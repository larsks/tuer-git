-- 3dvia.com   --

The zip file smach.dae.zip contains the following files :
- readme.txt
- 8D0CF28395A7B98B_smach.jpg
- smach.obj.dae


-- Model information --

Model Name : smach
Author : Psionic3D
Publisher : gouessej

You can view this model here :
http://www.3dvia.com/content/4DCB33435567794B
More models about this author :
http://www.3dvia.com/gouessej


-- Attached license --

A license is attached to the smach model and all related media.
You must agree with this licence before using the enclosed media.

License : Attribution-ShareAlike 2.5
Detailed license : http://creativecommons.org/licenses/by-sa/2.5/

The licenses used by 3dvia are based on Creative Commons Licenses.
More info: http://creativecommons.org/about/licenses/meet-the-licenses
