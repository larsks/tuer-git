-- 3dvia.com   --

The zip file pistol3.dae.zip contains the following files :
- readme.txt
- 8910EEBF91A3B587_pistol3.jpg
- pistol3.obj.dae


-- Model information --

Model Name : pistol3
Author : Psionic3D
Publisher : gouessej

You can view this model here :
http://www.3dvia.com/content/49CF2F7F51637547
More models about this author :
http://www.3dvia.com/gouessej


-- Attached license --

A license is attached to the pistol3 model and all related media.
You must agree with this licence before using the enclosed media.

License : Attribution-ShareAlike 2.5
Detailed license : http://creativecommons.org/licenses/by-sa/2.5/

The licenses used by 3dvia are based on Creative Commons Licenses.
More info: http://creativecommons.org/about/licenses/meet-the-licenses
