-- 3dvia.com   --

The zip file giger_alien.dae.zip contains the following files :
- readme.txt
- 03AA65390B1D2F01_giger_alien.jpg
- giger_alien.obj.dae


-- Model information --

Model Name : giger_alien
Author : www.jerryartist.com
Publisher : gouessej

You can view this model here :
http://www.3dvia.com/content/C26AA5F8CADCEEC0
More models about this author :
http://www.3dvia.com/gouessej


-- Attached license --

A license is attached to the giger_alien model and all related media.
You must agree with this licence before using the enclosed media.

License : Attribution-ShareAlike 2.5
Detailed license : http://creativecommons.org/licenses/by-sa/2.5/

The licenses used by 3dvia are based on Creative Commons Licenses.
More info: http://creativecommons.org/about/licenses/meet-the-licenses
