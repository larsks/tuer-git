-- 3dvia.com   --

The zip file laser.dae.zip contains the following files :
- readme.txt
- C464ABFACCDEF0C2_laser.jpg
- laser.obj.dae


-- Model information --

Model Name : laser
Author : Psionic3D
Publisher : gouessej

You can view this model here :
http://www.3dvia.com/content/8429E5BA8C9EB082
More models about this author :
http://www.3dvia.com/gouessej


-- Attached license --

A license is attached to the laser model and all related media.
You must agree with this licence before using the enclosed media.

License : Attribution-ShareAlike 2.5
Detailed license : http://creativecommons.org/licenses/by-sa/2.5/

The licenses used by 3dvia are based on Creative Commons Licenses.
More info: http://creativecommons.org/about/licenses/meet-the-licenses
