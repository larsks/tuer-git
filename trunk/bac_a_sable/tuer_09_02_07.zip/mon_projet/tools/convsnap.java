/*
   Prerequisites:
      this tools requires SUN's Java Advanced Imaging 
      Image I/O Tools, which can be downloaded from SUN
      for free (consult Google about it).
      the package allows easy read and write of
      all kinds of graphics formats.

   HOW TO USE:
   -  create a directory "snap" within your d3caster work dir
   -  create a directory "snap2" within your d3caster work dir
   -  run the demo locally (do-run-local.bat).
      while playing,
      -  press F1 to record a single snapshot
      -  press F2 to toggle movie recording on or off
      this creates many ".raw" files in snap/
   -  leave the demo
   -  open this source (convsnap.java),
      make sure the resolution settings match exactly
      the demo resolution you used (-> width, height below)
   -  from your d3caster working dir, type
         javac tools/convsnap.java
   -  run the conversion by typing
         java tools.convsnap
      this tools will automatically detect how many
      frames are present in snap/ and convert them
      to .png files within a directory snap2
*/

package tools;

import java.io.PrintWriter;
import java.text.NumberFormat;
import java.util.Random;

import javax.imageio.*;
import java.awt.*;
import java.awt.image.*;
import java.awt.image.BufferedImage;
import java.awt.image.DataBuffer;
import java.awt.image.WritableRaster;
import java.awt.geom.*;
import java.io.*;
import com.sun.image.codec.jpeg.*;

public class convsnap
{
   final int width =620;
   final int height=300;

   String quaddig(int i) {
      if (i<10)   return "000"+i;
      if (i<100)  return "00"+i;
      if (i<1000) return "0"+i;
      return ""+i;
   }

   static public void main(String args[])
      throws Throwable
   {
      try {
         new convsnap().conv();
      }  catch (Throwable e) {
         System.out.println("done");
      }
   }

   byte abuf[] = new byte[width*3];
   int apix[]  = new int[width*height];

   public void conv()
      throws Throwable
   {
      int x,y,ipix,ioff=0;
      int appletWidth =width;
      int appletHeight=height;
      int idumpcnt=0;

      for (int i=0; i<10000; i++) 
      {
         String sName = "snap/snap"+quaddig(i)+".raw";
         FileInputStream is = new FileInputStream(sName);

         for (y=0;y<appletHeight;y++) 
         {
            is.read(abuf,0,appletWidth*3);
            for (x=0;x<appletWidth;x++) 
            {
               ipix =  ((abuf[x*3+0]&0xFF)<<16)
                      |((abuf[x*3+1]&0xFF)<< 8)
                      |((abuf[x*3+2]&0xFF)    );
               apix[y*appletWidth+x] = ipix;
            }
         }
         is.close();

         BufferedImage buf = new BufferedImage(appletWidth,appletHeight,
            BufferedImage.TYPE_INT_ARGB);
         WritableRaster rast = buf.getRaster();

         int apix2[] = new int[4];
         ioff=0;
         for (y=0;y<appletHeight;y++)
         for (x=0;x<appletWidth;x++) {
            ipix=apix[ioff++];
            apix2[0]=(ipix>>16)&0xFF;
            apix2[1]=(ipix>> 8)&0xFF;
            apix2[2]=(ipix    )&0xFF;
            apix2[3]=0xFF;
            rast.setPixel(x,y,apix2);
         }

      try 
      {
         final String stype = "png";
         String lastDumpedFile="snap2/"+quaddig(idumpcnt++)+"."+stype;
         File file = new File(lastDumpedFile);
         ImageIO.write(buf, stype, file);
         System.out.println(lastDumpedFile+" written");
      }  catch (Throwable t) {
         System.out.println("error: "+t);
      }

      }
   }
}
