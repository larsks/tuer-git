/*
         d3conv - d3caster image conversion tool
      ==============================================
      Release 1.0, Vincent Stahl, www.StahlForce.com

   Prerequisites:

      this tools requires SUN's Java Advanced Imaging 
      Image I/O Tools, which can be downloaded from SUN
      for free (consult Google about it).
      the package allows easy read and write of
      all kinds of graphics formats.
 
   How to use this tool:

   -  create game images with 256x256 in truecolor.
      be aware what should be transparent, and what not.

   -  save them as TRANSPARENT PNG's.
      PNG is the perfect file format for this purpose,
      as it supplies a separate alpha channel.
      Consult your graphics software how to do this,
      or find the appropriate tools.

   -  d3conv then reads the png, and checks:
      -  IF an alpha channel is given, it
         -  saves a JPEG with the graphical content
         -  saves a Stahlforce compliant "image mask" file
            ending with .zip
         -  treats also all WHITE pixels (0xFFFFFF)
            as being transparent (added to the image mask).
            this is necessary to allow shadows on the ground.
      -  if NO alpha channel is given,
         it just saves a JPEG, and nothing else.

   -  in the next step, all .zip's must be packed together:

         jar cf masks.jar pic256\*.zip

      into one large JAR. this will by read by the game engine
      in one go, while the JPG's are read image by image.

   This is the optimum way for

   -  a minimum game loading time, due to JPEG compression

   -  having transparency info although using JPEG,
      without relying on GIF or PNG for transporting
      the image masks (many browsers still do not support
      loading of PNG within Java).

   Tips for own modifications:

   -  of course you may change the Whiteboxing
      to Blue- or Greenboxing. If you're unable
      to create PNG files with alpha channels,
      this could be an alternative for you.

   -  you may also change .png image reading
      to any other format, .bmp, .tga, .tiff etc.,
      whatever the ImageIO API supports.
*/

import java.io.PrintWriter;
import java.text.NumberFormat;
import java.util.Random;

import javax.imageio.*;
import java.awt.*;
import java.awt.image.*;
import java.awt.image.BufferedImage;
import java.awt.image.DataBuffer;
import java.awt.image.WritableRaster;
import java.awt.geom.*;
import java.io.*;
import java.util.zip.*;
import com.sun.image.codec.jpeg.*;

public class d3conv
{
   static int width=256, height=256;

   static public void main(String args[])
   {
      if (args.length < 4) {
         msg("d3conv - d3caster image converter 1.0\n"
            +"Release 1.0, Vincent Stahl, www.StahlForce.com\n"
            +"usage  : java d3conv srcbase destbase nframes quality [offs]\n"
            +"example: java d3conv dir1/ping dir2/pong 10 80\n"
            +"         will convert dir1/ping00.png to:\n"
            +"         -> dir2/pong00.jpg at 80 percent JPEG quality\n"
            +"         -> dir2/pong00.zip containing alpha mask\n"
            +"except.: if nframes==1, then no \"00\" is added.\n"
            +"... offs = counting offset, if set to 1, ping01.png\n"
            +"           is converted into pong00.jpg.\n"
            );
         return;
      }

      try
      {
         int iOffs = 0;
         if (args.length >= 5)
            iOffs = Integer.parseInt(args[4]);
         d3conv x = new d3conv();
         float fquality = Integer.parseInt(args[3])/100.0f;
         int inum = Integer.parseInt(args[2]);
         if (inum==1)
            x.convImage(
               args[0]+".png",
               args[1],
               0,
               fquality
               );
         else
         for (int iframe=0; iframe<inum; iframe++) {
            x.convImage(
               args[0]+doubdig(iframe+iOffs)+".png",
               args[1]+doubdig(iframe),
               iframe,
               fquality
               );
         }
      }  catch (Throwable t) {
         System.out.println("error: "+t);
      }
   }

   void convImage(String src,String dst,int iframe,float quality)
      throws Throwable
   {
         BufferedImage buf = ImageIO.read(new File(src));

         WritableRaster ralpha = buf.getAlphaRaster();
         // if (ralpha==null) {
         //   fail("no alpha raster found");
         // }
         // all alpha pixels with 0x00000000 are TRANSPARENT.
         // all alpha pixels with 0x000000FF are NOT TRANSPARENT.

         WritableRaster rast = buf.getRaster();

         // msg("samples before conversion:\n");
         // dump(rast);

         BufferedImage bout  = new BufferedImage(width,height,BufferedImage.TYPE_INT_RGB);
         WritableRaster rout = bout.getRaster();

         byte amask[] = new byte[width*height];
         for (int i=0; i<width*height; i++)
            amask[i] = 0;

         boolean bdetect=false;

         int npassed=0,nmasked=0;
         int apix1[] = new int[10];
         int apix2[] = new int[10];
         int iBytesPerY = width/8; // in the mask
         int r,g,b;
         for (int y=0; y<width; y++)
         for (int x=0; x<height; x++)
         {
            if (ralpha == null)
            {
               // no alpha channel given: copy image through
               rast.getPixel(x,y,apix2);
               rout.setPixel(x,y,apix2);
               npassed++;
            }
            else
            {
               // identify transparent pixels
               // 1. by the alpha channel
               // 2. furthermore, by the color White
               //    reason: objects should have shadows,
               //    this requires them to be placed on some
               //    white ground. the ground, however, should
               //    be removed, which is done here.
               ralpha.getPixel(x,y,apix1);
               rast.getPixel(x,y,apix2);
               r = apix2[0];
               g = apix2[1];
               b = apix2[2];
               if (    apix1[0]==0x00  // if alpha set
                    || (r==0xFF && g==0xFF && b==0xFF) // or white ground
                  )
               {
                  if (r==0xFF && g==0xFF && b==0xFF)
                     bdetect=true;  // white ground
   
                  rout.setPixel(x,y,apix2);     // copy thru (no use) but
                  amask[y*width+x] = (byte)1;   // also set mask to "transparent"
                  nmasked++;
               }
               else
               {
                  rout.setPixel(x,y,apix2);     // copy thru, and keep
                  npassed++;                    // mask on 0 "opaque"
               }
            }
         }

         // write graphical content as JPEG
         File file = new File(dst+".jpg");
         FileOutputStream out = new FileOutputStream(file);
         JPEGImageEncoder encoder = JPEGCodec.createJPEGEncoder(out);
         JPEGEncodeParam param = encoder.getDefaultJPEGEncodeParam(bout);
         param.setQuality(quality, false);
         encoder.setJPEGEncodeParam(param);
         encoder.encode(bout);
         out.close();

         // if alpha was given in PNG, then also write a ZIP MASK.
         if (ralpha!=null)
         {
            String sMaskFile = dst+".zip";
            OutputStream output = new BufferedOutputStream(new FileOutputStream(sMaskFile));
            writeMaskZip(output,amask,width,height);
            output.close();
            if (bdetect)   // the info masked(2) tells that also white ground was detected.
               msg(src+" -> "+dst+".jpg/zip, masked(2), "
                 +(int)(quality*100)+"%, "+file.length()+" bytes\n");
            else           // masked(1) tells only alpha was used, no white ground.
               msg(src+" -> "+dst+".jpg/zip, masked(1), "
                 +(int)(quality*100)+"%, "+file.length()+" bytes\n");
         }
         else
            msg(src+" -> "+dst+".jpg, opaque, at "
              +(int)(quality*100)+"%, "+file.length()+" bytes\n");
   }

   void fail(String s) {
         System.err.println(s);
         System.exit(1);
      }

   void writeMaskZip(OutputStream out, byte amask[], int w, int h)
      throws Throwable
   {
      // out.write(new String("ZMSK").getBytes("US-ASCII"),0,4);
      ZipOutputStream zout = new ZipOutputStream(out);
      ZipEntry entry = new ZipEntry("scmsk");
      zout.putNextEntry(entry);
      zout.write(amask,0,w*h);
      zout.finish();
   }

   static void msg(String s) {
         System.out.print(s);
   }

   // tools for debugging
   String hex(int n) {
      final String ahex[] = {
         "0","1","2","3","4","5","6","7","8","9",
         "A","B","C","D","E","F" };
      String s="";
      for (int i=32-4; i>=0; i-=4)
         s += ahex[(n>>i)&0xF];
      return s;
   }
   void dump(WritableRaster r) {
      int a[] = new int[10];
      for (int i=0; i<100; i++) {
         r.getPixel(128,i,a);
         msg(hex(a[0])+" "+hex(a[1])+" "+hex(a[2])+"\n");
      }
      msg("\n");
   }
   static String doubdig(int i) {
      if (i<10) return "0"+i;
      return ""+i;
   }
}
