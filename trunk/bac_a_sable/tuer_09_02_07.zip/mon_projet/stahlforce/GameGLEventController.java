package stahlforce;

import com.sun.opengl.util.GLUT;
import com.sun.opengl.util.Screenshot;
import java.io.File;
import java.io.IOException;
import java.nio.IntBuffer;
import java.util.List;
import java.util.Vector;
import javax.media.opengl.GL;
import javax.media.opengl.GLAutoDrawable;
import javax.media.opengl.GLCanvas;
import javax.media.opengl.GLEventListener;
import javax.media.opengl.GLException;

/**
 * This class has the role of being the controller 
 * (in the meaning of the design pattern "MVC") of
 * the GL events. It is a tool which is used by the
 * view and the model to communicate together. 
 * It avoids us to modify the model when we modify the view
 * and vice versa. It only handles the events related on
 * refreshing the display and creating the GL context.
 *
 * @author Julien Gouesse
 */

class GameGLEventController implements GLEventListener{
    
    
    private GL gl;
    
    private GLUT glut;
    
    private IntBuffer pixelsBuffer;
    
    private GLCanvas canvas;
    
    private d3caster gameView;
    
    private int screenWidth;
    
    private int screenHeight;
    
    private boolean screenshotAsked;
    
    private File screenshotFile;
    
    private List<String> messageLine;
    
    private List<Integer> messageHeight;
    
    private List<Boolean> messageLarge;
    
    
    GameGLEventController(d3caster gameView){
        this.gl=gameView.getGL();
	this.glut=new GLUT();
	this.pixelsBuffer=gameView.getPixelsBuffer();
	this.canvas=gameView.getCanvas();
	this.gameView=gameView;
	this.screenWidth=gameView.getScreenWidth();
	this.screenHeight=gameView.getScreenHeight();
	this.screenshotAsked=false;
	this.screenshotFile=null;
	this.messageLine=new Vector<String>();
	this.messageHeight=new Vector<Integer>();
	this.messageLarge=new Vector<Boolean>();
    }
    
    
    public void display(){
        canvas.display();
    }
    
    public void display(GLAutoDrawable drawable){	  
        gl.glMatrixMode (GL.GL_MODELVIEW);
        gl.glLoadIdentity(); 
        gl.glClear (GL.GL_COLOR_BUFFER_BIT);
        gl.glColor3f(0.0f,0.0f,0.0f);
	gl.glRasterPos2i(0,0);
	/*only direct buffers are supported on X11*/	
	/*prevents from drawing an empty render buffer and crash the JVM*/		
	/*push raster position*/
	gl.glPushAttrib(GL.GL_CURRENT_BIT);

	gl.glRasterPos2f(-1.0f,-1.0f);

	pixelsBuffer.position(0);

	gl.glDrawPixels(screenWidth,screenHeight,GL.GL_BGRA,GL.GL_UNSIGNED_BYTE,pixelsBuffer);
	pixelsBuffer.clear();	     
	/*pop raster position*/
	gl.glPopAttrib();		
	for(int i=0;i<messageLine.size();i++)
	    {gl.glPushAttrib(GL.GL_CURRENT_BIT);
	     gl.glColor3f(0.5f,0.2f,0.4f);
	     gl.glRasterPos2f(0.0f,1.0f-((float)(2*messageHeight.get(i).intValue()))/screenHeight);	     
	     if(!(messageLarge.get(i).booleanValue()))
	         glut.glutBitmapString(GLUT.BITMAP_TIMES_ROMAN_10,messageLine.get(i));
	     else
	         glut.glutBitmapString(GLUT.BITMAP_TIMES_ROMAN_24,messageLine.get(i));
	     gl.glPopAttrib();
	    }
	messageLine.clear();
	messageHeight.clear();
	messageLarge.clear();
	gl.glFlush();  
	/*this prevents problems with intel, SIS and ATI drivers 
	  under Microsoft Windows*/     
	try{canvas.swapBuffers();}
	catch(GLException glex){}
	if(screenshotAsked)
	    {screenshotAsked=false;
	     //save screenshot in a targa file
             try {Screenshot.writeToTargaFile(screenshotFile,screenWidth,screenHeight);}
	     catch(IOException ioe)
	     {ioe.printStackTrace();}
	    }	   	
    }

    public void displayChanged(GLAutoDrawable drawable, boolean modeChanged, boolean deviceChanged){}

    public void init(GLAutoDrawable drawable){
        gl.glClearColor(1.0f,1.0f,1.0f,1.0f);
	gl.glColor3f(0.0f,0.0f,0.0f);
	gl.glHint(GL.GL_PERSPECTIVE_CORRECTION_HINT,GL.GL_NICEST);
    /*
	gl.glClearColor(1.0,1.0,1.0,0.0);
	glClearDepth(1.0);
	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LESS);/*
	glEnable(GL_CULL_FACE);
	glCullFace(GL_BACK);*/
	/*glViewport(-50,-50,100,100);*/
	/*
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();  
	/*glFrustum(-50,50,-50,50,20,100);*//*ca marche quand meme*//*
	gluPerspective(65.0,((float)WINDOW_WIDTH)/
                	    ((float)WINDOW_HEIGHT),1,1000);
	
	glMatrixMode(GL_MODELVIEW);  	
	*/
    }

    public void reshape(GLAutoDrawable drawable, int x, int y, int width, int height){}
    
    public void pushMessage(String message,int height,boolean large){
        //fill the message queue
	messageLine.add(message);
	messageHeight.add(height);
	messageLarge.add(large);
    }
    
    public void performScreenshot(File file){
        screenshotAsked=true;
	screenshotFile=file;
    }
}
