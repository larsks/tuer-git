package stahlforce;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

/**
 *This class allows to exit the program when closing the frame.
 *
 *@author Julien Gouesse
 */

public class WindowClosingListener extends WindowAdapter{    
    
    public void windowClosing(WindowEvent we){
	System.exit(0);
    }   
    
}
