package stahlforce;

import java.awt.Image;

final class d3texture{


   private int nfaces;         // 1,2,4,8 or 16
   private int width;          // currently 256
   private int height;         // same as width, so far
   private short afaces[][];   // e.g. with or without rocket impact
   private long bytes;         // size in bytes, for statistics

   // dynamic loading support
   private String filebase;    // file base name
   private String filetype;    // extension
   private boolean transparent;   // used with objects
   private boolean usemask;    // use mask image

   // old image loading   
   private byte   amask[][];   // if any

   private long   lastupdate;  // used while loading
   private boolean maskAmbient; // use all green pix as ambient one


   public d3texture(
      int ifaces, int iwidth, int iheight,
      d3texture toCopyFrom,
      String sfilebase, String sfiletype,
      boolean btrans)
   {
      nfaces      = ifaces;
      width       = iwidth;
      height      = iheight;
      afaces      = new short[nfaces][width*height];
      bytes       = 2*nfaces*width*height;
      filebase    = sfilebase;
      filetype    = sfiletype;      
      amask       = null;
      transparent = btrans;
      usemask     = false;
      maskAmbient = false;
      lastupdate  = 0;
      initDefault(toCopyFrom); // even if toCopyFrom is null
   }
   
   int getNfaces(){return(nfaces);}         
   int getWidth(){return(width);}          
   int getHeight(){return(height);}         
   short[][] getAfaces(){return(afaces);}   
   long getBytes(){return(bytes);}            
   String getFilebase(){return(filebase);}    
   String getFiletype(){return(filetype);}    
   boolean getTransparent(){return(transparent);}  
   boolean getUsemask(){return(usemask);}             
   byte[][]   getAmask(){return(amask);}   
   long   getLastupdate(){return(lastupdate);}  
   boolean getMaskAmbient(){return(maskAmbient);}
   
   void setNfaces(int nfaces){this.nfaces=nfaces;}         
   void setWidth(int width){this.width=width;}          
   void setHeight(int height){this.height=height;}         
   void setAfaces(short[][] afaces){this.afaces=afaces;}   
   void setBytes(long bytes){this.bytes=bytes;}            
   void setFilebase(String filebase){this.filebase=filebase;}    
   void setFiletype(String filetype){this.filetype=filetype;}    
   void setTransparent(boolean transparent){this.transparent=transparent;}  
   void setUsemask(boolean usemask){this.usemask=usemask;}             
   void setAmask(byte[][] amask){this.amask=amask;} 
   void setAmask(int index,byte[] amask){this.amask[index]=amask;}   
   void setLastupdate(long lastupdate){this.lastupdate=lastupdate;}  
   void setMaskAmbient(boolean maskAmbient){this.maskAmbient=maskAmbient;}


   void initDefault(d3texture d3default)
   {
      for (int n=0; n<nfaces; n++)
      {
         if (   d3default != null
             && d3default.width == width
             && d3default.height == height)
         {
            for (int i=0; i<width*height; i++)
               afaces[n][i] = d3default.afaces[0][i];
         }
         else
         for (int i=0; i<width*height; i++)
            afaces[n][i] = (short)0xFFFF; // transparent
      }
   }

   public short [] face(int idx) {
      return afaces[idx % nfaces];  // previously "idx & nfacemask"
   }
}
