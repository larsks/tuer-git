/*This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation, version 2
  of the License.
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston,
  MA 02111-1307, USA.
*/
package drawer;

import com.sun.opengl.util.BufferUtil;
import java.nio.FloatBuffer;
import javax.media.opengl.GL;


class StaticVertexBufferObject extends StaticVertexSet{
    
    
    private int[] id;
    
    
    StaticVertexBufferObject(GL gl,float[] array){
        this.mode=GL.GL_TRIANGLES;
        this.gl=gl;
	this.buffer=BufferUtil.newFloatBuffer(array.length);
	this.buffer.put(array);	
	this.buffer.position(0);
	/*TODO : create the vertex buffer object*/
	this.id=new int[1];
	gl.glGenBuffersARB(1,id,0);
	gl.glBindBufferARB(GL.GL_ARRAY_BUFFER_ARB,id[0]);
	gl.glBufferDataARB(GL.GL_ARRAY_BUFFER_ARB,BufferUtil.SIZEOF_FLOAT*buffer.capacity(),buffer,GL.GL_STATIC_DRAW_ARB);
	this.buffer.position(0);		
    }
    
    StaticVertexBufferObject(GL gl,FloatBuffer floatBuffer){
        this.mode=GL.GL_TRIANGLES;
        this.gl=gl;
	this.buffer=BufferUtil.copyFloatBuffer(floatBuffer);
	this.buffer.position(0);
	/*TODO : create the vertex buffer object*/
	this.id=new int[1];
	gl.glGenBuffersARB(1,id,0);
	gl.glBindBufferARB(GL.GL_ARRAY_BUFFER_ARB,id[0]);
	gl.glBufferDataARB(GL.GL_ARRAY_BUFFER_ARB,BufferUtil.SIZEOF_FLOAT*buffer.capacity(),buffer,GL.GL_STATIC_DRAW_ARB);
	this.buffer.position(0);
    }
    
    StaticVertexBufferObject(GL gl,IVertexSet vertexSet){
        this(gl,vertexSet.getBuffer());
    }    
            
    public void draw(){       		
	/*TODO : draw the vertex buffer object*/	
	gl.glEnableClientState(GL.GL_VERTEX_ARRAY);
	//gl.glEnableClientState(GL.GL_NORMAL_ARRAY);
	gl.glEnableClientState(GL.GL_TEXTURE_COORD_ARRAY);
	gl.glBindBufferARB(GL.GL_ARRAY_BUFFER_ARB,id[0]);
	gl.glInterleavedArrays(VertexSet.interleavedFormat,0,0);       
	final int size=buffer.capacity()/VertexSet.primitiveCount;
	for(int i=0;i<size;i+=VertexSetFactory.GL_MAX_ELEMENTS_VERTICES)
	    {buffer.position(0);
	     if(size-i<=VertexSetFactory.GL_MAX_ELEMENTS_VERTICES)
	         gl.glDrawArrays(mode,i,size-i);
	     else
	         gl.glDrawArrays(mode,i,VertexSetFactory.GL_MAX_ELEMENTS_VERTICES);
             buffer.position(0);	     
	    }			
	gl.glDisableClientState(GL.GL_TEXTURE_COORD_ARRAY);
	//gl.glDisableClientState(GL.GL_NORMAL_ARRAY);
	gl.glDisableClientState(GL.GL_VERTEX_ARRAY);
    }
}
