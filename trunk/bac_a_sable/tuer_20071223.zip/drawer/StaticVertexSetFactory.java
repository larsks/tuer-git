/*This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation, version 2
  of the License.
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston,
  MA 02111-1307, USA.
*/
package drawer;

import java.nio.FloatBuffer;
import javax.media.opengl.GL;


class StaticVertexSetFactory extends AbstractStaticVertexSetFactory{

    
    private AbstractStaticVertexSetFactory delegate;
    
    private StaticDefaultVertexSetFactory rescueDelegate;
    
    
    StaticVertexSetFactory(GL gl){
        /*TODO : force display lists if GL VERSION < 3.0??*/
	if(gl.isExtensionAvailable("GL_ARB_vertex_buffer_object")
	&& gl.isFunctionAvailable("glBindBufferARB")
	&& gl.isFunctionAvailable("glBufferDataARB")
	&& gl.isFunctionAvailable("glDeleteBuffersARB")
	&& gl.isFunctionAvailable("glGenBuffersARB"))
	    {delegate=new StaticVertexBufferObjectFactory(gl);
	     rescueDelegate=null;
	    }
	else
	    /*if(gl.isExtensionAvailable("GL_EXT_compiled_vertex_array")
	    && gl.isFunctionAvailable("glLockArraysEXT")
	    && gl.isFunctionAvailable("glUnlockArraysEXT"))
	        {delegate=new CompiledVertexArrayFactory(gl);
		 rescueDelegate=null;
		}
	    else*/
	        if(gl.isFunctionAvailable("glCallList")
		&& gl.isFunctionAvailable("glCallLists")
		&& gl.isFunctionAvailable("glDeleteLists")
		&& gl.isFunctionAvailable("glGenLists")
		&& gl.isFunctionAvailable("glNewList")
		&& gl.isFunctionAvailable("glEndList"))
		    {delegate=new DisplayListFactory(gl);
		     rescueDelegate=new StaticDefaultVertexSetFactory(gl);
		    }
		else
		    {delegate=new StaticDefaultVertexSetFactory(gl);
		     rescueDelegate=null;
		    }
    }
        
    
    StaticVertexSet newVertexSet(float[] array){
	StaticVertexSet set=null;
	try {set=delegate.newVertexSet(array);}
	catch(RuntimeException re)
	{if(rescueDelegate!=null)
	     set=rescueDelegate.newVertexSet(array);
	}
        return(set);
    }
    
    StaticVertexSet newVertexSet(FloatBuffer floatBuffer){
	StaticVertexSet set=null;
	try {set=delegate.newVertexSet(floatBuffer);}
	catch(RuntimeException re)
	{if(rescueDelegate!=null)
	     set=rescueDelegate.newVertexSet(floatBuffer);
	}
        return(set);
    }
    
    StaticVertexSet newVertexSet(IVertexSet vertexSet){
	StaticVertexSet set=null;
	try {set=delegate.newVertexSet(vertexSet);}
	catch(RuntimeException re)
	{if(rescueDelegate!=null)
	     set=rescueDelegate.newVertexSet(vertexSet);
	}
        return(set);
    }
}
