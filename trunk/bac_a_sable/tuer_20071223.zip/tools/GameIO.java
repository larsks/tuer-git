/*This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation, version 2
  of the License.
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston,
  MA 02111-1307, USA.
*/

/**
 * This class is the facade of the component called "tools". 
 * It provides some static methods to manipulate textures.
 *@author Julien Gouesse
 */

package tools;

import com.sun.opengl.util.ImageUtil;
import com.sun.opengl.util.texture.Texture;
import com.sun.opengl.util.texture.TextureIO;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.net.URL;

import javax.swing.ImageIcon;

public class GameIO{

    public static Texture newTexture(URL url,boolean mipmap,String fileSuffix){  
        Image image=new ImageIcon(url).getImage();
        BufferedImage bufferedImage;
        if(fileSuffix.equals(TextureIO.PNG)||fileSuffix.equals(TextureIO.GIF))
            bufferedImage=new BufferedImage(image.getWidth(null),image.getHeight(null),BufferedImage.TYPE_INT_ARGB);
        else
            bufferedImage=new BufferedImage(image.getWidth(null),image.getHeight(null),BufferedImage.TYPE_3BYTE_BGR);
        Graphics g=bufferedImage.getGraphics();
        g.drawImage(image,0,0,null);
        g.dispose();
        ImageUtil.flipImageVertically(bufferedImage);
        return(TextureIO.newTexture(bufferedImage,mipmap));
    }
}
