/*This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation, version 2
  of the License.
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston,
  MA 02111-1307, USA.
*/

/*This class computes the vertex coordinates and texture coordinates
  of the tiles representing the level by using the map in Stahl's format. 
  It deletes useless "walls", keeps the useful walls and builds the floor 
  and the ceil. 
*/

package tools;

import java.awt.Image;
import java.awt.image.PixelGrabber;
import java.awt.Point;
import java.awt.Toolkit;
import java.io.BufferedOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.Vector;

public final class TilesGenerator{


    private List<PointPair> topWallsList;
    
    private List<PointPair> bottomWallsList;
    
    private List<PointPair> leftWallsList;
    
    private List<PointPair> rightWallsList;
    
    private List<PointPair> artTopWallsList;
    
    private List<PointPair> artBottomWallsList;
    
    private List<PointPair> artLeftWallsList;
    
    private List<PointPair> artRightWallsList;
    
    private List<Point> ceilTilesList;
    
    private List<Point> floorTilesList;
    
    private List<Point> specialCeilTilesList;
    
    private List<Point> specialFloorTilesList;
    
    private List<Point> unbreakableObjectsTilesList;
    
    private List<Point> lampsTilesList;
    
    private List<Point> chairsTilesList;
    
    private List<Point> flowerPotsTilesList;   
    
    private List<Point> tablesTilesList;
    
    private List<Point> vendingMachinesTilesList;
    
    private List<Point> bonsaiTreesTilesList;
    
    private int[] worldMap;
    
    private static final int tileSize=256;

    private static final int artCount=27;

    private static final int artPerTexture=16;

    private static final int artTextureSize=4;
    
    private static final int factor=65536;    
    
    private static final int EMPTY=0;
    
    private static final int FIXED_AND_BREAKABLE_CHAIR=1;
    
    private static final int FIXED_AND_BREAKABLE_LIGHT=2;
    
    private static final int MOVING_AND_BREAKABLE=3;
    
    private static final int AVOIDABLE_AND_UNBREAKABLE=4;
    
    private static final int UNAVOIDABLE_AND_UNBREAKABLE=5;    
    
    private static final int UNAVOIDABLE_AND_UNBREAKABLE_DIRTY=6;
    
    private static final int FIXED_AND_BREAKABLE_BIG=7;
    
    private static final int FIXED_AND_BREAKABLE_FLOWER=8;
    
    private static final int FIXED_AND_BREAKABLE_TABLE=9;
    
    private static final int FIXED_AND_BREAKABLE_BONSAI=10;      
    
    private static final int UNAVOIDABLE_AND_UNBREAKABLE_DOWN=11;
    
    private static final int UNAVOIDABLE_AND_UNBREAKABLE_LEFT=12;
    
    private static final int UNAVOIDABLE_AND_UNBREAKABLE_RIGHT=13;
    
    private static final int UNAVOIDABLE_AND_UNBREAKABLE_UP_DOWN=14;
    
    private static final int UNAVOIDABLE_AND_UNBREAKABLE_UP_LEFT=15;
    
    private static final int UNAVOIDABLE_AND_UNBREAKABLE_UP_RIGHT=16;
    
    private static final int UNAVOIDABLE_AND_UNBREAKABLE_UP_DOWN_LEFT=17;
    
    private static final int UNAVOIDABLE_AND_UNBREAKABLE_UP_DOWN_RIGHT=18;
    
    private static final int UNAVOIDABLE_AND_UNBREAKABLE_UP_LEFT_RIGHT=19;
               
    private static final int UNAVOIDABLE_AND_UNBREAKABLE_UP_DOWN_LEFT_RIGHT=20;
       
    private static final int UNAVOIDABLE_AND_UNBREAKABLE_DOWN_LEFT=21;
    
    private static final int UNAVOIDABLE_AND_UNBREAKABLE_DOWN_RIGHT=22;
    
    private static final int UNAVOIDABLE_AND_UNBREAKABLE_DOWN_LEFT_RIGHT=23;
    
    private static final int UNAVOIDABLE_AND_UNBREAKABLE_LEFT_RIGHT=24;
    
    private static final int UNAVOIDABLE_AND_UNBREAKABLE_UP=25;
    
    //dirty walls
    private static final int UNAVOIDABLE_AND_UNBREAKABLE_DOWN_DIRTY=26;
    
    private static final int UNAVOIDABLE_AND_UNBREAKABLE_LEFT_DIRTY=27;
    
    private static final int UNAVOIDABLE_AND_UNBREAKABLE_RIGHT_DIRTY=28;
    
    private static final int UNAVOIDABLE_AND_UNBREAKABLE_UP_DOWN_DIRTY=29;
    
    private static final int UNAVOIDABLE_AND_UNBREAKABLE_UP_LEFT_DIRTY=30;
    
    private static final int UNAVOIDABLE_AND_UNBREAKABLE_UP_RIGHT_DIRTY=31;
    
    private static final int UNAVOIDABLE_AND_UNBREAKABLE_UP_DOWN_LEFT_DIRTY=32;
    
    private static final int UNAVOIDABLE_AND_UNBREAKABLE_UP_DOWN_RIGHT_DIRTY=33;
    
    private static final int UNAVOIDABLE_AND_UNBREAKABLE_UP_LEFT_RIGHT_DIRTY=34;
               
    private static final int UNAVOIDABLE_AND_UNBREAKABLE_UP_DOWN_LEFT_RIGHT_DIRTY=35;
       
    private static final int UNAVOIDABLE_AND_UNBREAKABLE_DOWN_LEFT_DIRTY=36;
    
    private static final int UNAVOIDABLE_AND_UNBREAKABLE_DOWN_RIGHT_DIRTY=37;
    
    private static final int UNAVOIDABLE_AND_UNBREAKABLE_DOWN_LEFT_RIGHT_DIRTY=38;
    
    private static final int UNAVOIDABLE_AND_UNBREAKABLE_LEFT_RIGHT_DIRTY=39;
    
    private static final int UNAVOIDABLE_AND_UNBREAKABLE_UP_DIRTY=40;

    
    public TilesGenerator(String mapFilename,String tilesFilename,
            String rocketLauncherFilename,String binaryMapFilename){
        topWallsList=new Vector<PointPair>();   
        bottomWallsList=new Vector<PointPair>();
        leftWallsList=new Vector<PointPair>();
        rightWallsList=new Vector<PointPair>();
        artTopWallsList=new Vector<PointPair>();   
        artBottomWallsList=new Vector<PointPair>();
        artLeftWallsList=new Vector<PointPair>();
        artRightWallsList=new Vector<PointPair>();
        ceilTilesList=new Vector<Point>();
        floorTilesList=new Vector<Point>();
        specialCeilTilesList=new Vector<Point>();
        specialFloorTilesList=new Vector<Point>();
        unbreakableObjectsTilesList=new Vector<Point>();
        lampsTilesList=new Vector<Point>();
        chairsTilesList=new Vector<Point>();
        flowerPotsTilesList=new Vector<Point>();
        tablesTilesList=new Vector<Point>();
        vendingMachinesTilesList=new Vector<Point>();
        bonsaiTreesTilesList=new Vector<Point>();
        Image worldMapImage;
        worldMapImage=Toolkit.getDefaultToolkit().getImage(mapFilename);
        worldMap=new int[65536];	
	    try {(new PixelGrabber(worldMapImage,0,0,tileSize,tileSize,worldMap,0,tileSize)).grabPixels();}
        catch(InterruptedException i) 
	    {System.out.println("Pixel grabber interrupted");}
        worldMapImage.flush();
	    int tmp,r,g,b;
	    PointPair pair;	
	    //i : line index
	    //j : column index
	    byte[] collisionMap=new byte[256*256];
	    for(int i=0;i<256;i++)
             {tmp=i*256;
	          for(int j=0;j<256;j++)
	         /*handle decorated walls as "special" walls here*/
	              {r=(worldMap[tmp+j]>>16)&0xFF;
		           g=(worldMap[tmp+j]>>8)&0xFF;
		           b=worldMap[tmp+j]&0xFF;		  
		           if(((r==0x00)&&(g==0x00)&&(b==0xFF))||((r==0xFF)&&(g==0xFF)&&(b==0x00)))
		               {//upper wall
		                pair=new PointPair(new Point(j,i),new Point(j+1,i));
		                if(removePointPair(bottomWallsList,pair))
			                removePointPair(artBottomWallsList,pair);
		                else
		                    if(!removePointPair(artBottomWallsList,pair))
		                        topWallsList.add((PointPair)pair.clone());
		                //use clone()!!!!!
		                //lower wall
		                pair=new PointPair(new Point(j,i+1),new Point(j+1,i+1));
		                if(removePointPair(topWallsList,pair))
		                    removePointPair(artTopWallsList,pair);
		                else
		                    if(!removePointPair(artTopWallsList,pair))			       
		                        bottomWallsList.add((PointPair)pair.clone());
		                //left side wall
		                pair=new PointPair(new Point(j,i),new Point(j,i+1));
		                if(removePointPair(rightWallsList,pair))
		                    removePointPair(artRightWallsList,pair);
		                else
		                    if(!removePointPair(artRightWallsList,pair))			       
		                        leftWallsList.add((PointPair)pair.clone());
		                //right side wall
		                pair=new PointPair(new Point(j+1,i),new Point(j+1,i+1));
		                if(removePointPair(leftWallsList,pair))
		                    removePointPair(artLeftWallsList,pair);
		                else
		                    if(!removePointPair(artLeftWallsList,pair))
		                        rightWallsList.add((PointPair)pair.clone());
		                collisionMap[tmp+j]=UNAVOIDABLE_AND_UNBREAKABLE;		           
		               }
		           else
		               if((r==0x00)&&(g==0x00)&&(b==0x64))
		                   {//upper wall
		                    pair=new PointPair(new Point(j,i),new Point(j+1,i));
		                    if(removePointPair(bottomWallsList,pair))
		                        removePointPair(artBottomWallsList,pair);
		                    else
		                        if(!removePointPair(artBottomWallsList,pair))
		                            artTopWallsList.add((PointPair)pair.clone());
		                    //use clone()!!!!!
		                    //lower wall
		                    pair=new PointPair(new Point(j,i+1),new Point(j+1,i+1));
		                    if(removePointPair(topWallsList,pair))
		                        removePointPair(artTopWallsList,pair);
		                    else
		                        if(!removePointPair(artTopWallsList,pair))			       
		                            artBottomWallsList.add((PointPair)pair.clone());
		                    //left side wall
		                    pair=new PointPair(new Point(j,i),new Point(j,i+1));
		                    if(removePointPair(rightWallsList,pair))
		                        removePointPair(artRightWallsList,pair);
		                    else
		                        if(!removePointPair(artRightWallsList,pair))			       
		                            artLeftWallsList.add((PointPair)pair.clone());
		                    //right side wall
		                    pair=new PointPair(new Point(j+1,i),new Point(j+1,i+1));
		                    if(removePointPair(leftWallsList,pair))
		                        removePointPair(artLeftWallsList,pair);
		                    else
		                        if(!removePointPair(artLeftWallsList,pair))
		                            artRightWallsList.add((PointPair)pair.clone());
		                    collisionMap[tmp+j]=UNAVOIDABLE_AND_UNBREAKABLE;			   	      
		                   }
		               else
			               {if((r==0x00)&&(g==0x00)&&(b==0x00))
		                        {//add floor and ceil
		                         specialFloorTilesList.add(new Point(j,i));
		                         specialFloorTilesList.add(new Point(j,i+1));
		                         specialFloorTilesList.add(new Point(j+1,i+1));
		                         specialFloorTilesList.add(new Point(j+1,i));
		                         specialCeilTilesList.add(new Point(j+1,i));
		                         specialCeilTilesList.add(new Point(j+1,i+1));
		                         specialCeilTilesList.add(new Point(j,i+1));
		                         specialCeilTilesList.add(new Point(j,i));
		                         collisionMap[tmp+j]=EMPTY;
		                        }
			                else
		                        {//add floor and ceil
			                     if((r==0x00)&&(g==0xFF)&&(b==0xFF))
				                     {collisionMap[tmp+j]=MOVING_AND_BREAKABLE;
				                      //collisionMap[tmp+j]=EMPTY;
				                      System.out.println("bot FF");
				                     }
				                 else
				                     if((r==0x00)&&(g==0xC8)&&(b==0xC8))
				                         {collisionMap[tmp+j]=MOVING_AND_BREAKABLE;
					                      //collisionMap[tmp+j]=EMPTY;
					                      System.out.println("bot C8");
					                     }
				                     else
				                         if((r==0x00)&&(g==0x00)&&(b==0xE0))
				                             {unbreakableObjectsTilesList.add(new Point(j,i));
				                             unbreakableObjectsTilesList.add(new Point(j,i+1));
				                             unbreakableObjectsTilesList.add(new Point(j+1,i+1));
				                             unbreakableObjectsTilesList.add(new Point(j+1,i));
				                             collisionMap[tmp+j]=AVOIDABLE_AND_UNBREAKABLE;
				                             System.out.println("unbreakable object");
				                             }
				                         else
				                             if((r==0x99)&&(g==0x00)&&(b==0x99))
				                                 {lampsTilesList.add(new Point(j,i));
				                                 lampsTilesList.add(new Point(j,i+1));
				                                 lampsTilesList.add(new Point(j+1,i+1));
				                                 lampsTilesList.add(new Point(j+1,i));
				                                 collisionMap[tmp+j]=FIXED_AND_BREAKABLE_LIGHT;
				                                 System.out.println("lamp");
				                                 }
				                             else
				                                 if((r==0x97)&&(g==0x00)&&(b==0x97))
				                                     {chairsTilesList.add(new Point(j,i));
				                                     chairsTilesList.add(new Point(j,i+1));
				                                     chairsTilesList.add(new Point(j+1,i+1));
				                                     chairsTilesList.add(new Point(j+1,i));
				                                     collisionMap[tmp+j]=FIXED_AND_BREAKABLE_CHAIR;
				                                     System.out.println("chair");
				                                     }
				                                 else
				                                     if((r==0xC8)&&(g==0x00)&&(b==0xC8))
				                                         {flowerPotsTilesList.add(new Point(j,i));
				                                         flowerPotsTilesList.add(new Point(j,i+1));
				                                         flowerPotsTilesList.add(new Point(j+1,i+1));
				                                         flowerPotsTilesList.add(new Point(j+1,i));
				                                         collisionMap[tmp+j]=FIXED_AND_BREAKABLE_FLOWER;
				                                         System.out.println("flower pot");
				                                         }
				                                     else
				                                         if((r==0x64)&&(g==0x00)&&(b==0x64))
				                                             {tablesTilesList.add(new Point(j,i));
				                                             tablesTilesList.add(new Point(j,i+1));
				                                             tablesTilesList.add(new Point(j+1,i+1));
				                                             tablesTilesList.add(new Point(j+1,i));
				                                             collisionMap[tmp+j]=FIXED_AND_BREAKABLE_TABLE;
				                                             System.out.println("table");
				                                             }
				                                         else
				                                             if((r==0x96)&&(g==0x00)&&(b==0x96))
				                                                 {vendingMachinesTilesList.add(new Point(j,i));
				                                                 vendingMachinesTilesList.add(new Point(j,i+1));
				                                                 vendingMachinesTilesList.add(new Point(j+1,i+1));
				                                                 vendingMachinesTilesList.add(new Point(j+1,i));
				                                                 //collisionMap[tmp+j]=FIXED_AND_BREAKABLE;
				                                                 collisionMap[tmp+j]=FIXED_AND_BREAKABLE_BIG;
				                                                 System.out.println("vending machine");
				                                                 }
				                                             else
				                                                 if((r==0x98)&&(g==0x00)&&(b==0x98))
				                                                     {bonsaiTreesTilesList.add(new Point(j,i));
				                                                     bonsaiTreesTilesList.add(new Point(j,i+1));
				                                                     bonsaiTreesTilesList.add(new Point(j+1,i+1));
				                                                     bonsaiTreesTilesList.add(new Point(j+1,i));
				                                                     collisionMap[tmp+j]=FIXED_AND_BREAKABLE_BONSAI;
				                                                     System.out.println("bonsai tree");
				                                                     }
				                                                 else
				                                                     if((r==0xFF)&&(g==0x00)&&(b==0x00))
				                                                         {
				                                                             System.out.println("initial point");
				                                                         }
				                                                     else
				                                                         if((r==0x64)&&(g==0x64)&&(b==0x64))
				                                                             {
				                                                                 System.out.println("respawn point");
				                                                             }
				                                                         else
				                                                             {//empty area
				                                                                 collisionMap[tmp+j]=EMPTY;
				                                                             }
			                     floorTilesList.add(new Point(j,i));
			                     floorTilesList.add(new Point(j,i+1));
			                     floorTilesList.add(new Point(j+1,i+1));
			                     floorTilesList.add(new Point(j+1,i));
			                     ceilTilesList.add(new Point(j+1,i));
			                     ceilTilesList.add(new Point(j+1,i+1));
			                     ceilTilesList.add(new Point(j,i+1));
			                     ceilTilesList.add(new Point(j,i));
		                        }
			               }
	              }
             }	
	    boolean found;
	    for(int i=0;i<256;i++)
	        {tmp=i*256;
	         for(int j=0;j<256;j++)
	             if(collisionMap[tmp+j]==UNAVOIDABLE_AND_UNBREAKABLE)
	                 {found=false;
	                 //upper wall
	                 pair=new PointPair(new Point(j,i),new Point(j+1,i));
	                 for(PointPair po:topWallsList)
	                     if(pair.equals(po))
	                         {found=true;
	                          break;
	                         }
	                if(found)
	                    {switch(collisionMap[tmp+j])
	                        {case UNAVOIDABLE_AND_UNBREAKABLE:
	                        {collisionMap[tmp+j]=UNAVOIDABLE_AND_UNBREAKABLE_UP;
	                        break;
	                        } 			        
	                        case UNAVOIDABLE_AND_UNBREAKABLE_DOWN:
	                        {collisionMap[tmp+j]=UNAVOIDABLE_AND_UNBREAKABLE_UP_DOWN;
	                        break;
	                        }
	                        case UNAVOIDABLE_AND_UNBREAKABLE_LEFT:
	                        {collisionMap[tmp+j]=UNAVOIDABLE_AND_UNBREAKABLE_UP_LEFT;
	                        break;
	                        }
	                        case UNAVOIDABLE_AND_UNBREAKABLE_RIGHT:
	                        {collisionMap[tmp+j]=UNAVOIDABLE_AND_UNBREAKABLE_UP_RIGHT;
	                        break;
	                        }
	                        case UNAVOIDABLE_AND_UNBREAKABLE_DOWN_LEFT:
	                        {collisionMap[tmp+j]=UNAVOIDABLE_AND_UNBREAKABLE_UP_DOWN_LEFT;
	                        break;
	                        }
	                        case UNAVOIDABLE_AND_UNBREAKABLE_DOWN_RIGHT:
	                        {collisionMap[tmp+j]=UNAVOIDABLE_AND_UNBREAKABLE_UP_DOWN_RIGHT;
	                        break;
	                        }
	                        case UNAVOIDABLE_AND_UNBREAKABLE_LEFT_RIGHT:
	                        {collisionMap[tmp+j]=UNAVOIDABLE_AND_UNBREAKABLE_UP_LEFT_RIGHT;
	                        break;
	                        }
	                        case UNAVOIDABLE_AND_UNBREAKABLE_DOWN_LEFT_RIGHT:
	                        {collisionMap[tmp+j]=UNAVOIDABLE_AND_UNBREAKABLE_UP_DOWN_LEFT_RIGHT;
	                        break;
	                        }				   
	                        }
	                    }
	                found=false;  
	                //lower wall
	                pair=new PointPair(new Point(j,i+1),new Point(j+1,i+1));	              
	                for(PointPair po:bottomWallsList)
	                    if(pair.equals(po))
	                        {found=true;
	                        break;
	                        }
		      if(found)
		          {switch(collisionMap[tmp+j])
			       {case UNAVOIDABLE_AND_UNBREAKABLE:
			            {collisionMap[tmp+j]=UNAVOIDABLE_AND_UNBREAKABLE_DOWN;
				     break;
				    } 			        
			        case UNAVOIDABLE_AND_UNBREAKABLE_UP:
				    {collisionMap[tmp+j]=UNAVOIDABLE_AND_UNBREAKABLE_UP_DOWN;
				     break;
				    }
				case UNAVOIDABLE_AND_UNBREAKABLE_LEFT:
				    {collisionMap[tmp+j]=UNAVOIDABLE_AND_UNBREAKABLE_DOWN_LEFT;
				     break;
				    }
				case UNAVOIDABLE_AND_UNBREAKABLE_RIGHT:
				    {collisionMap[tmp+j]=UNAVOIDABLE_AND_UNBREAKABLE_DOWN_RIGHT;
				     break;
				    }
				case UNAVOIDABLE_AND_UNBREAKABLE_UP_LEFT:
				    {collisionMap[tmp+j]=UNAVOIDABLE_AND_UNBREAKABLE_UP_DOWN_LEFT;
				     break;
				    }
				case UNAVOIDABLE_AND_UNBREAKABLE_UP_RIGHT:
				    {collisionMap[tmp+j]=UNAVOIDABLE_AND_UNBREAKABLE_UP_DOWN_RIGHT;
				     break;
				    }
				case UNAVOIDABLE_AND_UNBREAKABLE_LEFT_RIGHT:
				    {collisionMap[tmp+j]=UNAVOIDABLE_AND_UNBREAKABLE_DOWN_LEFT_RIGHT;
				     break;
				    }
				case UNAVOIDABLE_AND_UNBREAKABLE_UP_LEFT_RIGHT:
				    {collisionMap[tmp+j]=UNAVOIDABLE_AND_UNBREAKABLE_UP_DOWN_LEFT_RIGHT;
				     break;
				    }				   
			       }
			  }      			      
		      found=false;
		      //left side wall
		      pair=new PointPair(new Point(j,i),new Point(j,i+1));
		      for(PointPair po:leftWallsList)
		          if(pair.equals(po))
			      {found=true;
			       break;
			      }
		      if(found)
		          {switch(collisionMap[tmp+j])
			       {case UNAVOIDABLE_AND_UNBREAKABLE:
			            {collisionMap[tmp+j]=UNAVOIDABLE_AND_UNBREAKABLE_LEFT;
				     break;
				    } 			        
			        case UNAVOIDABLE_AND_UNBREAKABLE_UP:
				    {collisionMap[tmp+j]=UNAVOIDABLE_AND_UNBREAKABLE_UP_LEFT;
				     break;
				    }
				case UNAVOIDABLE_AND_UNBREAKABLE_DOWN:
				    {collisionMap[tmp+j]=UNAVOIDABLE_AND_UNBREAKABLE_DOWN_LEFT;
				     break;
				    }				
				case UNAVOIDABLE_AND_UNBREAKABLE_RIGHT:
				    {collisionMap[tmp+j]=UNAVOIDABLE_AND_UNBREAKABLE_LEFT_RIGHT;
				     break;
				    }
				case UNAVOIDABLE_AND_UNBREAKABLE_UP_DOWN:
				    {collisionMap[tmp+j]=UNAVOIDABLE_AND_UNBREAKABLE_UP_DOWN_LEFT;
				     break;
				    }
				case UNAVOIDABLE_AND_UNBREAKABLE_UP_RIGHT:
				    {collisionMap[tmp+j]=UNAVOIDABLE_AND_UNBREAKABLE_UP_LEFT_RIGHT;
				     break;
				    }				
				case UNAVOIDABLE_AND_UNBREAKABLE_DOWN_RIGHT:
				    {collisionMap[tmp+j]=UNAVOIDABLE_AND_UNBREAKABLE_DOWN_LEFT_RIGHT;
				     break;
				    }				
				case UNAVOIDABLE_AND_UNBREAKABLE_UP_DOWN_RIGHT:
				    {collisionMap[tmp+j]=UNAVOIDABLE_AND_UNBREAKABLE_UP_DOWN_LEFT_RIGHT;
				     break;
				    }				   
			       }
			  }
		      found=false;
		      //right side wall
		      pair=new PointPair(new Point(j+1,i),new Point(j+1,i+1)); 
		      for(PointPair po:rightWallsList)
		          if(pair.equals(po))
			      {found=true;
			       break;
			      }
		      if(found)
		          {switch(collisionMap[tmp+j])
			       {case UNAVOIDABLE_AND_UNBREAKABLE:
			            {collisionMap[tmp+j]=UNAVOIDABLE_AND_UNBREAKABLE_RIGHT;
				     break;
				    } 			        
			        case UNAVOIDABLE_AND_UNBREAKABLE_UP:
				    {collisionMap[tmp+j]=UNAVOIDABLE_AND_UNBREAKABLE_UP_RIGHT;
				     break;
				    }
				case UNAVOIDABLE_AND_UNBREAKABLE_DOWN:
				    {collisionMap[tmp+j]=UNAVOIDABLE_AND_UNBREAKABLE_DOWN_RIGHT;
				     break;
				    }				
				case UNAVOIDABLE_AND_UNBREAKABLE_LEFT:
				    {collisionMap[tmp+j]=UNAVOIDABLE_AND_UNBREAKABLE_LEFT_RIGHT;
				     break;
				    }
				case UNAVOIDABLE_AND_UNBREAKABLE_UP_DOWN:
				    {collisionMap[tmp+j]=UNAVOIDABLE_AND_UNBREAKABLE_UP_DOWN_RIGHT;
				     break;
				    }
				case UNAVOIDABLE_AND_UNBREAKABLE_UP_LEFT:
				    {collisionMap[tmp+j]=UNAVOIDABLE_AND_UNBREAKABLE_UP_LEFT_RIGHT;
				     break;
				    }				
				case UNAVOIDABLE_AND_UNBREAKABLE_DOWN_LEFT:
				    {collisionMap[tmp+j]=UNAVOIDABLE_AND_UNBREAKABLE_DOWN_LEFT_RIGHT;
				     break;
				    }				
				case UNAVOIDABLE_AND_UNBREAKABLE_UP_DOWN_LEFT:
				    {collisionMap[tmp+j]=UNAVOIDABLE_AND_UNBREAKABLE_UP_DOWN_LEFT_RIGHT;
				     break;
				    }				   
			       }
			  }
		     }
	    }
        /*System.out.println("art count = "+pb);*/
	//write the correct data in the file
	try {File file=new File(tilesFilename);
	     if(!file.exists())
	         file.createNewFile();
	     /*for each point, associate the good texture coordinates*/   
	     //use DataOutputStream and writeInt() for the definitive implementation
	     DataOutputStream out=new DataOutputStream(new BufferedOutputStream(new FileOutputStream(file)));
	     //write the number of point of each entity (upper walls, lower walls, left side walls, right side walls, floor and ceil)
	     out.writeInt(topWallsList.size()*4);
	     out.writeInt(bottomWallsList.size()*4);
	     out.writeInt(leftWallsList.size()*4);
	     out.writeInt(rightWallsList.size()*4);
	     out.writeInt(floorTilesList.size()+specialFloorTilesList.size());
	     out.writeInt(ceilTilesList.size()+specialCeilTilesList.size());
             
	     //each tile contains a point
	     //count of tiles per element = 4
	     //count of elements per tile = 1/4
	     //count of elements = count of tiles / count of tiles per element
	     //count of tiles = count of subelements / count of subelements per tile
	     //count of subelements per tile = count of primitive per group (quad->4) * count of groups of primitive per element / count of tiles per element
	     out.writeInt(unbreakableObjectsTilesList.size()*8);//8 = 4 * 8 / 4
	     out.writeInt(vendingMachinesTilesList.size()*4);//4 = 4 * 4 / 4
	     out.writeInt(lampsTilesList.size()*2+chairsTilesList.size()*2+flowerPotsTilesList.size()*2+tablesTilesList.size()*2+bonsaiTreesTilesList.size()*2);
             //2 = 4 * 2 / 4

	     out.writeInt(artTopWallsList.size()*4);
	     out.writeInt(artBottomWallsList.size()*4);
	     out.writeInt(artLeftWallsList.size()*4);
	     out.writeInt(artRightWallsList.size()*4);
	     //use factor
	     //build upper walls (last, first) (y=-0.5 or 0.5)
             for(PointPair p:topWallsList)
	         {writeQuadPrimitive(out,0.0f,0.25f,(float)(factor*p.getLast().getX()),0.5f*factor,(float)(factor*p.getLast().getY()),
		                         0.0f,0.5f,(float)(factor*p.getLast().getX()),-0.5f*factor,(float)(factor*p.getLast().getY()),
		                         0.25f,0.5f,(float)(factor*p.getFirst().getX()),-0.5f*factor,(float)(factor*p.getFirst().getY()),
					 0.25f,0.25f,(float)(factor*p.getFirst().getX()),0.5f*factor,(float)(factor*p.getFirst().getY()));	       
		 }
	     //build lower walls (first, last) (y=-0.5 or 0.5)
             for(PointPair p:bottomWallsList)
	         {writeQuadPrimitive(out,0.0f,0.25f,(float)(factor*p.getFirst().getX()),0.5f*factor,(float)(factor*p.getFirst().getY()),
		                         0.0f,0.5f,(float)(factor*p.getFirst().getX()),-0.5f*factor,(float)(factor*p.getFirst().getY()),
		                         0.25f,0.5f,(float)(factor*p.getLast().getX()),-0.5f*factor,(float)(factor*p.getLast().getY()),
					 0.25f,0.25f,(float)(factor*p.getLast().getX()),0.5f*factor,(float)(factor*p.getLast().getY()));
		 }
	     //build left side walls (first, last) (y=-0.5 or 0.5)
             for(PointPair p:leftWallsList)
	         {writeQuadPrimitive(out,0.0f,0.25f,(float)(factor*p.getFirst().getX()),0.5f*factor,(float)(factor*p.getFirst().getY()),
		                         0.0f,0.5f,(float)(factor*p.getFirst().getX()),-0.5f*factor,(float)(factor*p.getFirst().getY()),
		                         0.25f,0.5f,(float)(factor*p.getLast().getX()),-0.5f*factor,(float)(factor*p.getLast().getY()),
					 0.25f,0.25f,(float)(factor*p.getLast().getX()),0.5f*factor,(float)(factor*p.getLast().getY()));		       
		 }
	     //build right side walls (last, first) (y=-0.5 or 0.5)
             for(PointPair p:rightWallsList)
	         {writeQuadPrimitive(out,0.0f,0.25f,(float)(factor*p.getLast().getX()),0.5f*factor,(float)(factor*p.getLast().getY()),
		                         0.0f,0.5f,(float)(factor*p.getLast().getX()),-0.5f*factor,(float)(factor*p.getLast().getY()),
		                         0.25f,0.5f,(float)(factor*p.getFirst().getX()),-0.5f*factor,(float)(factor*p.getFirst().getY()),
					 0.25f,0.25f,(float)(factor*p.getFirst().getX()),0.5f*factor,(float)(factor*p.getFirst().getY()));		       
		 }		    
	     //build floor and ceil (y=-0.5 on the floor, 0.5 on the ceiling)
	     int k=0;
	     for(Point p:floorTilesList)
		 {if(k%4==0)
		      writeTextureCoord(out,0.0f,0.75f);
		  else
		      if(k%4==1)
			  writeTextureCoord(out,0.0f,0.5f);
		      else
		          if(k%4==2)
			      writeTextureCoord(out,0.25f,0.5f);
			  else			     
			      writeTextureCoord(out,0.25f,0.75f);
		  k++;
		  //writeNormal(out,0.0f,1.0f,0.0f);
		  writePoint(out,factor*p.getX(),-0.5*factor,factor*p.getY());
		 }
	     k=0;
	     for(Point p:specialFloorTilesList)
		 {if(k%4==0)
		      writeTextureCoord(out,0.0f,0.75f);
		  else
		      if(k%4==1)
			  writeTextureCoord(out,0.0f,0.5f);
		      else
		          if(k%4==2)
			      writeTextureCoord(out,0.25f,0.5f);
			  else			     
			      writeTextureCoord(out,0.25f,0.75f);
		  k++;
		  //writeNormal(out,0.0f,1.0f,0.0f);
		  writePoint(out,factor*p.getX(),-0.5*factor,factor*p.getY());
		 }
	     k=0;
	     for(Point p:ceilTilesList)
	         {if(k%4==0)
		      writeTextureCoord(out,0,1);
		  else
		      if(k%4==1)
			  writeTextureCoord(out,0,0.75f);
		      else
		          if(k%4==2)
			      writeTextureCoord(out,0.25f,0.75f);
			  else			     
			      writeTextureCoord(out,0.25f,1);
		  k++;
		  //writeNormal(out,0.0f,-1.0f,0.0f);
		  writePoint(out,factor*p.getX(),0.5*factor,factor*p.getY());
		 }		  
	     k=0;
	     for(Point p:specialCeilTilesList)
	         {if(k%4==0)
		      writeTextureCoord(out,0.25f,1);
		  else
		      if(k%4==1)
			  writeTextureCoord(out,0.25f,0.75f);
		      else
		          if(k%4==2)
			      writeTextureCoord(out,0.5f,0.75f);
			  else			     
			      writeTextureCoord(out,0.5f,1);
		  k++;
		  //writeNormal(out,0.0f,-1.0f,0.0f);
		  writePoint(out,factor*p.getX(),0.5*factor,factor*p.getY());
		 }	     
             int artIndex=0;//index of the artworks to display
             int texturePos=0;//position inside the texture
             float x1,x2,y1,y2;//texture coordinates
             float q=1.0f/((float)artTextureSize);
	     //build upper walls (last, first) (y=-0.5 or 0.5)
             for(PointPair p:artTopWallsList)
	         {x1=texturePos%artTextureSize;
                  y2=artTextureSize-(texturePos/artTextureSize);
                  x2=x1+1;
                  y1=y2-1;                                  		  
		  writeQuadPrimitive(out,x2*q,y2*q,(float)(factor*p.getLast().getX()),0.5f*factor,(float)(factor*p.getLast().getY()),
		                         x2*q,y1*q,(float)(factor*p.getLast().getX()),-0.5f*factor,(float)(factor*p.getLast().getY()),
		                         x1*q,y1*q,(float)(factor*p.getFirst().getX()),-0.5f*factor,(float)(factor*p.getFirst().getY()),
					 x1*q,y2*q,(float)(factor*p.getFirst().getX()),0.5f*factor,(float)(factor*p.getFirst().getY()));		  		  		  
                  artIndex=(artIndex+1)%artCount;
                  texturePos=artIndex%artPerTexture;	       
		 }
	     //build lower walls (first, last) (y=-0.5 or 0.5)
             for(PointPair p:artBottomWallsList)
	         {x1=texturePos%artTextureSize;
                  y2=artTextureSize-(texturePos/artTextureSize);
                  x2=x1+1;
                  y1=y2-1;
		  writeQuadPrimitive(out,x1*q,y2*q,(float)(factor*p.getFirst().getX()),0.5f*factor,(float)(factor*p.getFirst().getY()),
		                         x1*q,y1*q,(float)(factor*p.getFirst().getX()),-0.5f*factor,(float)(factor*p.getFirst().getY()),
		                         x2*q,y1*q,(float)(factor*p.getLast().getX()),-0.5f*factor,(float)(factor*p.getLast().getY()),
					 x2*q,y2*q,(float)(factor*p.getLast().getX()),0.5f*factor,(float)(factor*p.getLast().getY()));
		               
                  artIndex=(artIndex+1)%artCount;
                  texturePos=artIndex%artPerTexture;                    	       
		 }
	     //build left side walls (first, last) (y=-0.5 or 0.5)
             for(PointPair p:artLeftWallsList)
	         {x1=texturePos%artTextureSize;
                  y2=artTextureSize-(texturePos/artTextureSize);
                  x2=x1+1;
                  y1=y2-1;                                   		  
		  writeQuadPrimitive(out,x1*q,y2*q,(float)(factor*p.getFirst().getX()),0.5f*factor,(float)(factor*p.getFirst().getY()),
		                         x1*q,y1*q,(float)(factor*p.getFirst().getX()),-0.5f*factor,(float)(factor*p.getFirst().getY()),
		                         x2*q,y1*q,(float)(factor*p.getLast().getX()),-0.5f*factor,(float)(factor*p.getLast().getY()),
					 x2*q,y2*q,(float)(factor*p.getLast().getX()),0.5f*factor,(float)(factor*p.getLast().getY()));		                     
                  artIndex=(artIndex+1)%artCount;
                  texturePos=artIndex%artPerTexture;	       
		 }
	     //build right side walls (last, first) (y=-0.5 or 0.5)
             for(PointPair p:artRightWallsList)
	         {x1=texturePos%artTextureSize;
                  y2=artTextureSize-(texturePos/artTextureSize);
                  x2=x1+1;
                  y1=y2-1;
		  writeQuadPrimitive(out,x2*q,y2*q,(float)(factor*p.getLast().getX()),0.5f*factor,(float)(factor*p.getLast().getY()),
		                         x2*q,y1*q,(float)(factor*p.getLast().getX()),-0.5f*factor,(float)(factor*p.getLast().getY()),
		                         x1*q,y1*q,(float)(factor*p.getFirst().getX()),-0.5f*factor,(float)(factor*p.getFirst().getY()),
					 x1*q,y2*q,(float)(factor*p.getFirst().getX()),0.5f*factor,(float)(factor*p.getFirst().getY()));		                       
                  artIndex=(artIndex+1)%artCount;
                  texturePos=artIndex%artPerTexture;	       
		 }		  		  
	     /*PointPair p;
	     for(k=0;k<unbreakableObjectsTilesList.size();k+=4)
		 {//build upper walls (last, first) (y=-0.5 or 0.5)
		  p=new PointPair(unbreakableObjectsTilesList.get(k),unbreakableObjectsTilesList.get(k+3));       	  
		  writeQuadPrimitive(out,0.0f,0.85f,(float)(factor*p.getLast().getX()),-0.1f*factor,(float)(factor*p.getLast().getY()),
		                         0.0f,0.75f,(float)(factor*p.getLast().getX()),-0.5f*factor,(float)(factor*p.getLast().getY()),
		                         0.25f,0.75f,(float)(factor*p.getFirst().getX()),-0.5f*factor,(float)(factor*p.getFirst().getY()),
					 0.25f,0.85f,(float)(factor*p.getFirst().getX()),-0.1f*factor,(float)(factor*p.getFirst().getY()));
		  //build lower walls (first, last) (y=-0.5 or 0.5)
		  p=new PointPair(unbreakableObjectsTilesList.get(k+1),unbreakableObjectsTilesList.get(k+2));       	  
		  writeQuadPrimitive(out,0.0f,0.85f,(float)(factor*p.getFirst().getX()),-0.1f*factor,(float)(factor*p.getFirst().getY()),
		                         0.0f,0.75f,(float)(factor*p.getFirst().getX()),-0.5f*factor,(float)(factor*p.getFirst().getY()),
		                         0.25f,0.75f,(float)(factor*p.getLast().getX()),-0.5f*factor,(float)(factor*p.getLast().getY()),
					 0.25f,0.85f,(float)(factor*p.getLast().getX()),-0.1f*factor,(float)(factor*p.getLast().getY()));
		  //build left side walls (first, last) (y=-0.5 or 0.5)
		  p=new PointPair(unbreakableObjectsTilesList.get(k),unbreakableObjectsTilesList.get(k+1));
		  writeQuadPrimitive(out,0.0f,0.85f,(float)(factor*p.getFirst().getX()),-0.1f*factor,(float)(factor*p.getFirst().getY()),
		                         0.0f,0.75f,(float)(factor*p.getFirst().getX()),-0.5f*factor,(float)(factor*p.getFirst().getY()),
		                         0.25f,0.75f,(float)(factor*p.getLast().getX()),-0.5f*factor,(float)(factor*p.getLast().getY()),
					 0.25f,0.85f,(float)(factor*p.getLast().getX()),-0.1f*factor,(float)(factor*p.getLast().getY()));		       
		  //build right side walls (last, first) (y=-0.5 or 0.5)
		  p=new PointPair(unbreakableObjectsTilesList.get(k+3),unbreakableObjectsTilesList.get(k+2));                  
		  writeQuadPrimitive(out,0.0f,0.85f,(float)(factor*p.getLast().getX()),-0.1f*factor,(float)(factor*p.getLast().getY()),
		                         0.0f,0.75f,(float)(factor*p.getLast().getX()),-0.5f*factor,(float)(factor*p.getLast().getY()),
		                         0.25f,0.75f,(float)(factor*p.getFirst().getX()),-0.5f*factor,(float)(factor*p.getFirst().getY()),
					 0.25f,0.85f,(float)(factor*p.getFirst().getX()),-0.1f*factor,(float)(factor*p.getFirst().getY()));
		  //build upper walls (last, first) (y=-0.5 or 0.5)
		  p=new PointPair(unbreakableObjectsTilesList.get(k+3),unbreakableObjectsTilesList.get(k));       	  
		  writeQuadPrimitive(out,0.0f,0.85f,(float)(factor*p.getLast().getX()),-0.1f*factor,(float)(factor*p.getLast().getY()),
		                         0.0f,0.75f,(float)(factor*p.getLast().getX()),-0.5f*factor,(float)(factor*p.getLast().getY()),
		                         0.25f,0.75f,(float)(factor*p.getFirst().getX()),-0.5f*factor,(float)(factor*p.getFirst().getY()),
					 0.25f,0.85f,(float)(factor*p.getFirst().getX()),-0.1f*factor,(float)(factor*p.getFirst().getY()));
		  //build lower walls (first, last) (y=-0.5 or 0.5)
		  p=new PointPair(unbreakableObjectsTilesList.get(k+2),unbreakableObjectsTilesList.get(k+1));       	  
		  writeQuadPrimitive(out,0.0f,0.85f,(float)(factor*p.getFirst().getX()),-0.1f*factor,(float)(factor*p.getFirst().getY()),
		                         0.0f,0.75f,(float)(factor*p.getFirst().getX()),-0.5f*factor,(float)(factor*p.getFirst().getY()),
		                         0.25f,0.75f,(float)(factor*p.getLast().getX()),-0.5f*factor,(float)(factor*p.getLast().getY()),
					 0.25f,0.85f,(float)(factor*p.getLast().getX()),-0.1f*factor,(float)(factor*p.getLast().getY()));
		  //build left side walls (first, last) (y=-0.5 or 0.5)
		  p=new PointPair(unbreakableObjectsTilesList.get(k+1),unbreakableObjectsTilesList.get(k));
		  writeQuadPrimitive(out,0.0f,0.85f,(float)(factor*p.getFirst().getX()),-0.1f*factor,(float)(factor*p.getFirst().getY()),
		                         0.0f,0.75f,(float)(factor*p.getFirst().getX()),-0.5f*factor,(float)(factor*p.getFirst().getY()),
		                         0.25f,0.75f,(float)(factor*p.getLast().getX()),-0.5f*factor,(float)(factor*p.getLast().getY()),
					 0.25f,0.85f,(float)(factor*p.getLast().getX()),-0.1f*factor,(float)(factor*p.getLast().getY()));		       
		  //build right side walls (last, first) (y=-0.5 or 0.5)
		  p=new PointPair(unbreakableObjectsTilesList.get(k+2),unbreakableObjectsTilesList.get(k+3));                  
		  writeQuadPrimitive(out,0.0f,0.85f,(float)(factor*p.getLast().getX()),-0.1f*factor,(float)(factor*p.getLast().getY()),
		                         0.0f,0.75f,(float)(factor*p.getLast().getX()),-0.5f*factor,(float)(factor*p.getLast().getY()),
		                         0.25f,0.75f,(float)(factor*p.getFirst().getX()),-0.5f*factor,(float)(factor*p.getFirst().getY()),
					 0.25f,0.85f,(float)(factor*p.getFirst().getX()),-0.1f*factor,(float)(factor*p.getFirst().getY()));		       		    
		 }
	     double X,Z;
	     for(k=0;k<vendingMachinesTilesList.size();k+=4)
		 {//build upper walls (last, first) (y=-0.5 or 0.5)		       
		  p=new PointPair(vendingMachinesTilesList.get(k),vendingMachinesTilesList.get(k+3));       	  
		  writeQuadPrimitive(out,0.58f,0.73f,(float)(factor*(p.getLast().getX()-0.3f)),0.5f*factor,(float)(factor*(p.getLast().getY()+0.3f)),
		                         0.58f,0.52f,(float)(factor*(p.getLast().getX()-0.3f)),-0.5f*factor,(float)(factor*(p.getLast().getY()+0.3f)),
		                         0.66f,0.52f,(float)(factor*(p.getFirst().getX()+0.3f)),-0.5f*factor,(float)(factor*(p.getFirst().getY()+0.3f)),
					 0.66f,0.73f,(float)(factor*(p.getFirst().getX()+0.3f)),0.5f*factor,(float)(factor*(p.getFirst().getY()+0.3f)));
		  //build lower walls (first, last) (y=-0.5 or 0.5)
		  p=new PointPair(vendingMachinesTilesList.get(k+1),vendingMachinesTilesList.get(k+2));        	  		  
		  writeQuadPrimitive(out,0.58f,0.73f,(float)(factor*(p.getFirst().getX()+0.3f)),0.5f*factor,(float)(factor*(p.getFirst().getY()-0.3f)),
		                         0.58f,0.52f,(float)(factor*(p.getFirst().getX()+0.3f)),-0.5f*factor,(float)(factor*(p.getFirst().getY()-0.3f)),
		                         0.66f,0.52f,(float)(factor*(p.getLast().getX()-0.3f)),-0.5f*factor,(float)(factor*(p.getLast().getY()-0.3f)),
					 0.66f,0.73f,(float)(factor*(p.getLast().getX()-0.3f)),0.5f*factor,(float)(factor*(p.getLast().getY()-0.3f)));
		  //build left side walls (first, last) (y=-0.5 or 0.5)
		  p=new PointPair(vendingMachinesTilesList.get(k),vendingMachinesTilesList.get(k+1));      	       	          		  
		  writeQuadPrimitive(out,0.58f,0.73f,(float)(factor*(p.getFirst().getX()+0.3f)),0.5f*factor,(float)(factor*(p.getFirst().getY()+0.3f)),
		                         0.58f,0.52f,(float)(factor*(p.getFirst().getX()+0.3f)),-0.5f*factor,(float)(factor*(p.getFirst().getY()+0.3f)),
		                         0.66f,0.52f,(float)(factor*(p.getLast().getX()+0.3f)),-0.5f*factor,(float)(factor*(p.getLast().getY()-0.3f)),
					 0.66f,0.73f,(float)(factor*(p.getLast().getX()+0.3f)),0.5f*factor,(float)(factor*(p.getLast().getY()-0.3f)));	       
		  //build right side walls (last, first) (y=-0.5 or 0.5)
		  p=new PointPair(vendingMachinesTilesList.get(k+3),vendingMachinesTilesList.get(k+2));                  		  
		  writeQuadPrimitive(out,0.58f,0.73f,(float)(factor*(p.getLast().getX()-0.3f)),0.5f*factor,(float)(factor*(p.getLast().getY()-0.3f)),
		                         0.58f,0.52f,(float)(factor*(p.getLast().getX()-0.3f)),-0.5f*factor,(float)(factor*(p.getLast().getY()-0.3f)),
		                         0.66f,0.52f,(float)(factor*(p.getFirst().getX()-0.3f)),-0.5f*factor,(float)(factor*(p.getFirst().getY()+0.3f)),
					 0.66f,0.73f,(float)(factor*(p.getFirst().getX()-0.3f)),0.5f*factor,(float)(factor*(p.getFirst().getY()+0.3f)));		       		    
		 }	  
	     for(k=0;k<lampsTilesList.size();k+=4)
		 {Z=factor*(lampsTilesList.get(k).getY()+0.5f);
		  X=factor*lampsTilesList.get(k).getX();		  		  
		  writeQuadPrimitive(out,0.25f,1.0f,(float)X,0.5f*factor,(float)Z,
		                         0.25f,0.75f,(float)X,-0.5f*factor,(float)Z,
		                         0.5f,0.75f,(float)X+factor,-0.5f*factor,(float)Z,
					 0.5f,1.0f,(float)X+factor,0.5f*factor,(float)Z);  
		  writeQuadPrimitive(out,0.25f,1.0f,(float)X+factor,0.5f*factor,(float)Z,
		                         0.25f,0.75f,(float)X+factor,-0.5f*factor,(float)Z,
		                         0.5f,0.75f,(float)X,-0.5f*factor,(float)Z,
					 0.5f,1.0f,(float)X,0.5f*factor,(float)Z);		       
		 }
	     for(k=0;k<chairsTilesList.size();k+=4)
		 {Z=factor*(chairsTilesList.get(k).getY()+0.5f);
		  X=factor*chairsTilesList.get(k).getX();		  		  
		  writeQuadPrimitive(out,0.5f,1.0f,(float)X,0.5f*factor,(float)Z,
		                         0.5f,0.75f,(float)X,-0.5f*factor,(float)Z,
		                         0.75f,0.75f,(float)X+factor,-0.5f*factor,(float)Z,
					 0.75f,1.0f,(float)X+factor,0.5f*factor,(float)Z);  
		  writeQuadPrimitive(out,0.5f,1.0f,(float)X+factor,0.5f*factor,(float)Z,
		                         0.5f,0.75f,(float)X+factor,-0.5f*factor,(float)Z,
		                         0.75f,0.75f,(float)X,-0.5f*factor,(float)Z,
					 0.75f,1.0f,(float)X,0.5f*factor,(float)Z);				       
		 }			      
	     for(k=0;k<flowerPotsTilesList.size();k+=4)
		 {Z=factor*(flowerPotsTilesList.get(k).getY()+0.5f);
		  X=factor*flowerPotsTilesList.get(k).getX();		  		  		
		  writeQuadPrimitive(out,0.0f,0.75f,(float)X,0.5f*factor,(float)Z,
		                         0.0f,0.5f,(float)X,-0.5f*factor,(float)Z,
		                         0.25f,0.5f,(float)X+factor,-0.5f*factor,(float)Z,
					 0.25f,0.75f,(float)X+factor,0.5f*factor,(float)Z);  
		  writeQuadPrimitive(out,0.0f,0.75f,(float)X+factor,0.5f*factor,(float)Z,
		                         0.0f,0.5f,(float)X+factor,-0.5f*factor,(float)Z,
		                         0.25f,0.5f,(float)X,-0.5f*factor,(float)Z,
					 0.25f,0.75f,(float)X,0.5f*factor,(float)Z);		       
		 }
	     for(k=0;k<tablesTilesList.size();k+=4)
		 {Z=factor*(tablesTilesList.get(k).getY()+0.5f);
		  X=factor*tablesTilesList.get(k).getX();		  		  
		  writeQuadPrimitive(out,0.25f,0.75f,(float)X,0.5f*factor,(float)Z,
		                         0.25f,0.5f,(float)X,-0.5f*factor,(float)Z,
		                         0.5f,0.5f,(float)X+factor,-0.5f*factor,(float)Z,
					 0.5f,0.75f,(float)X+factor,0.5f*factor,(float)Z);  
		  writeQuadPrimitive(out,0.25f,0.75f,(float)X+factor,0.5f*factor,(float)Z,
		                         0.25f,0.5f,(float)X+factor,-0.5f*factor,(float)Z,
		                         0.5f,0.5f,(float)X,-0.5f*factor,(float)Z,
					 0.5f,0.75f,(float)X,0.5f*factor,(float)Z);		       
		 }		  			    	     
	     for(k=0;k<bonsaiTreesTilesList.size();k+=4)
		 {Z=factor*(bonsaiTreesTilesList.get(k).getY()+0.5f);
		  X=factor*bonsaiTreesTilesList.get(k).getX();		  
		  writeQuadPrimitive(out,0.0f,0.5f,(float)X,0.5f*factor,(float)Z,
		                         0.0f,0.25f,(float)X,-0.5f*factor,(float)Z,
		                         0.25f,0.25f,(float)X+factor,-0.5f*factor,(float)Z,
					 0.25f,0.5f,(float)X+factor,0.5f*factor,(float)Z);  
		  writeQuadPrimitive(out,0.0f,0.5f,(float)X+factor,0.5f*factor,(float)Z,
		                         0.0f,0.25f,(float)X+factor,-0.5f*factor,(float)Z,
		                         0.25f,0.25f,(float)X,-0.5f*factor,(float)Z,
					 0.25f,0.5f,(float)X,0.5f*factor,(float)Z);		       
		 }
	     */
	     //write the collision map
	     out.write(collisionMap,0,65536);     
	     //TODO : put the initial point
         //TODO : put the respawn points
         //TODO : put the crosshair coordinates
	     //write the animations of the bot
	     //animation n 0
	     //frame n 0
	     writeQuadPrimitive(out,0.0f,1.0f,-0.5f*factor,0.5f*factor,0.0f,
		                    0.0f,0.75f,-0.5f*factor,-0.5f*factor,0.0f,
		                    0.25f,0.75f,0.5f*factor,-0.5f*factor,0.0f,
				    0.25f,1.0f,0.5f*factor,0.5f*factor,0.0f);
	     //frame n 1
	     writeQuadPrimitive(out,0.25f,1.0f,-0.5f*factor,0.5f*factor,0.0f,
		                    0.25f,0.75f,-0.5f*factor,-0.5f*factor,0.0f,
		                    0.5f,0.75f,0.5f*factor,-0.5f*factor,0.0f,
				    0.5f,1.0f,0.5f*factor,0.5f*factor,0.0f);
	     //frame n 2
	     writeQuadPrimitive(out,0.5f,1.0f,-0.5f*factor,0.5f*factor,0.0f,
		                    0.5f,0.75f,-0.5f*factor,-0.5f*factor,0.0f,
		                    0.75f,0.75f,0.5f*factor,-0.5f*factor,0.0f,
				    0.75f,1.0f,0.5f*factor,0.5f*factor,0.0f);
	     //frame n 3
	     writeQuadPrimitive(out,0.75f,1.0f,-0.5f*factor,0.5f*factor,0.0f,
		                    0.75f,0.75f,-0.5f*factor,-0.5f*factor,0.0f,
		                    1.0f,0.75f,0.5f*factor,-0.5f*factor,0.0f,
				    1.0f,1.0f,0.5f*factor,0.5f*factor,0.0f);
	     //frame n 4
	     writeQuadPrimitive(out,0.0f,0.75f,-0.5f*factor,0.5f*factor,0.0f,
		                    0.0f,0.5f,-0.5f*factor,-0.5f*factor,0.0f,
		                    0.25f,0.5f,0.5f*factor,-0.5f*factor,0.0f,
				    0.25f,0.75f,0.5f*factor,0.5f*factor,0.0f);
	     //frame n 5
	     writeQuadPrimitive(out,0.25f,0.75f,-0.5f*factor,0.5f*factor,0.0f,
		                    0.25f,0.5f,-0.5f*factor,-0.5f*factor,0.0f,
		                    0.5f,0.5f,0.5f*factor,-0.5f*factor,0.0f,
				    0.5f,0.75f,0.5f*factor,0.5f*factor,0.0f);
	     //frame n 6
	     writeQuadPrimitive(out,0.5f,0.75f,-0.5f*factor,0.5f*factor,0.0f,
		                    0.5f,0.5f,-0.5f*factor,-0.5f*factor,0.0f,
		                    0.75f,0.5f,0.5f*factor,-0.5f*factor,0.0f,
				    0.75f,0.75f,0.5f*factor,0.5f*factor,0.0f);
	     //frame n 7
	     writeQuadPrimitive(out,0.75f,0.75f,-0.5f*factor,0.5f*factor,0.0f,
		                    0.75f,0.5f,-0.5f*factor,-0.5f*factor,0.0f,
		                    1.0f,0.5f,0.5f*factor,-0.5f*factor,0.0f,
				    1.0f,0.75f,0.5f*factor,0.5f*factor,0.0f);
	     //frame n 8
	     writeQuadPrimitive(out,0.0f,0.5f,-0.5f*factor,0.5f*factor,0.0f,
		                    0.0f,0.25f,-0.5f*factor,-0.5f*factor,0.0f,
		                    0.25f,0.25f,0.5f*factor,-0.5f*factor,0.0f,
				    0.25f,0.5f,0.5f*factor,0.5f*factor,0.0f);
	     //frame n 9
	     writeQuadPrimitive(out,0.25f,0.5f,-0.5f*factor,0.5f*factor,0.0f,
		                    0.25f,0.25f,-0.5f*factor,-0.5f*factor,0.0f,
		                    0.5f,0.25f,0.5f*factor,-0.5f*factor,0.0f,
				    0.5f,0.5f,0.5f*factor,0.5f*factor,0.0f);
	     //frame n 10
	     writeQuadPrimitive(out,0.5f,0.5f,-0.5f*factor,0.5f*factor,0.0f,
		                    0.5f,0.25f,-0.5f*factor,-0.5f*factor,0.0f,
		                    0.75f,0.25f,0.5f*factor,-0.5f*factor,0.0f,
				    0.75f,0.5f,0.5f*factor,0.5f*factor,0.0f);	    
	     //animation n 1
	     //frame n 0
	     writeQuadPrimitive(out,0.0f,1.0f,-0.5f*factor,0.5f*factor,0.0f,
		                    0.0f,0.75f,-0.5f*factor,-0.5f*factor,0.0f,
		                    0.25f,0.75f,0.5f*factor,-0.5f*factor,0.0f,
				    0.25f,1.0f,0.5f*factor,0.5f*factor,0.0f);
	     //frame n 1
	     writeQuadPrimitive(out,0.25f,1.0f,-0.5f*factor,0.5f*factor,0.0f,
		                    0.25f,0.75f,-0.5f*factor,-0.5f*factor,0.0f,
		                    0.5f,0.75f,0.5f*factor,-0.5f*factor,0.0f,
				    0.5f,1.0f,0.5f*factor,0.5f*factor,0.0f);
	     //frame n 2
	     writeQuadPrimitive(out,0.5f,1.0f,-0.5f*factor,0.5f*factor,0.0f,
		                    0.5f,0.75f,-0.5f*factor,-0.5f*factor,0.0f,
		                    0.75f,0.75f,0.5f*factor,-0.5f*factor,0.0f,
				    0.75f,1.0f,0.5f*factor,0.5f*factor,0.0f);
	     //frame n 3
	     writeQuadPrimitive(out,0.75f,1.0f,-0.5f*factor,0.5f*factor,0.0f,
		                    0.75f,0.75f,-0.5f*factor,-0.5f*factor,0.0f,
		                    1.0f,0.75f,0.5f*factor,-0.5f*factor,0.0f,
				    1.0f,1.0f,0.5f*factor,0.5f*factor,0.0f);
	     //frame n 4
	     writeQuadPrimitive(out,0.0f,0.75f,-0.5f*factor,0.5f*factor,0.0f,
		                    0.0f,0.5f,-0.5f*factor,-0.5f*factor,0.0f,
		                    0.25f,0.5f,0.5f*factor,-0.5f*factor,0.0f,
				    0.25f,0.75f,0.5f*factor,0.5f*factor,0.0f);
	     //frame n 5
	     writeQuadPrimitive(out,0.25f,0.75f,-0.5f*factor,0.5f*factor,0.0f,
		                    0.25f,0.5f,-0.5f*factor,-0.5f*factor,0.0f,
		                    0.5f,0.5f,0.5f*factor,-0.5f*factor,0.0f,
				    0.5f,0.75f,0.5f*factor,0.5f*factor,0.0f);
	     //frame n 6
	     writeQuadPrimitive(out,0.5f,0.75f,-0.5f*factor,0.5f*factor,0.0f,
		                    0.5f,0.5f,-0.5f*factor,-0.5f*factor,0.0f,
		                    0.75f,0.5f,0.5f*factor,-0.5f*factor,0.0f,
				    0.75f,0.75f,0.5f*factor,0.5f*factor,0.0f);
	     //frame n 7
	     writeQuadPrimitive(out,0.75f,0.75f,-0.5f*factor,0.5f*factor,0.0f,
		                    0.75f,0.5f,-0.5f*factor,-0.5f*factor,0.0f,
		                    1.0f,0.5f,0.5f*factor,-0.5f*factor,0.0f,
				    1.0f,0.75f,0.5f*factor,0.5f*factor,0.0f);
	     //frame n 8
	     writeQuadPrimitive(out,0.0f,0.5f,-0.5f*factor,0.5f*factor,0.0f,
		                    0.0f,0.25f,-0.5f*factor,-0.5f*factor,0.0f,
		                    0.25f,0.25f,0.5f*factor,-0.5f*factor,0.0f,
				    0.25f,0.5f,0.5f*factor,0.5f*factor,0.0f);
	     //frame n 9
	     writeQuadPrimitive(out,0.25f,0.5f,-0.5f*factor,0.5f*factor,0.0f,
		                    0.25f,0.25f,-0.5f*factor,-0.5f*factor,0.0f,
		                    0.5f,0.25f,0.5f*factor,-0.5f*factor,0.0f,
				    0.5f,0.5f,0.5f*factor,0.5f*factor,0.0f);
	     //frame n 10
	     writeQuadPrimitive(out,0.5f,0.5f,-0.5f*factor,0.5f*factor,0.0f,
		                    0.5f,0.25f,-0.5f*factor,-0.5f*factor,0.0f,
		                    0.75f,0.25f,0.5f*factor,-0.5f*factor,0.0f,
				    0.75f,0.5f,0.5f*factor,0.5f*factor,0.0f);	 
	     //write the animation of the unbreakable object
	     //animation n 0
	     //frame n 0
	     //build upper walls    	  
	     writeQuadPrimitive(out,0.0f,0.85f,0.5f*factor,-0.1f*factor,-0.5f*factor,
		                    0.0f,0.75f,0.5f*factor,-0.5f*factor,-0.5f*factor,
		                    0.25f,0.75f,-0.5f*factor,-0.5f*factor,-0.5f*factor,
				    0.25f,0.85f,-0.5f*factor,-0.1f*factor,-0.5f*factor);
	     //build lower walls          	  
	     writeQuadPrimitive(out,0.0f,0.85f,-0.5f*factor,-0.1f*factor,0.5f*factor,
		                    0.0f,0.75f,-0.5f*factor,-0.5f*factor,0.5f*factor,
		                    0.25f,0.75f,0.5f*factor,-0.5f*factor,0.5f*factor,
				    0.25f,0.85f,0.5f*factor,-0.1f*factor,0.5f*factor);
	     //build left side walls	     
	     writeQuadPrimitive(out,0.0f,0.85f,-0.5f*factor,-0.1f*factor,-0.5f*factor,
		                    0.0f,0.75f,-0.5f*factor,-0.5f*factor,-0.5f*factor,
		                    0.25f,0.75f,-0.5f*factor,-0.5f*factor,0.5f*factor,
				    0.25f,0.85f,-0.5f*factor,-0.1f*factor,0.5f*factor);		       
	     //build right side walls                  
	     writeQuadPrimitive(out,0.0f,0.85f,0.5f*factor,-0.1f*factor,0.5f*factor,
		                    0.0f,0.75f,0.5f*factor,-0.5f*factor,0.5f*factor,
		                    0.25f,0.75f,0.5f*factor,-0.5f*factor,-0.5f*factor,
				    0.25f,0.85f,0.5f*factor,-0.1f*factor,-0.5f*factor);
	     //build upper walls         	  
	     writeQuadPrimitive(out,0.0f,0.85f,-0.5f*factor,-0.1f*factor,-0.5f*factor,
		                    0.0f,0.75f,-0.5f*factor,-0.5f*factor,-0.5f*factor,
		                    0.25f,0.75f,0.5f*factor,-0.5f*factor,-0.5f*factor,
				    0.25f,0.85f,0.5f*factor,-0.1f*factor,-0.5f*factor);
	     //build lower walls	           	  
	     writeQuadPrimitive(out,0.0f,0.85f,0.5f*factor,-0.1f*factor,0.5f*factor,
		                    0.0f,0.75f,0.5f*factor,-0.5f*factor,0.5f*factor,
		                    0.25f,0.75f,-0.5f*factor,-0.5f*factor,0.5f*factor,
				    0.25f,0.85f,-0.5f*factor,-0.1f*factor,0.5f*factor);
	     //build left side walls
	     writeQuadPrimitive(out,0.0f,0.85f,-0.5f*factor,-0.1f*factor,0.5f*factor,
		                    0.0f,0.75f,-0.5f*factor,-0.5f*factor,0.5f*factor,
		                    0.25f,0.75f,-0.5f*factor,-0.5f*factor,-0.5f*factor,
				    0.25f,0.85f,-0.5f*factor,-0.1f*factor,-0.5f*factor);		       
	     //build right side walls               
	     writeQuadPrimitive(out,0.0f,0.85f,0.5f*factor,-0.1f*factor,-0.5f*factor,
		                    0.0f,0.75f,0.5f*factor,-0.5f*factor,-0.5f*factor,
		                    0.25f,0.75f,0.5f*factor,-0.5f*factor,0.5f*factor,
				    0.25f,0.85f,0.5f*factor,-0.1f*factor,0.5f*factor);
	     //write the animations of the vending machine
	     //animation n 0
	     //frame n 0
	     //build upper walls	              	  
	     writeQuadPrimitive(out,0.58f,0.73f,0.2f*factor,0.5f*factor,-0.2f*factor,
		                    0.58f,0.52f,0.2f*factor,-0.5f*factor,-0.2f*factor,
		                    0.66f,0.52f,-0.2f*factor,-0.5f*factor,-0.2f*factor,
				    0.66f,0.73f,-0.2f*factor,0.5f*factor,-0.2f*factor);
	     //build lower walls	          	  		  
	     writeQuadPrimitive(out,0.58f,0.73f,-0.2f*factor,0.5f*factor,0.2f*factor,
		                    0.58f,0.52f,-0.2f*factor,-0.5f*factor,0.2f*factor,
		                    0.66f,0.52f,0.2f*factor,-0.5f*factor,0.2f*factor,
				    0.66f,0.73f,0.2f*factor,0.5f*factor,0.2f*factor);
	     //build left side walls	        	       	          		  
	     writeQuadPrimitive(out,0.58f,0.73f,-0.2f*factor,0.5f*factor,-0.2f*factor,
		                    0.58f,0.52f,-0.2f*factor,-0.5f*factor,-0.2f*factor,
		                    0.66f,0.52f,-0.2f*factor,-0.5f*factor,0.2f*factor,
				    0.66f,0.73f,-0.2f*factor,0.5f*factor,0.2f*factor);	       
	     //build right side walls	                      		  
	     writeQuadPrimitive(out,0.58f,0.73f,0.2f*factor,0.5f*factor,0.2f*factor,
		                    0.58f,0.52f,0.2f*factor,-0.5f*factor,0.2f*factor,
		                    0.66f,0.52f,0.2f*factor,-0.5f*factor,-0.2f*factor,
				    0.66f,0.73f,0.2f*factor,0.5f*factor,-0.2f*factor);
	     //write the animation of the lamp
	     //animation n 0
	     //frame n 0	     		  		  
	     writeQuadPrimitive(out,0.25f,1.0f,-0.5f*factor,0.5f*factor,0.0f,
		                    0.25f,0.75f,-0.5f*factor,-0.5f*factor,0.0f,
		                    0.5f,0.75f,0.5f*factor,-0.5f*factor,0.0f,
				    0.5f,1.0f,0.5f*factor,0.5f*factor,0.0f);  
	     writeQuadPrimitive(out,0.25f,1.0f,0.5f*factor,0.5f*factor,0.0f,
		                    0.25f,0.75f,0.5f*factor,-0.5f*factor,0.0f,
		                    0.5f,0.75f,-0.5f*factor,-0.5f*factor,0.0f,
				    0.5f,1.0f,-0.5f*factor,0.5f*factor,0.0f);
	     //write the animation of the chair
	     //animation n 0
	     //frame n 0	     		  		  
	     writeQuadPrimitive(out,0.5f,1.0f,-0.5f*factor,0.5f*factor,0.0f,
		                    0.5f,0.75f,-0.5f*factor,-0.5f*factor,0.0f,
		                    0.75f,0.75f,0.5f*factor,-0.5f*factor,0.0f,
				    0.75f,1.0f,0.5f*factor,0.5f*factor,0.0f);  
	     writeQuadPrimitive(out,0.5f,1.0f,0.5f*factor,0.5f*factor,0.0f,
		                    0.5f,0.75f,0.5f*factor,-0.5f*factor,0.0f,
		                    0.75f,0.75f,-0.5f*factor,-0.5f*factor,0.0f,
				    0.75f,1.0f,-0.5f*factor,0.5f*factor,0.0f);
	     //write the animation of the flower
	     //animation n 0
	     //frame n 0	     		  		  		
	     writeQuadPrimitive(out,0.0f,0.75f,-0.5f*factor,0.5f*factor,0.0f,
		                    0.0f,0.5f,-0.5f*factor,-0.5f*factor,0.0f,
		                    0.25f,0.5f,0.5f*factor,-0.5f*factor,0.0f,
				    0.25f,0.75f,0.5f*factor,0.5f*factor,0.0f);  
	     writeQuadPrimitive(out,0.0f,0.75f,0.5f*factor,0.5f*factor,0.0f,
		                    0.0f,0.5f,0.5f*factor,-0.5f*factor,0.0f,
		                    0.25f,0.5f,-0.5f*factor,-0.5f*factor,0.0f,
				    0.25f,0.75f,-0.5f*factor,0.5f*factor,0.0f);
	     //write the animation of the table
	     //animation n 0
	     //frame n 0		  		  
	     writeQuadPrimitive(out,0.25f,0.75f,-0.5f*factor,0.5f*factor,0.0f,
		                    0.25f,0.5f,-0.5f*factor,-0.5f*factor,0.0f,
		                    0.5f,0.5f,0.5f*factor,-0.5f*factor,0.0f,
				    0.5f,0.75f,0.5f*factor,0.5f*factor,0.0f);  
	     writeQuadPrimitive(out,0.25f,0.75f,0.5f*factor,0.5f*factor,0.0f,
		                    0.25f,0.5f,0.5f*factor,-0.5f*factor,0.0f,
		                    0.5f,0.5f,-0.5f*factor,-0.5f*factor,0.0f,
				    0.5f,0.75f,-0.5f*factor,0.5f*factor,0.0f);
	     //write the animation of the bonsai
	     //animation n 0
	     //frame n 0	     		  
	     writeQuadPrimitive(out,0.0f,0.5f,-0.5f*factor,0.5f*factor,0.0f,
		                    0.0f,0.25f,-0.5f*factor,-0.5f*factor,0.0f,
		                    0.25f,0.25f,0.5f*factor,-0.5f*factor,0.0f,
				    0.25f,0.5f,0.5f*factor,0.5f*factor,0.0f);  
	     writeQuadPrimitive(out,0.0f,0.5f,0.5f*factor,0.5f*factor,0.0f,
		                    0.0f,0.25f,0.5f*factor,-0.5f*factor,0.0f,
		                    0.25f,0.25f,-0.5f*factor,-0.5f*factor,0.0f,
				    0.25f,0.5f,-0.5f*factor,0.5f*factor,0.0f);	
	     //write the animation of the walls
	     //animation n 0
	     //frame n 0
	     //build upper walls (last, first) (y=-0.5 or 0.5)            
	     writeQuadPrimitive(out,0.0f,0.25f,0.5f*factor,0.5f*factor,0.0f,
		                    0.0f,0.5f,0.5f*factor,-0.5f*factor,0.0f,
		                    0.25f,0.5f,-0.5f*factor,-0.5f*factor,0.0f,
				    0.25f,0.25f,-0.5f*factor,0.5f*factor,0.0f);
	     //build lower walls (first, last) (y=-0.5 or 0.5)            
	     writeQuadPrimitive(out,0.0f,0.25f,-0.5f*factor,0.5f*factor,0.0f,
		                    0.0f,0.5f,-0.5f*factor,-0.5f*factor,0.0f,
		                    0.25f,0.5f,0.5f*factor,-0.5f*factor,0.0f,
				    0.25f,0.25f,0.5f*factor,0.5f*factor,0.0f);
	     //build left side walls (first, last) (y=-0.5 or 0.5)             
	     writeQuadPrimitive(out,0.0f,0.25f,0.0f,0.5f*factor,-0.5f*factor,
		                    0.0f,0.5f,0.0f,-0.5f*factor,-0.5f*factor,
		                    0.25f,0.5f,0.0f,-0.5f*factor,0.5f*factor,
				    0.25f,0.25f,0.0f,0.5f*factor,0.5f*factor);
	     //build right side walls (last, first) (y=-0.5 or 0.5)            	
	     writeQuadPrimitive(out,0.0f,0.25f,0.0f,0.5f*factor,0.5f*factor,
		                    0.0f,0.5f,0.0f,-0.5f*factor,0.5f*factor,
		                    0.25f,0.5f,0.0f,-0.5f*factor,-0.5f*factor,
				    0.25f,0.25f,0.0f,0.5f*factor,-0.5f*factor);	  
	     //write the animation of the ceil
	     //animation n 0
	     //frame n 0
	     writeQuadPrimitive(out,0.0f,1.0f,0.5f*factor,0.0f,0.5f*factor,
		                    0.0f,0.75f,-0.5f*factor,0.0f,0.5f*factor,
		                    0.25f,0.75f,-0.5f*factor,0.0f,-0.5f*factor,
				    0.25f,1.0f,0.5f*factor,0.0f,-0.5f*factor);	 
	     //write the animation of the floor
	     //animation n 0
	     //frame n 0
	     writeQuadPrimitive(out,0.0f,0.75f,0.5f*factor,0.0f,-0.5f*factor,
		                    0.0f,0.5f,-0.5f*factor,0.0f,-0.5f*factor,
		                    0.25f,0.5f,-0.5f*factor,0.0f,0.5f*factor,
				    0.25f,0.75f,0.5f*factor,0.0f,0.5f*factor);	     
	     //TODO : rotate it by 180 degrees
	     //write the animation of the dirty walls
	     //animation n 0
	     //frame n 0
	     //build upper walls (last, first) (y=-0.5 or 0.5)            
	     writeQuadPrimitive(out,0.25f,0.25f,0.5f*factor,0.5f*factor,0.0f,
		                    0.25f,0.0f,0.5f*factor,-0.5f*factor,0.0f,
		                    0.0f,0.0f,-0.5f*factor,-0.5f*factor,0.0f,
				    0.0f,0.25f,-0.5f*factor,0.5f*factor,0.0f);
	     //build lower walls (first, last) (y=-0.5 or 0.5)            
	     writeQuadPrimitive(out,0.25f,0.25f,-0.5f*factor,0.5f*factor,0.0f,
		                    0.25f,0.0f,-0.5f*factor,-0.5f*factor,0.0f,
		                    0.0f,0.0f,0.5f*factor,-0.5f*factor,0.0f,
				    0.0f,0.25f,0.5f*factor,0.5f*factor,0.0f);
	         //build left side walls (first, last) (y=-0.5 or 0.5)             
	         writeQuadPrimitive(out,0.25f,0.25f,0.0f,0.5f*factor,-0.5f*factor,
		                    0.25f,0.0f,0.0f,-0.5f*factor,-0.5f*factor,
		                    0.0f,0.0f,0.0f,-0.5f*factor,0.5f*factor,
				    0.0f,0.25f,0.0f,0.5f*factor,0.5f*factor);
	         //build right side walls (last, first) (y=-0.5 or 0.5)            	
	         writeQuadPrimitive(out,0.25f,0.25f,0.0f,0.5f*factor,0.5f*factor,
		                    0.25f,0.0f,0.0f,-0.5f*factor,0.5f*factor,
		                    0.0f,0.0f,0.0f,-0.5f*factor,-0.5f*factor,
				    0.0f,0.25f,0.0f,0.5f*factor,-0.5f*factor);		     	         
	         out.flush();
             out.close();    
             //put the data of the rocket launcher in a separate file
             file=new File(rocketLauncherFilename);
             if(!file.exists())
                 file.createNewFile();
             out=new DataOutputStream(new BufferedOutputStream(new FileOutputStream(file)));        
             writeRocketLauncher(out,15.0f);	               
             out.flush();
             out.close();
             //put the pixmap of the worldmap in a separate file
             file=new File(binaryMapFilename);
             if(!file.exists())
                 file.createNewFile();
             out=new DataOutputStream(new BufferedOutputStream(new FileOutputStream(file)));
             for(int i=0;i<worldMap.length;i++)
                 out.writeInt(worldMap[i]);
             out.flush();
             out.close();
	        }
	     catch(IOException ioe)
	     {ioe.printStackTrace();}
	     //handle all kinds of walls together
	     /*leftWallsList.addAll(artLeftWallsList);
	     rightWallsList.addAll(artRightWallsList);
	     topWallsList.addAll(artTopWallsList);
	     bottomWallsList.addAll(artBottomWallsList);	     
	     //the cells generator uses a cartesian reference mark
	     //whereas the tiles generator inverts left and right
	     //that is why you have to invert it
	     CellsGenerator.generate(topWallsList,bottomWallsList,rightWallsList,leftWallsList);*/
    }      
    
    
    public static void writeNormal(DataOutputStream out,float nx,float ny,float nz)throws IOException{
        out.writeFloat(nx);
	    out.writeFloat(ny);
	    out.writeFloat(nz);	
    }
    
    public static void writePoint(DataOutputStream out,float x,float y,float z)throws IOException{
        out.writeFloat(x);
	    out.writeFloat(y);
	    out.writeFloat(z);	
    }
    
    public static void writePoint(DataOutputStream out,double x,double y,double z)throws IOException{
        writePoint(out,(float)x,(float)y,(float)z);
    }
    
    public static void writeTextureCoord(DataOutputStream out,float u,float v)throws IOException{
        out.writeFloat(u);
	    out.writeFloat(v);		
    }
    
    public static void writePrimitive(DataOutputStream out,float u,float v,float nx,float ny,float nz,float x,float y,float z)throws IOException{
        writeTextureCoord(out,u,v);
	    //writeNormal(out,nx,ny,nz);
	    writePoint(out,x,y,z);
    }
    
    public static void writeQuadPrimitive(DataOutputStream out,float u1,float v1,float x1,float y1,float z1,
                                                               float u2,float v2,float x2,float y2,float z2,
							       float u3,float v3,float x3,float y3,float z3,
							       float u4,float v4,float x4,float y4,float z4)throws IOException{
        float[] n=getQuadNormal(x1,y1,z1,x2,y2,z2,x3,y3,z3,x4,y4,z4);	
	    writePrimitive(out,u1,v1,n[0],n[1],n[2],x1,y1,z1);
	    writePrimitive(out,u2,v2,n[0],n[1],n[2],x2,y2,z2);
	    writePrimitive(out,u3,v3,n[0],n[1],n[2],x3,y3,z3);
	    writePrimitive(out,u4,v4,n[0],n[1],n[2],x4,y4,z4);
    }
    
    public static float[] getQuadNormal(float x1,float y1,float z1,float x2,float y2,float z2,float x3,float y3,float z3,float x4,float y4,float z4){
        float[] normal=new float[3];
	    //compute the normal
	
	    //normalize it
        
	    return(normal);
    }
       
    /**
     * write the coordinates to draw a regular octagon centered on zero
     * @param out : stream to write the data
     * @param inradius : inradius of the octagon
     * @param z : z coordinate of the octagon
     * @param u1
     * @param v1
     * @param u2
     * @param v2
     * @param u3
     * @param v3
     * @param u4
     * @param v4
     * @param u5
     * @param v5
     * @param u6
     * @param v6
     * @param u7
     * @param v7
     * @param u8
     * @param v8
     */
    public static float[][] writeZeroCenteredRegularOctagon(DataOutputStream out,float inradius,float z,
    		float u1,float v1,float u2,float v2,float u3,float v3,float u4,float v4,
    		float u5,float v5,float u6,float v6,float u7,float v7,float u8,float v8)throws IOException{
    	float[][] pArray=computeZeroCenteredRegularOctagon(inradius,z);
    	final float[] p1=pArray[0];
    	final float[] p2=pArray[1];
    	final float[] p3=pArray[2];
    	final float[] p4=pArray[3];
    	final float[] p5=pArray[4];
    	final float[] p6=pArray[5];
    	final float[] p7=pArray[6];
    	final float[] p8=pArray[7];
    	writeQuadPrimitive(out,u1,v1,p1[0],p1[1],p1[2],u2,v2,p2[0],p2[1],p2[2],u3,v3,p3[0],p3[1],p3[2],u4,v4,p4[0],p4[1],p4[2]);
    	writeQuadPrimitive(out,u1,v1,p1[0],p1[1],p1[2],u4,v4,p4[0],p4[1],p4[2],u5,v5,p5[0],p5[1],p5[2],u8,v8,p8[0],p8[1],p8[2]);
    	writeQuadPrimitive(out,u5,v5,p5[0],p5[1],p5[2],u6,v6,p6[0],p6[1],p6[2],u7,v7,p7[0],p7[1],p7[2],u8,v8,p8[0],p8[1],p8[2]);
    	return(pArray);
    }
    
    /**
     * write the coordinates to draw a regular octagon centered on zero
     * BUT on the reverse order
     * @param out : stream to write the data
     * @param inradius : inradius of the octagon
     * @param z : z coordinate of the octagon
     * @param u1
     * @param v1
     * @param u2
     * @param v2
     * @param u3
     * @param v3
     * @param u4
     * @param v4
     * @param u5
     * @param v5
     * @param u6
     * @param v6
     * @param u7
     * @param v7
     * @param u8
     * @param v8
     */
    public static float[][] writeZeroCenteredReversedRegularOctagon(DataOutputStream out,float inradius,float z,
    		float u1,float v1,float u2,float v2,float u3,float v3,float u4,float v4,
    		float u5,float v5,float u6,float v6,float u7,float v7,float u8,float v8)throws IOException{
    	float[][] pArray=computeZeroCenteredRegularOctagon(inradius,z);
    	final float[] p1=pArray[7];
    	final float[] p2=pArray[6];
    	final float[] p3=pArray[5];
    	final float[] p4=pArray[4];
    	final float[] p5=pArray[3];
    	final float[] p6=pArray[2];
    	final float[] p7=pArray[1];
    	final float[] p8=pArray[0];
    	writeQuadPrimitive(out,u1,v1,p1[0],p1[1],p1[2],u2,v2,p2[0],p2[1],p2[2],u3,v3,p3[0],p3[1],p3[2],u4,v4,p4[0],p4[1],p4[2]);
    	writeQuadPrimitive(out,u1,v1,p1[0],p1[1],p1[2],u4,v4,p4[0],p4[1],p4[2],u5,v5,p5[0],p5[1],p5[2],u8,v8,p8[0],p8[1],p8[2]);
    	writeQuadPrimitive(out,u5,v5,p5[0],p5[1],p5[2],u6,v6,p6[0],p6[1],p6[2],u7,v7,p7[0],p7[1],p7[2],u8,v8,p8[0],p8[1],p8[2]);
    	return(pArray);
    }
    
    private final static void writeLinkBetweenTwoZeroCenteredRegularOctagons(DataOutputStream out,float[][] back,float[][] front,
    		float u1,float v1,float u2,float v2,float u3,float v3,float u4,float v4)throws IOException{   	
    	for(int i=0;i<8;i++)
    	    writeQuadPrimitive(out,u1,v1,back[i][0],back[i][1],back[i][2],u2,v2,front[i][0],front[i][1],front[i][2],u3,v3,front[(i+1)%8][0],front[(i+1)%8][1],front[(i+1)%8][2],u4,v4,back[(i+1)%8][0],back[(i+1)%8][1],back[(i+1)%8][2]);
    }
    
    /**
     * 
     * @param inradius
     * @param z
     */
    private final static float[][] computeZeroCenteredRegularOctagon(float inradius,float z){
    	final float halfSideLength = inradius/2.4142f;
    	final float[] p1={inradius,halfSideLength,z};
    	final float[] p2={halfSideLength,inradius,z};
    	final float[] p3={-halfSideLength,inradius,z};
    	final float[] p4={-inradius,halfSideLength,z};
    	final float[] p5={-inradius,-halfSideLength,z};
    	final float[] p6={-halfSideLength,-inradius,z};
    	final float[] p7={halfSideLength,-inradius,z};
    	final float[] p8={inradius,-halfSideLength,z};
    	return(new float[][]{p1,p2,p3,p4,p5,p6,p7,p8});
    }
    
    private final static void writeRocketLauncher(DataOutputStream out,float inradius)throws IOException{
    	final float r1=inradius,r2=inradius*(2.0f/3.0f);
    	final float r3=inradius*(5.0f/6.0f),r4=inradius/6.0f;
    	final float r5=inradius/2.0f,r6=inradius/3.0f;
    	float[][] part1,part2,part3,part3bis,part4,part5,part6,part7,part8,part9,part10,part11;
    	float[] lightBeige={0.5f,0.5f,0.75f,1.0f};
    	float[] lightestGray={0.75f,0.5f,1.0f,1.0f};   	
    	float[] smallScrew={0.0f,0.0f,0.25f,0.5f};
    	float[] bigScrew={0.25f,0.0f,0.5f,0.5f};
    	float[] lightGray={0.5f,0.0f,0.75f,0.5f};
    	float[] darkGray={0.75f,0.0f,1.0f,0.5f};
    	//write the closest octagon in the back of the weapon
    	part1=writeZeroCenteredRegularOctagon(out, r1, 0.0f,
    			darkGray[0],darkGray[1],darkGray[0],darkGray[3],
    			darkGray[2],darkGray[3],darkGray[2],darkGray[1],
    			darkGray[0],darkGray[1],darkGray[0],darkGray[3],
    			darkGray[2],darkGray[3],darkGray[2],darkGray[1]);
    	part2=computeZeroCenteredRegularOctagon(r1,-inradius*(4.0f/3.0f));
    	//write the closest link
    	writeLinkBetweenTwoZeroCenteredRegularOctagons(out,part1,part2,
    			lightGray[0],lightGray[1],lightGray[0],lightGray[3],
    			lightGray[2],lightGray[3],lightGray[2],lightGray[1]);   	   	
    	part3=computeZeroCenteredRegularOctagon(r2, -inradius*(5.0f/3.0f));
    	//write the link
    	writeLinkBetweenTwoZeroCenteredRegularOctagons(out,part2,part3, 
    			bigScrew[0],bigScrew[1],bigScrew[0],bigScrew[3],
    			bigScrew[2],bigScrew[3],bigScrew[2],bigScrew[1]);   	
    	part3bis=computeZeroCenteredRegularOctagon(r2, -inradius*(7.0f/3.0f));
    	//write the link
    	writeLinkBetweenTwoZeroCenteredRegularOctagons(out,part3,part3bis, 
    			lightGray[0],lightGray[1],lightGray[0],lightGray[3],
    			lightGray[2],lightGray[3],lightGray[2],lightGray[1]);
    	part4=computeZeroCenteredRegularOctagon(r2, -inradius*(8.0f/3.0f));
    	//write the link
    	writeLinkBetweenTwoZeroCenteredRegularOctagons(out,part3bis,part4, 
    			lightBeige[0],lightBeige[1],lightBeige[0],lightBeige[3],
    			lightBeige[2],lightBeige[3],lightBeige[2],lightBeige[1]);
    	part5=computeZeroCenteredRegularOctagon(r3, -inradius*3.0f);
    	//write the link
    	writeLinkBetweenTwoZeroCenteredRegularOctagons(out,part4,part5,
    			smallScrew[0],smallScrew[1],smallScrew[0],smallScrew[3],
    			smallScrew[2],smallScrew[3],smallScrew[2],smallScrew[1]);
    	part6=computeZeroCenteredRegularOctagon(r3, -inradius*(10.0f/3.0f));
    	//write the link
    	writeLinkBetweenTwoZeroCenteredRegularOctagons(out,part5,part6,
    			bigScrew[0],bigScrew[1],bigScrew[0],bigScrew[3],
    			bigScrew[2],bigScrew[3],bigScrew[2],bigScrew[1]);
    	part7=computeZeroCenteredRegularOctagon(r2, -inradius*4.0f);
    	//write the link
    	writeLinkBetweenTwoZeroCenteredRegularOctagons(out,part6,part7, 
    			smallScrew[0],smallScrew[1],smallScrew[0],smallScrew[3],
    			smallScrew[2],smallScrew[3],smallScrew[2],smallScrew[1]);
    	//write an octagon
    	writeZeroCenteredReversedRegularOctagon(out, r2, -inradius*4.0f,
    			smallScrew[0],smallScrew[1],smallScrew[0],smallScrew[3],
    			smallScrew[2],smallScrew[3],smallScrew[2],smallScrew[1],
    			smallScrew[0],smallScrew[1],smallScrew[0],smallScrew[3],
    			smallScrew[2],smallScrew[3],smallScrew[2],smallScrew[1]);
    	part8=computeZeroCenteredRegularOctagon(r4, -inradius*4.0f);
    	part9=computeZeroCenteredRegularOctagon(r4, -inradius*(13.0f/3.0f));
    	//write the link
    	writeLinkBetweenTwoZeroCenteredRegularOctagons(out,part8,part9,
    			smallScrew[0],smallScrew[1],smallScrew[0],smallScrew[3],
    			smallScrew[2],smallScrew[3],smallScrew[2],smallScrew[1]);
    	//write an octagon
    	part10=writeZeroCenteredRegularOctagon(out, r5, -inradius*(13.0f/3.0f),
    			smallScrew[0],smallScrew[1],smallScrew[0],smallScrew[3],
    			smallScrew[2],smallScrew[3],smallScrew[2],smallScrew[1],
    			smallScrew[0],smallScrew[1],smallScrew[0],smallScrew[3],
    			smallScrew[2],smallScrew[3],smallScrew[2],smallScrew[1]);
    	part11=computeZeroCenteredRegularOctagon(r6, -inradius*(17.0f/3.0f));
    	//write the link
    	writeLinkBetweenTwoZeroCenteredRegularOctagons(out,part10,part11,
    			lightestGray[0],lightestGray[1],lightestGray[0],lightestGray[3],
    			lightestGray[2],lightestGray[3],lightestGray[2],lightestGray[1]);
    	//write an octagon
    	writeZeroCenteredReversedRegularOctagon(out, r6, -inradius*(17.0f/3.0f),
    			lightestGray[0],lightestGray[1],lightestGray[0],lightestGray[3],
    			lightestGray[2],lightestGray[3],lightestGray[2],lightestGray[1],
    			lightestGray[0],lightestGray[1],lightestGray[0],lightestGray[3],
    			lightestGray[2],lightestGray[3],lightestGray[2],lightestGray[1]);   	
    }
       
    public static boolean removePointPair(List<PointPair> list,PointPair pair){
    	int index=0;
    	for(PointPair p:list)
    		if(p.equals(pair))	        
    			return(list.remove(index)!=null);
    		else
    			index++;
    	return(false);
    }
    
    public static void main(String[] args){
    	if(args.length!=4)
    	    {System.out.println("Usage: java TilesGenerator map_filename tiles_filename rocketlauncher_filename binary_map_filename");
    	     System.exit(0);
    	    }
	    new TilesGenerator(args[0],args[1],args[2],args[3]);
    }
    
}
