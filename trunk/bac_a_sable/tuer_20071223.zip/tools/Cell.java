/*This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation, version 2
  of the License.
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston,
  MA 02111-1307, USA.
*/

/*

*/

package tools;

import java.util.Collections;
import java.util.List;
import java.util.Vector;
import java.io.Serializable;

public final class Cell implements Serializable{
    
    private static final long serialVersionUID = 1L;
    
    /*TODO : use couples of 5D points*/
    /*TODO : delegate these temporary structures to another class*/
    private transient List<PointPair> topWalls;
    
    private transient List<PointPair> bottomWalls;
    
    private transient List<PointPair> topPortals;
    
    private transient List<PointPair> bottomPortals;
    
    private transient List<PointPair> leftWalls;
    
    private transient List<PointPair> rightWalls;
    
    private transient List<PointPair> leftPortals;
    
    private transient List<PointPair> rightPortals;
    
    public Cell(){
        topWalls=new Vector<PointPair>();
	    bottomWalls=new Vector<PointPair>();
	    topPortals=new Vector<PointPair>();
	    bottomPortals=new Vector<PointPair>();
	    leftWalls=new Vector<PointPair>();
	    rightWalls=new Vector<PointPair>();
	    leftPortals=new Vector<PointPair>();
	    rightPortals=new Vector<PointPair>();
    }
    
    
    public List<PointPair> getTopWalls(){
        return(topWalls);
    }
    
    public List<PointPair> getBottomWalls(){
        return(bottomWalls);
    }
    
    public PointPair getTopWalls(int index){
        return(topWalls.get(index));
    }
    
    public PointPair getBottomWalls(int index){
        return(bottomWalls.get(index));
    }
         
    public List<PointPair> getLeftWalls(){
        return(leftWalls);
    }
    
    public List<PointPair> getRightWalls(){
        return(rightWalls);
    }
    
    public PointPair getLeftWalls(int index){
        return(leftWalls.get(index));
    }
    
    public PointPair getRightWalls(int index){
        return(rightWalls.get(index));
    }   
    
    public List<PointPair> getTopPortals(){
        return(topPortals);
    }
    
    public List<PointPair> getBottomPortals(){
        return(bottomPortals);
    }
    
    public PointPair getTopPortals(int index){
        return(topPortals.get(index));
    }
    
    public PointPair getBottomPortals(int index){
        return(bottomPortals.get(index));
    }
         
    public List<PointPair> getLeftPortals(){
        return(leftPortals);
    }
    
    public List<PointPair> getRightPortals(){
        return(rightPortals);
    }
    
    public PointPair getLeftPortals(int index){
        return(leftPortals.get(index));
    }
    
    public PointPair getRightPortals(int index){
        return(rightPortals.get(index));
    }
    
    public void addTopWall(PointPair topWall){
        topWalls.add(topWall);
    }
    
    public void addBottomWall(PointPair bottomWall){
        bottomWalls.add(bottomWall);
    }
    
    public void addTopPortal(PointPair topPortal){
        topPortals.add(topPortal);
    }
    
    public void addBottomPortal(PointPair bottomPortal){
        bottomPortals.add(bottomPortal);
    }
    
    public void addLeftWall(PointPair leftWall){
        leftWalls.add(leftWall);
    }
    
    public void addRightWall(PointPair rightWall){
        rightWalls.add(rightWall);
    }
    
    public void addLeftPortal(PointPair leftPortal){
        leftPortals.add(leftPortal);
    }
    
    public void addRightPortal(PointPair rightPortal){
        rightPortals.add(rightPortal);
    }     
    
    public void addTopWalls(Vector<PointPair> topWalls){
        topWalls.addAll(topWalls);
    }
    
    public void addBottomWalls(Vector<PointPair> bottomWalls){
        bottomWalls.addAll(bottomWalls);
    }
    
    public void addTopPortals(Vector<PointPair> topPortals){
        topPortals.addAll(topPortals);
    }
    
    public void addBottomPortals(Vector<PointPair> bottomPortals){
        bottomPortals.addAll(bottomPortals);
    }
    
    public void addLeftWalls(Vector<PointPair> leftWalls){
        leftWalls.addAll(leftWalls);
    }
    
    public void addRightWalls(Vector<PointPair> rightWalls){
        rightWalls.addAll(rightWalls);
    }
    
    public void addLeftPortals(Vector<PointPair> leftPortals){
        leftPortals.addAll(leftPortals);
    }
    
    public void addRightPortals(Vector<PointPair> rightPortals){
        rightPortals.addAll(rightPortals);
    }    
    
    public void mergeLeftWalls(){
    	Collections.sort(leftWalls, new PointPairComparator(PointPairComparator.VERTICAL_SORT));
    	mergePointPairList(leftWalls);
    } 
    
    public void mergeRightWalls(){
    	Collections.sort(rightWalls, new PointPairComparator(PointPairComparator.VERTICAL_SORT));
    	mergePointPairList(rightWalls);
    } 
    
    public void mergeTopWalls(){
    	Collections.sort(topWalls, new PointPairComparator(PointPairComparator.HORIZONTAL_SORT));
    	mergePointPairList(topWalls);
    } 
    
    public void mergeBottomWalls(){
    	Collections.sort(bottomWalls, new PointPairComparator(PointPairComparator.HORIZONTAL_SORT));
    	mergePointPairList(bottomWalls);
    }  
    
    public void mergeLeftPortals(){
    	Collections.sort(leftPortals, new PointPairComparator(PointPairComparator.VERTICAL_SORT));
    	mergePointPairList(leftPortals);
    } 
    
    public void mergeRightPortals(){
    	Collections.sort(rightPortals, new PointPairComparator(PointPairComparator.VERTICAL_SORT));
    	mergePointPairList(rightPortals);
    } 
    
    public void mergeTopPortals(){
    	Collections.sort(topPortals, new PointPairComparator(PointPairComparator.HORIZONTAL_SORT));
    	mergePointPairList(topPortals);
    } 
    
    public void mergeBottomPortals(){
    	Collections.sort(bottomPortals, new PointPairComparator(PointPairComparator.HORIZONTAL_SORT));
    	mergePointPairList(bottomPortals);
    }
    
    /**
     * merge all linked point pairs
     * @param list : list containing SORTED point pairs
     */
    private static void mergePointPairList(List<PointPair> list){
    	if(list.size()<2)
    	    return;
    	Vector<PointPair> result=new Vector<PointPair>();
    	Vector<PointPair> lastLinkedPointPairVector=new Vector<PointPair>();
    	PointPair currentPointPair,nextPointPair;
    	for(int i=0;i<list.size()-1;i++)
    	   {//we move an "abstract window" to analyse 2 point pairs
    		currentPointPair=list.get(i);
    	    nextPointPair=list.get(i+1);
    		//if they are linked
    	    if(currentPointPair.isLinkedTo(nextPointPair))
    		    {if(lastLinkedPointPairVector.isEmpty())
    		    	 lastLinkedPointPairVector.add(currentPointPair);
    		     lastLinkedPointPairVector.add(nextPointPair);
    		     //if the next point pair is the last point pair
    		     if(i+2==list.size())
    		         {//force the merge of all walls
   				      PointPair head=lastLinkedPointPairVector.get(0);
   				      for(int j=1;j<lastLinkedPointPairVector.size();j++)
   				          head.merge(lastLinkedPointPairVector.get(j));
   		    	      //add it all to the result vector
   		    	      result.add(head);
   		    	      lastLinkedPointPairVector.clear();
   		             }
    		    }
    		else
    		    {//otherwise, check if it has already been added
    			 //check untreated already linked point pairs
    			 if(!lastLinkedPointPairVector.isEmpty())
    		         {//if the current point pair has not yet 
    				  //been added, add it to the result vector
    				  if(!lastLinkedPointPairVector.get(lastLinkedPointPairVector.size()-1).equals(currentPointPair))
    					  result.add(currentPointPair);
    				  //force the merge of all walls
    				  PointPair head=lastLinkedPointPairVector.get(0);
    				  for(int j=1;j<lastLinkedPointPairVector.size();j++)
    				      head.merge(lastLinkedPointPairVector.get(j));
    		    	  //add it all to the result vector
    		    	  result.add(head);
    		    	  lastLinkedPointPairVector.clear();
    		         }
    			 else
    				 result.add(currentPointPair);
    			 //if the next point pair is the last point pair
    			 if(i+2==list.size())
    				 result.add(nextPointPair);
    		    }
    		}
    	//update the list
    	list.clear();
    	list.addAll(result);
    }
    
    public String toString(){
    	final String newLine="\n";//System.getProperty("line.separator");
    	String tmp="";
    	//tmp+=((Object)this).toString()+newLine;
    	tmp+="top walls :"+newLine;
    	for(PointPair p:topWalls)
    	    tmp+=p.toString()+newLine;   	   
    	tmp+="top portals :"+newLine;
    	for(PointPair p:topPortals)
    	    tmp+=p.toString()+newLine;
    	tmp+="bottom walls :"+newLine;
    	for(PointPair p:bottomWalls)
    	    tmp+=p.toString()+newLine;
    	tmp+="bottom portals :"+newLine;
    	for(PointPair p:bottomPortals)
    	    tmp+=p.toString()+newLine;
    	tmp+="left walls :"+newLine;
    	for(PointPair p:leftWalls)
    	    tmp+=p.toString()+newLine;
    	tmp+="left portals :"+newLine;
    	for(PointPair p:leftPortals)
    	    tmp+=p.toString()+newLine;
    	tmp+="right walls :"+newLine;
    	for(PointPair p:rightWalls)
    	    tmp+=p.toString()+newLine;
    	tmp+="right portals :"+newLine;  
    	for(PointPair p:rightPortals)
    	    tmp+=p.toString()+newLine;
    	tmp+=newLine;
    	return(tmp);
    }


	public boolean isValid() {
		if(!leftWalls.isEmpty())
		    {int left=leftWalls.get(0).getFirst().x;
		     for(PointPair p:leftWalls)
			     if(p.getFirst().x!=left || p.getLast().x!=left)
				     return(false);
		     if(!leftPortals.isEmpty())
		    	 for(PointPair p:leftPortals)
		             if(p.getFirst().x!=left || p.getLast().x!=left)
			             return(false);
		    }
		else
		    if(!leftPortals.isEmpty())
		        {int left=leftPortals.get(0).getFirst().x;
	             for(PointPair p:leftPortals)
		             if(p.getFirst().x!=left || p.getLast().x!=left)
			             return(false);
	            }
		    else
		    	return(false);
		if(!rightWalls.isEmpty())
		    {int right=rightWalls.get(0).getFirst().x;
			 for(PointPair p:rightWalls)
				 if(p.getFirst().x!=right || p.getLast().x!=right)
					 return(false);
			 if(!rightPortals.isEmpty())
				 for(PointPair p:rightPortals)
				     if(p.getFirst().x!=right || p.getLast().x!=right)
					     return(false);	
		    }
		else
		    if(!rightPortals.isEmpty())
		        {int right=rightPortals.get(0).getFirst().x;
			     for(PointPair p:rightPortals)
				     if(p.getFirst().x!=right || p.getLast().x!=right)
					     return(false);			 
		        }
		    else
		    	return(false);	
		if(!topWalls.isEmpty())
		    {int top=topWalls.get(0).getFirst().y;
			 for(PointPair p:topWalls)
				 if(p.getFirst().y!=top || p.getLast().y!=top)
					 return(false);	
			 if(!topPortals.isEmpty())
				 for(PointPair p:topPortals)
				     if(p.getFirst().y!=top || p.getLast().y!=top)
					     return(false);
		    }
		else
			if(!topPortals.isEmpty())
			    {int top=topPortals.get(0).getFirst().y;
			     for(PointPair p:topPortals)
				     if(p.getFirst().y!=top || p.getLast().y!=top)
					     return(false);			 
		        }
			else
				return(false);
		
		if(!bottomWalls.isEmpty())
	        {int bottom=bottomWalls.get(0).getFirst().y;
		     for(PointPair p:bottomWalls)
			     if(p.getFirst().y!=bottom || p.getLast().y!=bottom)
				     return(false);	
		     if(!bottomPortals.isEmpty())
			     for(PointPair p:bottomPortals)
			         if(p.getFirst().y!=bottom || p.getLast().y!=bottom)
				         return(false);
	        }
	    else
		    if(!bottomPortals.isEmpty())
		        {int bottom=bottomPortals.get(0).getFirst().y;
		         for(PointPair p:bottomPortals)
			         if(p.getFirst().y!=bottom || p.getLast().y!=bottom)
				         return(false);			 
	            }
		    else
			    return(false);						
		return(true);
	}
}
