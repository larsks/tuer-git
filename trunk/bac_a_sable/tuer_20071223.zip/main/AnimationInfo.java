/*This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation, version 2
  of the License.
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston,
  MA 02111-1307, USA.
*/


/**
 * This class handles the information concerning an animation.
 * Each animation is composed of one or more frames.
 * @author Julien Gouesse
 */

package main;

class AnimationInfo{
    
    
    private String strName;//This stores the name of the animation
    
    private int startFrame;// This stores the first frame index for this animation
    
    private int endFrame;// This stores the last frame index for this animation
    
    private int frameCount;// This stores the count of frames for this animation
    
    private int framesPerSecond;// This stores the frames per second that this animation runs
    
    
    AnimationInfo(){
        this.strName="";
	this.startFrame=0;
	this.endFrame=0;
	this.frameCount=1;
	this.framesPerSecond=1;
    }
    
    AnimationInfo(String strName,int startFrame,int endFrame,int framesPerSecond){
        this.strName=strName;
	this.startFrame=startFrame;
	this.endFrame=endFrame;
	this.frameCount=endFrame-startFrame+1;
	this.framesPerSecond=framesPerSecond;
    }
    
    
    String getStrName(){
        return(strName);
    }
    
    int getStartFrame(){
        return(startFrame);
    }				
    
    int getEndFrame(){
        return(endFrame);
    }				
    
    int getFrameCount(){
        return(frameCount);
    }			
    
    int getFramesPerSecond(){
        return(framesPerSecond);
    }
    
    void setStrName(String strName){
        this.strName=strName;
    }
    
    void setStartFrame(int startFrame){
        this.startFrame=startFrame;
    }				
    
    void setEndFrame(int endFrame){
        this.endFrame=endFrame;
    }				
    
    void setFrameCount(int frameCount){
        this.frameCount=frameCount;
    }			
    
    void setFramesPerSecond(int framesPerSecond){
        this.framesPerSecond=framesPerSecond;
    }
}
