package main;

import java.awt.Frame;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import javax.media.opengl.GL;
import javax.media.opengl.GLCanvas;
import javax.media.opengl.GLCapabilities;


public final class GameView extends Frame {

	
	private static final long serialVersionUID = 1L;
	
	private int screenWidth;
	
	private int screenHeight;
	
    private GLCanvas canvas;//canvas for OpenGL rendering
    
    private GL gl;
    
    private transient GameMouseMotionController gameMouseMotionController;//controls the mouse
    
    private GameGLEventController gameGLEventController;//view (referring to the design pattern "MVC")

    private ISoundSystem sif = null;
    
	
	public GameView(){
		super();
		GameModel gameModel;		
		try{gameModel=new GameModel(this);}
		catch(RuntimeException re)
		{throw new RuntimeException("Unable to create the game model",re);}
		setLocation(0,0);//sets the window at the topleft corner
    	setUndecorated(true);//makes the decoration disappear
    	setIgnoreRepaint(true);//prevents the system from calling repaint automatically   	
	    //gets the size of the screen    
	    screenWidth=(int)Toolkit.getDefaultToolkit().getScreenSize().getWidth();
	    screenHeight=(int)Toolkit.getDefaultToolkit().getScreenSize().getHeight();	
	    setSize(screenWidth,screenHeight);	
	    //bug fix : under Linux, sometimes the window was drawn below the taskbar
	    setResizable(true);				
	    //builds a transparent cursor
	    BufferedImage cursor=new BufferedImage(1,1,BufferedImage.TYPE_INT_ARGB);
	    cursor.setRGB(0,0,0);
	    setCursor(Toolkit.getDefaultToolkit().createCustomCursor(cursor,new Point(0,0),"empty cursor"));	
	    GLCapabilities capabilities=new GLCapabilities();
	    capabilities.setDoubleBuffered(true);//enables double buffering
	    capabilities.setHardwareAccelerated(true);//enables hardware acceleration
	    canvas=new GLCanvas(capabilities);								
	    canvas.setAutoSwapBufferMode(false);//prevents any auto buffer swapping	
	    gl=canvas.getGL();
	    canvas.addGLEventListener(gameGLEventController=new GameGLEventController(this,gameModel));	
	    canvas.addMouseMotionListener(gameMouseMotionController=new GameMouseMotionController(true,this,gameModel,gameGLEventController,10));		
	    canvas.addMouseListener(gameMouseMotionController);	
	    canvas.addKeyListener(new GameKeyboardController(gameModel,gameGLEventController,this));			    
	    gameGLEventController.display();
	    add(canvas);        		
	    setVisible(true);
	    canvas.requestFocus();
	    canvas.requestFocusInWindow();       
	    attachSound();
        openSound();
	    gameModel.runEngine();
	    dispose();
	    closeSound();
	}
	
	
	GL getGL(){
        return(gl);
    }        
    
    GLCanvas getCanvas(){
        return(canvas);
    }
    
    int getScreenWidth(){
        return(screenWidth);
    }
    
    int getScreenHeight(){
        return(screenHeight);
    }
    
    void display(){
    	gameGLEventController.display();
    }
    
    void pushInfoMessage(String message){
    	gameGLEventController.pushInfoMessage(message);
    }
    
    int getCycle(){
    	return(gameGLEventController.getCycle());
    }
    
    void setCycle(int cycle){
    	gameGLEventController.setCycle(cycle);
    }
    
    public final void attachSound(){
        System.out.println("trying Java 2 Sound:");
        try {sif = new SoundSystem();}  
        catch(Throwable e)
        {sif=null;
         System.out.println("Java 2 sound failed : "+e.getMessage());
        }
     }
     
    public final void openSound(){  
         try {if(sif!=null)
                  {if(!sif.openSound())         
                       {// Java 2 sound startup failed.
                        System.out.println("Java 2 sound startup failed.");
                        sif=null;
                       } 
                  }
              else
                  System.out.println("Java 2 sound startup failed.");
             }
         catch(Exception e)
         {System.out.println("Problem : "+e);}
     }    

     public final void closeSound(){ 
         if(sif!=null) 
             sif.closeSound();
     }
     
     public final boolean loadSounds(){ 
         if(sif!=null) 
             return(sif.loadSounds()); 
         return(false); 
     }
     
     public final void stepMusic(){ 
         if(sif!=null) 
             sif.stepMusic();         
     }
     
     public final void restartMusic(){ 
         if(sif!=null) 
             sif.restartMusic();      
     }
     
     public String soundInfo(){
         if(sif!=null) 
             return sif.soundInfo(); 
         return ""; 
     }
     
     public final void playSound(int id,int x,int z,int playerx,int playerz){ 
         if(sif!=null) 
             sif.playSound(id,x,z,playerx,playerz);
     }
     
     public final void playBotGreeting(){ 
         if(sif!=null) 
             sif.playBotGreeting();   
     }
     
     public final void playBotHit(int x1,int z1,int x2,int z2){ 
         if(sif!=null) 
             sif.playBotHit(x1,z1,x2,z2); 
     }
     
     public final void playAreaCleared(){ 
         if(sif!=null) 
             sif.playAreaCleared();   
     }
     
     public final void playTermSound(){ 
         if(sif!=null) 
             sif.playTermSound();     
     }
     
     public final void startMovingSound(int iMask){ 
         if(sif!=null) 
             sif.startMovingSound(iMask);  
     }
     
     public final void stopMovingSound(int iMask){ 
         if(sif!=null) 
             sif.stopMovingSound(iMask);
     }
     
     /*TODO : call it when the player gets close to an area*/
     public final void startCarpetSound(){ 
         if(sif!=null) 
             sif.startCarpetSound();  
     }
     
     public final void stopCarpetSound(){ 
         if(sif!=null) 
             sif.stopCarpetSound();
     }
     
     public final void stopAllSounds(){ 
         if(sif!=null) 
             sif.stopAllSounds();
     }
     
     public final void setSoundOption(String s){
         if(sif!=null) 
             sif.setSoundOption(s);
     }
}
