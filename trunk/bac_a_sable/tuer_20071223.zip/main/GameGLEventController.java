/*This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation, version 2
  of the License.
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston,
  MA 02111-1307, USA.
*/

package main;

import com.sun.opengl.util.j2d.TextRenderer;
import com.sun.opengl.util.BufferUtil;
import com.sun.opengl.util.texture.Texture;
import com.sun.opengl.util.texture.TextureIO;
import com.sun.opengl.util.Screenshot;
import java.awt.Font;
import java.io.File;
import java.io.IOException;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.util.List;
import java.util.Vector;
import javax.media.opengl.GL;
import javax.media.opengl.GLAutoDrawable;
import javax.media.opengl.GLCanvas;
import javax.media.opengl.GLEventListener;
import javax.media.opengl.GLException;
import javax.media.opengl.glu.GLU;

/**
 * This class has the role of being the controller 
 * and the view
 * (in the meaning of the design pattern "MVC") of
 * the GL events. It is a tool which is used by the
 * view itself and the model to communicate together. 
 * It avoids us to modify the model when we modify the view
 * and vice versa. It only handles the events related on
 * refreshing the display and creating the GL context.
 *
 * @author Julien Gouesse
 */

class GameGLEventController implements GLEventListener{
    
    
    private GL gl;
    
    private GLU glu;    
    
    private GLCanvas canvas;
    
    private GameModel gameModel;
    
    private int screenWidth;
    
    private int screenHeight;   
    
    private List<String> messageLine;
    
    private List<Integer> messageWidth; 
    
    private List<Integer> messageHeight;           
    
    private IStaticVertexSet levelVertexSet;    
    
    private IDynamicVertexSet artVertexSet;
    
    //private IDynamicVertexSet objectsVertexSet;
    
    private IDynamicVertexSet botVertexSet;
    
    private IStaticVertexSet unbreakableObjectVertexSet;
    
    private IStaticVertexSet vendingMachineVertexSet;
        
    private IStaticVertexSet lampVertexSet;
    
    private IStaticVertexSet chairVertexSet;
    
    private IStaticVertexSet flowerVertexSet;
    
    private IStaticVertexSet tableVertexSet;
    
    private IStaticVertexSet bonsaiVertexSet;
    
    private IStaticVertexSet upperWallVertexSet;
    
    private IStaticVertexSet lowerWallVertexSet;
    
    private IStaticVertexSet leftWallVertexSet;
    
    private IStaticVertexSet rightWallVertexSet;
    
    private IStaticVertexSet dirtyUpperWallVertexSet;
    
    private IStaticVertexSet dirtyLowerWallVertexSet;
    
    private IStaticVertexSet dirtyLeftWallVertexSet;
    
    private IStaticVertexSet dirtyRightWallVertexSet;
    
    private IStaticVertexSet ceilVertexSet;
    
    private IStaticVertexSet floorVertexSet;   
    
    private IStaticVertexSet rocketLauncherVertexSet; 
    
    private Texture botTexture1;
    
    private Texture botTexture2;
    
    private Texture levelTexture;
    
    private Texture artTexture1;

    private Texture artTexture2;

    private Texture artTexture3;

    private Texture artTexture4;   
    
    private Texture objectsTexture;
    
    private Texture startingScreenTexture;
    
    private Texture startingMenuTexture;
    
    private Texture rocketLauncherTexture;

    private long  lnow;
    
    //private long  lStartPhase;

    private boolean recSnapFilm;

    private boolean recSnapShot;      
    
    private VertexSetSeeker vertexSetSeeker;
    
    private TextRenderer textRenderer;
    
    private int cycle;
    
    private boolean useAlphaTest;
    
    private GLMenu menu;
    
    private int loadProgress;
    
    private GLProgressBar progressBar;
    
    private static final int loadableItemCount=30;
    
    //private static final int EMPTY=0;
    
    private static final int FIXED_AND_BREAKABLE_CHAIR=1;
    
    private static final int FIXED_AND_BREAKABLE_LIGHT=2;
    
    //private static final int MOVING_AND_BREAKABLE=3;
    
    private static final int AVOIDABLE_AND_UNBREAKABLE=4;
    
    //private static final int UNAVOIDABLE_AND_UNBREAKABLE=5;
    
    //private static final int UNAVOIDABLE_AND_UNBREAKABLE_DIRTY=6;
    
    private static final int FIXED_AND_BREAKABLE_BIG=7;
    
    private static final int FIXED_AND_BREAKABLE_FLOWER=8;
    
    private static final int FIXED_AND_BREAKABLE_TABLE=9;
    
    private static final int FIXED_AND_BREAKABLE_BONSAI=10;
    
    //private static final int UNAVOIDABLE_AND_UNBREAKABLE_DOWN=11;
    
    //private static final int UNAVOIDABLE_AND_UNBREAKABLE_LEFT=12;
    
    //private static final int UNAVOIDABLE_AND_UNBREAKABLE_RIGHT=13;
    
    //private static final int UNAVOIDABLE_AND_UNBREAKABLE_UP_DOWN=14;
    
    //private static final int UNAVOIDABLE_AND_UNBREAKABLE_UP_LEFT=15;
    
    //private static final int UNAVOIDABLE_AND_UNBREAKABLE_UP_RIGHT=16;
    
    //private static final int UNAVOIDABLE_AND_UNBREAKABLE_UP_DOWN_LEFT=17;
    
    //private static final int UNAVOIDABLE_AND_UNBREAKABLE_UP_DOWN_RIGHT=18;
    
    //private static final int UNAVOIDABLE_AND_UNBREAKABLE_UP_LEFT_RIGHT=19;
               
    //private static final int UNAVOIDABLE_AND_UNBREAKABLE_UP_DOWN_LEFT_RIGHT=20;
       
    //private static final int UNAVOIDABLE_AND_UNBREAKABLE_DOWN_LEFT=21;
    
    //private static final int UNAVOIDABLE_AND_UNBREAKABLE_DOWN_RIGHT=22;
    
    //private static final int UNAVOIDABLE_AND_UNBREAKABLE_DOWN_LEFT_RIGHT=23;
    
    //private static final int UNAVOIDABLE_AND_UNBREAKABLE_LEFT_RIGHT=24;
    
    //private static final int UNAVOIDABLE_AND_UNBREAKABLE_UP=25;
    
    //dirty walls
    //private static final int UNAVOIDABLE_AND_UNBREAKABLE_DOWN_DIRTY=26;
    
    //private static final int UNAVOIDABLE_AND_UNBREAKABLE_LEFT_DIRTY=27;
    
    //private static final int UNAVOIDABLE_AND_UNBREAKABLE_RIGHT_DIRTY=28;
    
    //private static final int UNAVOIDABLE_AND_UNBREAKABLE_UP_DOWN_DIRTY=29;
    
    //private static final int UNAVOIDABLE_AND_UNBREAKABLE_UP_LEFT_DIRTY=30;
    
    //private static final int UNAVOIDABLE_AND_UNBREAKABLE_UP_RIGHT_DIRTY=31;
    
    //private static final int UNAVOIDABLE_AND_UNBREAKABLE_UP_DOWN_LEFT_DIRTY=32;
    
    //private static final int UNAVOIDABLE_AND_UNBREAKABLE_UP_DOWN_RIGHT_DIRTY=33;
    
    //private static final int UNAVOIDABLE_AND_UNBREAKABLE_UP_LEFT_RIGHT_DIRTY=34;
               
    //private static final int UNAVOIDABLE_AND_UNBREAKABLE_UP_DOWN_LEFT_RIGHT_DIRTY=35;
       
    //private static final int UNAVOIDABLE_AND_UNBREAKABLE_DOWN_LEFT_DIRTY=36;
    
    //private static final int UNAVOIDABLE_AND_UNBREAKABLE_DOWN_RIGHT_DIRTY=37;
    
    //private static final int UNAVOIDABLE_AND_UNBREAKABLE_DOWN_LEFT_RIGHT_DIRTY=38;
    
    //private static final int UNAVOIDABLE_AND_UNBREAKABLE_LEFT_RIGHT_DIRTY=39;
    
    //private static final int UNAVOIDABLE_AND_UNBREAKABLE_UP_DIRTY=40;
                                      
    
    GameGLEventController(GameView gameView,GameModel gameModel){
        this.gl=gameView.getGL();	
    	this.glu=new GLU();
    	this.useAlphaTest=false;
    	this.loadProgress=0;
    	this.canvas=gameView.getCanvas();
    	this.gameModel=gameModel;  	
    	this.screenWidth=gameView.getScreenWidth();
    	this.screenHeight=gameView.getScreenHeight();
    	this.messageLine=new Vector<String>();
    	this.messageHeight=new Vector<Integer>();
    	this.messageWidth=new Vector<Integer>();
    	this.levelVertexSet=null;
    	this.artVertexSet=null;
    	this.botVertexSet=null;
    	this.unbreakableObjectVertexSet=null;
    	this.vendingMachineVertexSet=null;
    	this.lampVertexSet=null;
    	this.chairVertexSet=null;
    	this.flowerVertexSet=null;    
    	this.tableVertexSet=null;
    	this.bonsaiVertexSet=null;  
    	this.botTexture1=null;
    	this.botTexture2=null;
    	this.levelTexture=null;
    	this.artTexture1=null;
    	this.artTexture2=null;
    	this.artTexture3=null;
    	this.artTexture4=null;
    	this.objectsTexture=null;
    	this.startingScreenTexture=null;
    	this.startingMenuTexture=null;
    	this.recSnapFilm=false;
    	this.recSnapShot=false;
    	this.vertexSetSeeker=VertexSetSeeker.getInstance();
    	this.cycle=0;
    	this.progressBar=new GLProgressBar((screenWidth-500)/2,(int)((screenHeight-25)/2.5),500,25,0,loadableItemCount);
    	this.progressBar.setProgressStringPainted(true);
    	//check if the directory called "snap" already exists, otherwise create it
    	File snapDirectory=new File("snap");
	    if(!snapDirectory.exists() || !snapDirectory.isDirectory())
	        if(!snapDirectory.mkdir())
	            pushMessage("The program can not create a directory to save the screenshots!",(int)(screenWidth*0.35),(int)(screenHeight*0.5));     
    }

    public final void display(){
    	canvas.display();
    }
    
    public final void display(GLAutoDrawable drawable){  	
        //System.out.println(((Runtime.getRuntime().totalMemory()-Runtime.getRuntime().freeMemory())/1048576) +"MB");
        gl.glClear(GL.GL_COLOR_BUFFER_BIT|GL.GL_DEPTH_BUFFER_BIT);          
	    //3D display now
	    switch(cycle)
	        {case 0:
	             {break;}
	         case 1:
                 {break;}
	         case 2:
	             {//if the game is not ready, don't display anything
	              if(loadProgress < loadableItemCount)
	                  break;	                  
	              //draw here objects in relative coordinates (to the player)
	              gl.glEnable(GL.GL_TEXTURE_2D); 
	              gl.glEnable(GL.GL_DEPTH_TEST);
	              gl.glLoadIdentity();
	              //draw the rocket launcher	              
	              this.rocketLauncherTexture.bind();
	              gl.glPushMatrix();
	              gl.glTranslatef(40.0f,-35.0f,-50.0f);
	              this.rocketLauncherVertexSet.draw();
	              gl.glPopMatrix();
	              glu.gluLookAt(gameModel.getPlayerXpos(),0,gameModel.getPlayerZpos(),
	                      gameModel.getPlayerXpos()+Math.cos(0.5*Math.PI-gameModel.getPlayerDirection()),0,gameModel.getPlayerZpos()+Math.sin(0.5*Math.PI-gameModel.getPlayerDirection()),
	                      0,1,0);
	              //draw here the objects in absolute coordinates
	              //draw the levelTextured level	              
	              this.levelTexture.bind(); 
	              this.levelVertexSet.draw();	                                                 
	              int i,j,limit,xp,zp;         
	              xp=(int)(gameModel.getPlayerXpos()/65536);
	              zp=(int)(gameModel.getPlayerZpos()/65536);
	              //draw the artworks              	                  
	              if(!gameModel.getPlayerWins())
	                  {this.artTexture1.bind();            
	                   this.artVertexSet.draw(0,64);
	                   this.artVertexSet.draw(108,64);
	                   this.artTexture2.bind();
	                   this.artVertexSet.draw(64,44);
	                   this.artVertexSet.draw(172,16);
	                  }                          
	              else
	                  {this.artTexture3.bind();
	                   this.artVertexSet.draw(0,64);
	                   this.artVertexSet.draw(108,64);
	                   this.artTexture4.bind();
	                   this.artVertexSet.draw(64,44);	                      
	                   this.artVertexSet.draw(172,16);
	                  }	                
	              //draw the bots
	              limit=0;      
	              FloatBuffer translation=BufferUtil.newFloatBuffer(gameModel.getBotList().size()*3);
	              FloatBuffer rotation=BufferUtil.newFloatBuffer(gameModel.getBotList().size()*4);
	              IntBuffer first=BufferUtil.newIntBuffer(gameModel.getBotList().size());
	              IntBuffer count=BufferUtil.newIntBuffer(gameModel.getBotList().size());         
	              for(BotModel bot:gameModel.getBotList())
	                  if(bot.getHealth()==BotModel.startingHealth && 
	                 bot.getX()<=gameModel.getPlayerXpos()+1638400 &&
	                 bot.getX()>=gameModel.getPlayerXpos()-1638400 &&
	                 bot.getZ()<=gameModel.getPlayerZpos()+1638400 &&
	                 bot.getZ()>=gameModel.getPlayerZpos()-1638400)               
	                      {translation.put((float)bot.getX());
	                       translation.put((float)bot.getY());
	                       translation.put((float)bot.getZ());
	                       rotation.put((float)((Math.PI+gameModel.getPlayerDirection())*(180/Math.PI)));
	                       rotation.put(0.0f);
	                       rotation.put(1.0f);
	                       rotation.put(0.0f);
	                       first.put(bot.getFace()*4);
	                       count.put(4);
	                       limit++;
	                      }
	              //draw the bots without damage here
	              //bug fix : allows to display objects on SiS 661 FX  
	              if(this.useAlphaTest)
	                  {gl.glEnable(GL.GL_ALPHA_TEST);
	                   gl.glAlphaFunc(GL.GL_EQUAL,1);
	                  }	              
	              this.botTexture1.bind();	              
	              this.botVertexSet.multiDraw(translation,rotation,first,count,limit,false);      
	              translation.position(0);
	              rotation.position(0);
	              first.position(0);
	              count.position(0);
	              limit=0;
	              for(BotModel bot:gameModel.getBotList())
	                  if(bot.isAlive() && bot.getHealth()<BotModel.startingHealth && 
	                 bot.getX()<=gameModel.getPlayerXpos()+1638400 &&
	                 bot.getX()>=gameModel.getPlayerXpos()-1638400 &&
	                 bot.getZ()<=gameModel.getPlayerZpos()+1638400 &&
	                 bot.getZ()>=gameModel.getPlayerZpos()-1638400)
	                  {translation.put((float)bot.getX());
	                   translation.put((float)bot.getY());
	                   translation.put((float)bot.getZ());
	                   rotation.put((float)((Math.PI+gameModel.getPlayerDirection())*(180/Math.PI)));
	                   rotation.put(0.0f);
	                   rotation.put(1.0f);
	                   rotation.put(0.0f);
	                   first.put(bot.getFace()*4);
	                   count.put(4);
	                   limit++;
	                  }
	              //draw the bots with damage here
	              this.botTexture2.bind();                    
	              this.botVertexSet.multiDraw(translation,rotation,first,count,limit,false);
	              this.objectsTexture.bind();         
	              for(i=zp-25;i<zp+25;i++)
	                  for(j=xp-25;j<xp+25;j++)
	                      switch(gameModel.getCollisionMap(i*256+j))
	                          {case AVOIDABLE_AND_UNBREAKABLE:
	                               {gl.glPushMatrix();
	                                gl.glTranslatef((j+0.5f)*65536,0.0f,(i+0.5f)*65536);
	                                this.unbreakableObjectVertexSet.draw();
	                                gl.glPopMatrix();
	                                break;
	                               }
	                           case FIXED_AND_BREAKABLE_BIG:  
	                               {gl.glPushMatrix();
	                                gl.glTranslatef((j+0.5f)*65536,0.0f,(i+0.5f)*65536);
	                                this.vendingMachineVertexSet.draw();
	                                gl.glPopMatrix();
	                                break;
	                               }                        
	                           case FIXED_AND_BREAKABLE_LIGHT:
	                               {gl.glPushMatrix();
	                                gl.glTranslatef((j+0.5f)*65536,0.0f,(i+0.5f)*65536);
	                                this.lampVertexSet.draw();
	                                gl.glPopMatrix();
	                                break;
	                               }
	                           case FIXED_AND_BREAKABLE_CHAIR:
	                               {gl.glPushMatrix();
	                                gl.glTranslatef((j+0.5f)*65536,0.0f,(i+0.5f)*65536);
	                                this.chairVertexSet.draw();
	                                gl.glPopMatrix();
	                                break;
	                               }
	                           case FIXED_AND_BREAKABLE_FLOWER:
	                               {gl.glPushMatrix();
	                                gl.glTranslatef((j+0.5f)*65536,0.0f,(i+0.5f)*65536);
	                                this.flowerVertexSet.draw();
	                                gl.glPopMatrix();
	                                break;
	                               }
	                           case FIXED_AND_BREAKABLE_TABLE:
	                               {gl.glPushMatrix();
	                                gl.glTranslatef((j+0.5f)*65536,0.0f,(i+0.5f)*65536);
	                                this.tableVertexSet.draw();
	                                gl.glPopMatrix();
	                                break;
	                               }
	                           case FIXED_AND_BREAKABLE_BONSAI:
	                               {gl.glPushMatrix();
	                                gl.glTranslatef((j+0.5f)*65536,0.0f,(i+0.5f)*65536);
	                                this.bonsaiVertexSet.draw();
	                                gl.glPopMatrix();
	                                break;
	                               }                  
	                          }	                                                                 
	              if(this.useAlphaTest)
	                  gl.glDisable(GL.GL_ALPHA_TEST);         
	              gl.glDisable(GL.GL_DEPTH_TEST);
	              gl.glDisable(GL.GL_TEXTURE_2D);  	                                          
	              break;
	             }	         
	        }	    
	    //2D display (but I save the previous projection matrix)
        gl.glMatrixMode(GL.GL_PROJECTION);
        gl.glPushMatrix();
        gl.glLoadIdentity();
        //2D display using gluOrtho2D
        glu.gluOrtho2D(0,screenWidth,0,screenHeight);       
        gl.glMatrixMode(GL.GL_MODELVIEW);
        gl.glLoadIdentity();       
        //it is not necessary to change the viewport here       
        //draw the panel with the data here : health, map, etc...
        switch(cycle)
            {case 0:
                 {if(this.startingScreenTexture!=null)
                      {gl.glEnable(GL.GL_TEXTURE_2D);
                       this.startingScreenTexture.bind();
                       gl.glBegin(GL.GL_QUADS);            
                       gl.glTexCoord2i(0,1);
                       gl.glVertex2i(0,0);
                       gl.glTexCoord2i(1,1);
                       gl.glVertex2i(screenWidth,0);
                       gl.glTexCoord2i(1,0);
                       gl.glVertex2i(screenWidth,screenHeight);
                       gl.glTexCoord2i(0,0);
                       gl.glVertex2i(0,screenHeight);          
                       gl.glEnd();
                       gl.glDisable(GL.GL_TEXTURE_2D);                      
                       progressBar.setValue(loadProgress);
                       progressBar.display(drawable);
                      }
                  break;
                 }
             case 1:
                 {if(this.startingMenuTexture!=null)
                      {gl.glEnable(GL.GL_TEXTURE_2D);
                       this.startingMenuTexture.bind();
                       gl.glBegin(GL.GL_QUADS);             
                       gl.glTexCoord2f(0.0f,0.75f);
                       gl.glVertex2i(0,(int)(screenHeight*0.75));
                       gl.glTexCoord2f(1.0f,0.75f);
                       gl.glVertex2i(screenWidth,(int)(screenHeight*0.75));
                       gl.glTexCoord2f(1.0f,0.25f);
                       gl.glVertex2i(screenWidth,screenHeight);
                       gl.glTexCoord2f(0.0f,0.25f);
                       gl.glVertex2i(0,screenHeight);
                       gl.glEnd();
                       gl.glDisable(GL.GL_TEXTURE_2D);
                       if(!menu.isVisible())
                           menu.setVisible(true);
                       if(gameModel.getBpause())
                           {//display something to show the game is paused                     
                            pushMessage("GAME PAUSED",(int)(screenWidth*0.45),(int)(screenHeight*0.7)); 
                            if(!menu.getItem(0).isEnabled())
                                menu.setEnabledIndex(0,true);
                           }
                       else
                           {if(menu.getItem(0).isEnabled())
                               menu.setEnabledIndex(0,false);
                            if(gameModel.getPlayerHit())
                                {//display something to show the player died                  
                                 pushMessage("YOU FAILED!!!",(int)(screenWidth*0.45),(int)(screenHeight*0.7));
                                }
                           }
                       menu.display(drawable);
                      }                         
                  break;
                 }
             case 2:
                 {pushMessage("HEALTH "+gameModel.getHealth(),(int)(screenWidth*0.85),(int)(screenHeight*0.1));
                  //bug fix : division by zero
                  if(System.currentTimeMillis()-lnow > 0)
                      {//System.out.println((1000L/(System.currentTimeMillis()-lnow))+" FPS");
                       pushMessage((1000L/(System.currentTimeMillis()-lnow))+" FPS",(int)(screenWidth*0.85),(int)(screenHeight*0.15));
                      }
                  if(gameModel.getPlayerWins())
                      {pushMessage("C O N G R A T U L A T I O N S",(int)(screenWidth*0.45),(int)(screenHeight*0.5));
                       pushMessage("DEMO COMPLETED - COOL ART ESTABLISHED!",(int)(screenWidth*0.40),(int)(screenHeight*0.45));                 
                      }
                  else
                      {//draw the crosshair     
                       final int halfWidth=screenWidth/2,halfHeight=screenHeight/2;
                       gl.glPushAttrib(GL.GL_CURRENT_BIT);
                       gl.glColor3f(1.0f,0.0f,0.0f);
                       gl.glBegin(GL.GL_LINES);
                       gl.glVertex2f(halfWidth,halfHeight*0.9f);
                       gl.glVertex2f(halfWidth,halfHeight*1.1f);
                       gl.glVertex2f(halfWidth*0.9f,halfHeight);
                       gl.glVertex2f(halfWidth*1.1f,halfHeight);
                       gl.glEnd();
                       gl.glPopAttrib();                      
                      }
                  if(menu.isVisible())
                      menu.setVisible(false);
                  break;
                 }
            }
        lnow = System.currentTimeMillis();          
        gl.glPushAttrib(GL.GL_CURRENT_BIT);       
        textRenderer.begin3DRendering();
        for(int i=0;i<messageLine.size();i++)
            {textRenderer.setColor(0.5f,0.2f,0.4f,1.0f);                
             textRenderer.draw(messageLine.get(i),messageWidth.get(i).intValue(),messageHeight.get(i).intValue()/*(int)(screenWidth*0.45),(int)(screenHeight*0.7)*/);
            }
        textRenderer.end3DRendering();
        gl.glPopAttrib();       
        messageLine.clear();
        messageHeight.clear();
        messageWidth.clear();       
        //restore the matrices for 3D display                            
        gl.glMatrixMode(GL.GL_PROJECTION);
        gl.glPopMatrix();
        gl.glMatrixMode(GL.GL_MODELVIEW);     	    	          
	    gl.glFlush();  
        /*this prevents problems with intel, SIS and ATI drivers 
	    under Microsoft Windows*/     
	    try{canvas.swapBuffers();}
	    catch(GLException glex)
	    {glex.printStackTrace();}	
	    if(recSnapFilm || recSnapShot)
	        {if(recSnapShot)
	             recSnapShot=false;
	         //save screenshot in a targa file
	         try {Screenshot.writeToTargaFile(getScreenshotFile(),screenWidth,screenHeight);}
	         catch(IOException ioe)
	         {ioe.printStackTrace();}
	        }
	    if(loadProgress < loadableItemCount)
	        {loadProgress=0;         
	         if(this.levelVertexSet==null)
	             {this.levelVertexSet=vertexSetSeeker.getIStaticVertexSetInstance(gl,gameModel.getLevelCoordinatesBuffer());      
	              this.levelVertexSet.setMode(GL.GL_QUADS);
	              return;
	             }
	         else
	             loadProgress+=1;
	         if(this.artVertexSet==null)
	             {this.artVertexSet=vertexSetSeeker.getIDynamicVertexSetInstance(gl,gameModel.getArtCoordinatesBuffer());
	              this.artVertexSet.setMode(GL.GL_QUADS);
	              return;
	             } 
	         else
                 loadProgress+=1;
	         if(this.botVertexSet==null)
	             {this.botVertexSet=vertexSetSeeker.getIDynamicVertexSetInstance(gl,gameModel.getBotCoordinatesBuffer());
	              this.botVertexSet.setMode(GL.GL_QUADS);
	              return;
	             }
	         else
                 loadProgress+=1;
	         if(this.unbreakableObjectVertexSet==null)
	             {this.unbreakableObjectVertexSet=vertexSetSeeker.getIStaticVertexSetInstance(gl,gameModel.getUnbreakableObjectCoordinatesBuffer());
	              this.unbreakableObjectVertexSet.setMode(GL.GL_QUADS);
	              return;
	             }
	         else
                 loadProgress+=1;
	         if(this.vendingMachineVertexSet==null)
	             {this.vendingMachineVertexSet=vertexSetSeeker.getIStaticVertexSetInstance(gl,gameModel.getVendingMachineCoordinatesBuffer());
	              this.vendingMachineVertexSet.setMode(GL.GL_QUADS);
	              return;
	             }
	         else
                 loadProgress+=1;
	         if(this.lampVertexSet==null)
	             {this.lampVertexSet=vertexSetSeeker.getIStaticVertexSetInstance(gl,gameModel.getLampCoordinatesBuffer());
	              this.lampVertexSet.setMode(GL.GL_QUADS);
	              return;
	             }
	         else
                 loadProgress+=1;
	         if(this.chairVertexSet==null)
	             {this.chairVertexSet=vertexSetSeeker.getIStaticVertexSetInstance(gl,gameModel.getChairCoordinatesBuffer());
	              this.chairVertexSet.setMode(GL.GL_QUADS);
	              return;
	             }
	         else
                 loadProgress+=1;
	         if(this.flowerVertexSet==null)
	             {this.flowerVertexSet=vertexSetSeeker.getIStaticVertexSetInstance(gl,gameModel.getFlowerCoordinatesBuffer());
	              this.flowerVertexSet.setMode(GL.GL_QUADS);
	              return;
	             }
	         else
                 loadProgress+=1;
	         if(this.tableVertexSet==null)
	             {this.tableVertexSet=vertexSetSeeker.getIStaticVertexSetInstance(gl,gameModel.getTableCoordinatesBuffer());
	              this.tableVertexSet.setMode(GL.GL_QUADS);
	              return;
	             }
	         else
                 loadProgress+=1;
	         if(this.bonsaiVertexSet==null)
	             {this.bonsaiVertexSet=vertexSetSeeker.getIStaticVertexSetInstance(gl,gameModel.getBonsaiCoordinatesBuffer());
	              this.bonsaiVertexSet.setMode(GL.GL_QUADS);
	              return;
	             }
	         else
                 loadProgress+=1;
	         if(this.upperWallVertexSet==null)
	             {this.upperWallVertexSet=vertexSetSeeker.getIStaticVertexSetInstance(gl,gameModel.getUpperWallCoordinatesBuffer());
	              this.upperWallVertexSet.setMode(GL.GL_QUADS);
	              return;
	             }
	         else
                 loadProgress+=1;
	         if(this.lowerWallVertexSet==null)
	             {this.lowerWallVertexSet=vertexSetSeeker.getIStaticVertexSetInstance(gl,gameModel.getLowerWallCoordinatesBuffer());
	              this.lowerWallVertexSet.setMode(GL.GL_QUADS);
	              return;
	             }
	         else
                 loadProgress+=1;
	         if(this.leftWallVertexSet==null)
	             {this.leftWallVertexSet=vertexSetSeeker.getIStaticVertexSetInstance(gl,gameModel.getLeftWallCoordinatesBuffer());
	              this.leftWallVertexSet.setMode(GL.GL_QUADS);
	              return;
	             }
	         else
                 loadProgress+=1;
	         if(this.rightWallVertexSet==null)
	             {this.rightWallVertexSet=vertexSetSeeker.getIStaticVertexSetInstance(gl,gameModel.getRightWallCoordinatesBuffer());
	              this.rightWallVertexSet.setMode(GL.GL_QUADS);
	              return;
	             }
	         else
                 loadProgress+=1;
	         if(this.dirtyUpperWallVertexSet==null)
	             {this.dirtyUpperWallVertexSet=vertexSetSeeker.getIStaticVertexSetInstance(gl,gameModel.getDirtyUpperWallCoordinatesBuffer());
	              this.dirtyUpperWallVertexSet.setMode(GL.GL_QUADS);
	              return;
	             }
	         else
                 loadProgress+=1;
	         if(this.dirtyLowerWallVertexSet==null)
	             {this.dirtyLowerWallVertexSet=vertexSetSeeker.getIStaticVertexSetInstance(gl,gameModel.getDirtyLowerWallCoordinatesBuffer());
	              this.dirtyLowerWallVertexSet.setMode(GL.GL_QUADS);
	              return;
	             }
	         else
                 loadProgress+=1;
	         if(this.dirtyLeftWallVertexSet==null)
	             {this.dirtyLeftWallVertexSet=vertexSetSeeker.getIStaticVertexSetInstance(gl,gameModel.getDirtyLeftWallCoordinatesBuffer());
	              this.dirtyLeftWallVertexSet.setMode(GL.GL_QUADS);
	              return;
	             }
	         else
                 loadProgress+=1;
	         if(this.dirtyRightWallVertexSet==null)
	             {this.dirtyRightWallVertexSet=vertexSetSeeker.getIStaticVertexSetInstance(gl,gameModel.getDirtyRightWallCoordinatesBuffer());
	              this.dirtyRightWallVertexSet.setMode(GL.GL_QUADS);
	              return;
	             }
	         else
                 loadProgress+=1;
	         if(this.ceilVertexSet==null)
	             {this.ceilVertexSet=vertexSetSeeker.getIStaticVertexSetInstance(gl,gameModel.getCeilCoordinatesBuffer());
	              this.ceilVertexSet.setMode(GL.GL_QUADS);
	              return;
	             }
	         else
                 loadProgress+=1;
	         if(this.floorVertexSet==null)
	             {this.floorVertexSet=vertexSetSeeker.getIStaticVertexSetInstance(gl,gameModel.getFloorCoordinatesBuffer());
	              this.floorVertexSet.setMode(GL.GL_QUADS);
	              return;
	             }
	         else
                 loadProgress+=1;
	         if(this.rocketLauncherVertexSet==null)
	             {this.rocketLauncherVertexSet=vertexSetSeeker.getIStaticVertexSetInstance(gl,gameModel.getRocketLauncherCoordinatesBuffer());
	              this.rocketLauncherVertexSet.setMode(GL.GL_QUADS);
	              return;
	             }
	         else
                 loadProgress+=1;
	         try{if(this.levelTexture==null)
	                 {this.levelTexture=TextureIO.newTexture(getClass().getResource("/pic256/wallTexture.png"),false,TextureIO.PNG);
	                  int[] t=new int[1];
	                  t[0]=this.levelTexture.getTextureObject();
	                  float[] p=new float[1];
	                  p[0]=1;
	                  gl.glPrioritizeTextures(1,t,0,p,0);
	                  return;
	                 }
	             else
                     loadProgress+=1;
	             if(this.artTexture1==null)
	                 {this.artTexture1=TextureIO.newTexture(getClass().getResource("/pic256/wallArt1.png"),false,TextureIO.PNG);
	                  return;
	                 }
	             else
	                 loadProgress+=1;
	             if(this.artTexture2==null)     
	                 {this.artTexture2=TextureIO.newTexture(getClass().getResource("/pic256/wallArt2.png"),false,TextureIO.PNG);
	                  return;
	                 }
	             else
	                 loadProgress+=1;
	             if(this.artTexture3==null)     
	                 {this.artTexture3=TextureIO.newTexture(getClass().getResource("/pic256/wallArt3.png"),false,TextureIO.PNG);
	                  return;
	                 }
	             else
	                 loadProgress+=1;
	             if(this.artTexture4==null)     
	                 {this.artTexture4=TextureIO.newTexture(getClass().getResource("/pic256/wallArt4.png"),false,TextureIO.PNG);   
	                  return;
	                 }
	             else
	                 loadProgress+=1;
	             if(this.objectsTexture==null)     
	                 {this.objectsTexture=TextureIO.newTexture(getClass().getResource("/pic256/objects.png"),false,TextureIO.PNG);
	                  return;
	                 }
	             else
	                 loadProgress+=1;
	             if(this.botTexture1==null)
	                 {this.botTexture1=TextureIO.newTexture(getClass().getResource("/pic256/bot1.png"),false,TextureIO.PNG);
	                  return;
	                 }
	             else
	                 loadProgress+=1;
	             if(this.botTexture2==null)
	                 {this.botTexture2=TextureIO.newTexture(getClass().getResource("/pic256/bot2.png"),false,TextureIO.PNG);
	                  return;
	                 }
	             else
	                 loadProgress+=1;
	             if(this.rocketLauncherTexture==null)
	                 {this.rocketLauncherTexture=TextureIO.newTexture(getClass().getResource("/pic256/rocketLauncher.png"),false,TextureIO.PNG);
	                  return;
	                 }
	             else
	                 loadProgress+=1;
	            }
	         catch(IOException ioe)
	         {ioe.printStackTrace();}	         
	        }
	    else
	        {//it allows to display the menu only when both the model and the view are ready
	         if(cycle==0 && gameModel.isGameRunning())
	             cycle=1;
	        }	    
    }

    public final void displayChanged(GLAutoDrawable drawable, boolean modeChanged, boolean deviceChanged){}

    public final  void init(GLAutoDrawable drawable){
    	gl.glClearColor(1.0f,1.0f,1.0f,1.0f);
    	gl.glColor3f(1.0f, 1.0f, 1.0f);
    	gl.glHint(GL.GL_PERSPECTIVE_CORRECTION_HINT,GL.GL_NICEST);
    	gl.glHint(GL.GL_LINE_SMOOTH_HINT,GL.GL_NICEST);
    	gl.glHint(GL.GL_POINT_SMOOTH_HINT,GL.GL_NICEST);
    	gl.glHint(GL.GL_POLYGON_SMOOTH_HINT,GL.GL_NICEST);
    	/*gl.glViewport(-50,-50,100,100);*/	
    	/*gl.glClearDepth(1.0);
	    gl.glEnable(GL.GL_DEPTH_TEST);
	    gl.glDepthFunc(GL.GL_LESS);*/
    	gl.glEnable(GL.GL_CULL_FACE);
    	gl.glCullFace(GL.GL_BACK);	
    	gl.glMatrixMode(GL.GL_PROJECTION);
    	gl.glLoadIdentity();
    	/*modify the projection matrix only when in 3D full mode*/
    	gl.glFrustum(-50,50,-50,50,50,5000000);
    	/*glu.gluPerspective(65.0,4/3,1,1000);*/
    	gl.glMatrixMode(GL.GL_MODELVIEW);
    	gl.glLoadIdentity();
    	//this.lStartPhase=System.currentTimeMillis()+15000;
    	this.lnow=System.currentTimeMillis();
    	this.textRenderer=new TextRenderer(new Font("SansSerif",Font.BOLD,12));	
    	try{
    	    this.startingScreenTexture=TextureIO.newTexture(getClass().getResource("/pic256/starting_screen_bis.png"),false,TextureIO.PNG);
    	    this.startingMenuTexture=TextureIO.newTexture(getClass().getResource("/pic256/starting_menu.png"),false,TextureIO.PNG);
    	   }
        catch(IOException ioe){ioe.printStackTrace();}
    	this.useAlphaTest=gl.isFunctionAvailable("glAlphaFunc");
    	gl.setSwapInterval(0);
    	initMainMenu();
    }
    
    private final void initMainMenu(){
        this.menu=new GLMenu(0.9f*screenWidth/2.0f,1.1f*screenHeight/2.0f,false,new TextRenderer(new Font("SansSerif",Font.BOLD,42)));
        GLMenuItem resumeMenuItem=new GLMenuItem("resume");
        resumeMenuItem.addActionListener(new ResumeGameActionListener(this));
        this.menu.addGLMenuItem(resumeMenuItem);
        GLMenuItem newMenuItem=new GLMenuItem("new game");
        newMenuItem.addActionListener(new NewGameActionListener(this));
        this.menu.addGLMenuItem(newMenuItem);
        GLMenuItem optionsMenuItem=new GLMenuItem("options");
        this.menu.addGLMenuItem(optionsMenuItem);
        GLMenuItem loadMenuItem=new GLMenuItem("load game");      
        this.menu.addGLMenuItem(loadMenuItem);
        GLMenuItem saveMenuItem=new GLMenuItem("save game");       
        this.menu.addGLMenuItem(saveMenuItem);
        GLMenuItem aboutMenuItem=new GLMenuItem("about");
        aboutMenuItem.addActionListener(new AboutActionListener());
        this.menu.addGLMenuItem(aboutMenuItem);
        GLMenuItem quitMenuItem=new GLMenuItem("quit game");
        quitMenuItem.addActionListener(new QuitGameActionListener(gameModel));
        this.menu.addGLMenuItem(quitMenuItem);       
    }

    public final void reshape(GLAutoDrawable drawable, int x, int y, int width, int height){}
    
    private final void pushMessage(String message,int width,int height){
    	//fill the message queue
    	messageLine.add(message);
    	messageWidth.add(width);
    	messageHeight.add(height);	
    }
    
    public final void pushInfoMessage(String message){
        pushMessage(message,(int)(screenWidth*0.45),(int)(screenHeight*0.9));
    }
    
    public final File getScreenshotFile(){
    	File f=null;
    	//try to find an unused abstract pathname
    	for(int i=0;i<Integer.MAX_VALUE;i++)
    		if(!(f=new File("snap/snapshot_"+i+".tga")).exists())
    		    {try {//then create a file with this pathname
    			      f.createNewFile();		      	      		     
    		         }
    		     catch(IOException ioe)
    		     {ioe.printStackTrace();
    		      pushMessage("The program can not save the screenshot!",(int)(screenWidth*0.45),(int)(screenHeight*0.5));
    		     }
    		     return(f);
    		    }
    	//print an error message if there's no unused abstract pathname
    	System.out.println("warning! the screenshot had not been successfully made");
    	return(f);
    }
    
    final int getCycle(){
        return(cycle);
    }
    
    final void setCycle(int cycle){
        this.cycle=cycle;
    }

    final void setRecSnapFilm(boolean recSnapFilm){
        this.recSnapFilm=recSnapFilm;
    }
    
    final void setRecSnapShot(boolean recSnapShot){
        this.recSnapShot=recSnapShot;
    }

    final boolean getRecSnapFilm(){
        return(recSnapFilm);
    }
    
    final boolean getRecSnapShot(){
        return(recSnapShot);
    }
    
    final GameModel getGameModel(){
        return(gameModel);
    }
    
    final GLMenu getGLMenu(){
        return(menu);
    }
}
