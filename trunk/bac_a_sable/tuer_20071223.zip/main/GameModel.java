/*This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation, version 2
  of the License.
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston,
  MA 02111-1307, USA.
*/

/**
 * This class performs the main tasks in the game. 
 *
 *@author Julien Gouesse, Vincent Stahl 
 */
/*
         TUER engine (tuer.tuxfamily.org) inspired from:
         
          d3caster, a 3-D java raycasting game engine 
         =============================================
         rel. 1.1.0, Vincent Stahl, www.stahlforce.com

         OPTIMIZED BY JULIEN GOUESSE (no more raycasting, pure power!!!!!)
	 
	     requires at least Java 1.6 and JOGL 1.1.0
*/

package main;

import com.sun.opengl.util.BufferUtil;
import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.nio.FloatBuffer;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.Vector;

/*TODO : rather use a facade*/
final public class GameModel{
    
    private static final long serialVersionUID=1L;
    
    private GameView gameView;
    
    private List<BotModel> botList;
   
    private final Runtime rt=Runtime.getRuntime();   
    
    private FloatBuffer levelCoordinatesBuffer;//coordinates of the walls
    
    private FloatBuffer artCoordinatesBuffer;//coordinates of the works of art
    
    //private FloatBuffer objectsCoordinatesBuffer;//coordinates of the objects
    
    private FloatBuffer botCoordinatesBuffer;//coordinates of a bot
    
    private FloatBuffer unbreakableObjectCoordinatesBuffer;//coordinates of a unbreakable object
    
    private FloatBuffer vendingMachineCoordinatesBuffer;//coordinates of a vending machine
    
    private FloatBuffer lampCoordinatesBuffer;
    
    private FloatBuffer chairCoordinatesBuffer;
    
    private FloatBuffer flowerCoordinatesBuffer;
    
    private FloatBuffer tableCoordinatesBuffer;
    
    private FloatBuffer bonsaiCoordinatesBuffer;
    
    private FloatBuffer upperWallCoordinatesBuffer;
    
    private FloatBuffer lowerWallCoordinatesBuffer;
    
    private FloatBuffer leftWallCoordinatesBuffer;
    
    private FloatBuffer rightWallCoordinatesBuffer;
    
    private FloatBuffer dirtyUpperWallCoordinatesBuffer;
    
    private FloatBuffer dirtyLowerWallCoordinatesBuffer;
    
    private FloatBuffer dirtyLeftWallCoordinatesBuffer;
    
    private FloatBuffer dirtyRightWallCoordinatesBuffer;
    
    private FloatBuffer ceilCoordinatesBuffer;
    
    private FloatBuffer floorCoordinatesBuffer;
    
    private FloatBuffer rocketLauncherCoordinatesBuffer;
    
    private boolean lookingDown;
    
    private boolean lookingUp;
    
    private byte[] collisionMap;
    
    private byte[] initialCollisionMap;
    
    private List<Integer> clearedArea;
         
    //TODO : put it in a "weapon" class
    private long lastShot;//time of last shof of rocket   
    
    private final static long timeBetweenShots=500;
    
    private int objectsCount;
    
    private int subObjectsCount;
    
    private int unbreakableObjectsCount;
    
    private int bigBreakableObjectsCount;
    
    private boolean gameRunning=false;
    
    private boolean bcheat  = false;
    private boolean bDistSnd= true;    // sound loudness relative to distance

    // basic setup
    private static final double fullCircle = Math.PI*2;
    private static final int numWallPlainText = 10;
    private static final int numWallPlainNetto= numWallPlainText/2;
    private static final int numLoWallImages  = 27; // 240804: 20
    private static final int numHiWallImages  = numLoWallImages; // MUST be identical

    // generic helper variables. in "decent" programming,
    // these should be declared locally, when they're used.
    // for maximum performance, they are declared globally,
    // reducing the creation of local stack frames.
    private int counter;
    private Random rg;

    // object handling
    private static final int maxBots=200;
    private static final int maxBushes=800;
    private static final int maxDeko=450;
    private static final int numObjects=100+maxBots+maxBushes+maxDeko;
    private static final int ShapeRocket=0; // must add iobjtext for atext[] index!
    private static final int ShapeExplo =1;
    private static final int ShapeBot   =2;
    private static final int ShapeBush  =3;
    private static final int ShapeDeko  =4;

    private d3object object[];
    private d3area   area[];

    private static final int IndexPlayerRockets=0;  // plr rockets are on index 0 to 9
    private static final int IndexBotRockets=10;    // bot rockets are on index 10 to 19
    private static final int IndexBots=20;          // bots are on index 20 to 119 (see maxBots)
    private static final int IndexBushes=IndexBots+maxBots; // bushes are on index 120 ff.
    private static final int IndexDeko=IndexBushes+maxBushes;
    
    // player handling
    private PlayerModel player;    
    
    private boolean innerLoop;

    private byte botmap[];
    private byte areamap[];

    private boolean bpause;

    // texture storage
    private int iwallplain, iwallimglo, iwallimghi;

    private int map[];
    private byte movemap[];   // determines where player can move 
    
    private boolean runningForwards;
    private boolean runningBackwards;
    private boolean rightStepping;
    private boolean leftStepping;
    private boolean playerMoving;
    private boolean turningLeft;
    private boolean turningRight;
    private boolean runningFast;
    
    private int iClLastClearedArea;   
    
    private int[] mapData = null;    
    
    //walking bot support
    private short aBotWalk1[] = { 0,5,6,7,6,5,0,8,9,10,9,8 };
    
    private String sover = null;
    private String soveradd[] = new String[10+5];
    private long   lover = 0; // elapse time
    
    private long lClLastPassBy = 0;
    private int nClBotsWalking = 0;
    
    private boolean aBwShouldPlay[]   = new boolean[3];
    private boolean aBwIsPlaying[]    = new boolean[3];
    private long    aBwPlayingSince[] = new long[3];
  
    private long lastBotShotTime;//latency for the bots
    
    private static final int EMPTY=0;
    
    /*private static final int FIXED_AND_BREAKABLE_CHAIR=1;
    
    private static final int FIXED_AND_BREAKABLE_LIGHT=2;*/
    
    private static final int MOVING_AND_BREAKABLE=3;
    
    /*private static final int AVOIDABLE_AND_UNBREAKABLE=4;
    
    private static final int UNAVOIDABLE_AND_UNBREAKABLE=5;
    
    private static final int UNAVOIDABLE_AND_UNBREAKABLE_DIRTY=6;
    
    private static final int FIXED_AND_BREAKABLE_BIG=7;
    
    private static final int FIXED_AND_BREAKABLE_FLOWER=8;
    
    private static final int FIXED_AND_BREAKABLE_TABLE=9;
    
    private static final int FIXED_AND_BREAKABLE_BONSAI=10;*/
    
    private static final int UNAVOIDABLE_AND_UNBREAKABLE_DOWN=11;
    
    private static final int UNAVOIDABLE_AND_UNBREAKABLE_LEFT=12;
    
    private static final int UNAVOIDABLE_AND_UNBREAKABLE_RIGHT=13;
    
    private static final int UNAVOIDABLE_AND_UNBREAKABLE_UP_DOWN=14;
    
    private static final int UNAVOIDABLE_AND_UNBREAKABLE_UP_LEFT=15;
    
    private static final int UNAVOIDABLE_AND_UNBREAKABLE_UP_RIGHT=16;
    
    private static final int UNAVOIDABLE_AND_UNBREAKABLE_UP_DOWN_LEFT=17;
    
    private static final int UNAVOIDABLE_AND_UNBREAKABLE_UP_DOWN_RIGHT=18;
    
    private static final int UNAVOIDABLE_AND_UNBREAKABLE_UP_LEFT_RIGHT=19;
               
    private static final int UNAVOIDABLE_AND_UNBREAKABLE_UP_DOWN_LEFT_RIGHT=20;
       
    private static final int UNAVOIDABLE_AND_UNBREAKABLE_DOWN_LEFT=21;
    
    private static final int UNAVOIDABLE_AND_UNBREAKABLE_DOWN_RIGHT=22;
    
    private static final int UNAVOIDABLE_AND_UNBREAKABLE_DOWN_LEFT_RIGHT=23;
    
    private static final int UNAVOIDABLE_AND_UNBREAKABLE_LEFT_RIGHT=24;
    
    private static final int UNAVOIDABLE_AND_UNBREAKABLE_UP=25;
    
    //dirty walls
    private static final int UNAVOIDABLE_AND_UNBREAKABLE_DOWN_DIRTY=26;
    
    private static final int UNAVOIDABLE_AND_UNBREAKABLE_LEFT_DIRTY=27;
    
    private static final int UNAVOIDABLE_AND_UNBREAKABLE_RIGHT_DIRTY=28;
    
    private static final int UNAVOIDABLE_AND_UNBREAKABLE_UP_DOWN_DIRTY=29;
    
    private static final int UNAVOIDABLE_AND_UNBREAKABLE_UP_LEFT_DIRTY=30;
    
    private static final int UNAVOIDABLE_AND_UNBREAKABLE_UP_RIGHT_DIRTY=31;
    
    private static final int UNAVOIDABLE_AND_UNBREAKABLE_UP_DOWN_LEFT_DIRTY=32;
    
    private static final int UNAVOIDABLE_AND_UNBREAKABLE_UP_DOWN_RIGHT_DIRTY=33;
    
    private static final int UNAVOIDABLE_AND_UNBREAKABLE_UP_LEFT_RIGHT_DIRTY=34;
               
    private static final int UNAVOIDABLE_AND_UNBREAKABLE_UP_DOWN_LEFT_RIGHT_DIRTY=35;
       
    private static final int UNAVOIDABLE_AND_UNBREAKABLE_DOWN_LEFT_DIRTY=36;
    
    private static final int UNAVOIDABLE_AND_UNBREAKABLE_DOWN_RIGHT_DIRTY=37;
    
    private static final int UNAVOIDABLE_AND_UNBREAKABLE_DOWN_LEFT_RIGHT_DIRTY=38;
    
    private static final int UNAVOIDABLE_AND_UNBREAKABLE_LEFT_RIGHT_DIRTY=39;
    
    private static final int UNAVOIDABLE_AND_UNBREAKABLE_UP_DIRTY=40;
            
    // abstract artworks titles
    private static String ainfoabs[] = {
       // reserved
       "Chief Big Bot - 1953 - $5,000,000",
       // generic
       "Breakfast Sushi - 1972 - $350,000",
       "Egg And Sausage - 1966 - $1,200,000",
       "Momo And Susu - 1927 - $1,900,000",
       "Three Armed Tarantulas - 1942 - $930,000",
       "Comments On Wurst - 1959 - $490,000",
       "A Jar Of Nothing - 1961 - $670,000",
       "Maria Di Lala - 1968 - $1,600,000",
       "Rooms Of Rubber - 1904 - $2,450,000",
       "Questionmark Castles - 1939 - $960,000",

       "Inductions Of Njet - 1952 - $780,000",
       "Riddle From Wall - 1956 - $870,000",
       "Bush And Banana - 1955 - $630,000",
       "Visions Of A Squirrel - 1951 - $1,100,000",
       "Sleepless Monkey - 1949 - $930,000",
       "Bowl Of Goo - 1920 - $1,350,000",
       "Wacky Jungles - 1932 - $550,000",
       "Cat Behind Moon - 1976 - $590,000",
       "Paper In The Loo - 1978 - $240,000",
       "Brain Spotting - 1944 - $960,000",

       "Cow Behind Chicken - 1911 - $450,000",
       "Behind The Coal Shed - 1970 - $475,000",
       "Doc Beavers Bum - 1965 - $630,000",
       "The Goo Gardens - 1909 - $990,000",
       "Photo of Uncle Ted - 1969 - $650,000",
       "Sociopolitical Frown - 1905 - $1,250,000",
       "Portrait Of A Mango - 1973 - $570,000",
    };

    // surreal artworks titles
    private static String ainfosur[] = {
       "Lanis At Park",          
       "Lanis At Lake",          
       "Lanis Caribe",           
       "Alaska Green",           
       "Alaska Gold",            
       "Torii",                  
       "Deserted Roads",         
       "Scarabaeus Wood",        
       "Pink Orchids",           
       "Floatbergs",             
       "Mammoth Park",           
       "Sleeping Mammoth",       
       "Neolithic View",         
       "Neolithic Caribbean",    
       "Blue Window",            
       "Hacienda Of Bricks",     
       "Hacienda Sunrise",       
       "Throne At Seascape",     
       "Throne At Sunset",       
       "Blue Room",              
       "Light Hall",             
       "Polar Industrial Estate",
       "Dream Cruiser",          
       "Icebergs",               
       "Orchids On Ice",         
       "Steel Moon",             
       "Sky Cities",             
    };
    
               
    GameModel(GameView gameView) throws RuntimeException{
    	this.gameView=gameView;
	    this.collisionMap=new byte[65536];
	    this.botList=new Vector<BotModel>();
	    this.clearedArea=new Vector<Integer>();
	    try{
	        DataInputStream in=new DataInputStream(new BufferedInputStream(getClass().getResourceAsStream("/pic256/worldmap.data")));
	        int i,count=0,artWorksCount=0,tmp;
	        //read the data for the walls of the level
	        for(i=0;i<6;i++)
	            count+=in.readInt();
	        //read the data for the objects : flower pots, tables, ...		 
	        //objectsCount contains the count of elements
	        objectsCount=0;
	        //subObjectsCount contains the count of subelements
	        //subObjectsCount = count of groups of primitive
	        //count of primitives = count of groups of primitive * count of primitives per group (quad->4)
	        subObjectsCount=0;	     
	        //count of tiles = count of subelements / count of subelements per tile
	        //count of subelements = tmp
	        //count of subelements per tile = 8 || 4 || 2
	        //count of tiles = tmp / 8 || 4 || 2
	        //count of elements = count of tiles / count of tiles per element
	        //count of tiles per element = 4
	        //count of elements = (tmp / 8 || 4 || 2) / 4 = tmp / 32 || 16 || 8
	        //objects with 8 subelements
	        tmp=in.readInt();	     
	        unbreakableObjectsCount=tmp/32;
	        objectsCount+=unbreakableObjectsCount;
	        subObjectsCount+=tmp;
	        //objects with 4 subelements
	        tmp=in.readInt();
	        bigBreakableObjectsCount=tmp/16;
	        objectsCount+=bigBreakableObjectsCount;
	        subObjectsCount+=tmp;
	        //objects with 2 subelements
	        tmp=in.readInt();
	        objectsCount+=tmp/8;
	        subObjectsCount+=tmp;
	        //read the data for the works of art
	        for(i=0;i<4;i++)
	            artWorksCount+=in.readInt();
	        //for each point : 2 levelTexture coordinates + 3 vertex coordinates
	        final int floatPerPrimitive=5;    
	        //update the way of reading to use the normals
	        levelCoordinatesBuffer=BufferUtil.newFloatBuffer(count*floatPerPrimitive);    
	        for(i=0;i<count;i++)
	            {levelCoordinatesBuffer.put(in.readFloat());
	             levelCoordinatesBuffer.put(in.readFloat());
	             //levelCoordinatesBuffer.put(in.readFloat());
	             //levelCoordinatesBuffer.put(in.readFloat());
	             //levelCoordinatesBuffer.put(in.readFloat());
	             levelCoordinatesBuffer.put(in.readFloat());
	             levelCoordinatesBuffer.put(in.readFloat());
	             levelCoordinatesBuffer.put(in.readFloat());
	            }
	        levelCoordinatesBuffer.position(0);
	        artCoordinatesBuffer=BufferUtil.newFloatBuffer(artWorksCount*floatPerPrimitive);
	        for(i=0;i<artWorksCount;i++)
	            {artCoordinatesBuffer.put(in.readFloat());
	             artCoordinatesBuffer.put(in.readFloat());
	             //artCoordinatesBuffer.put(in.readFloat());
	             //artCoordinatesBuffer.put(in.readFloat());
	             //artCoordinatesBuffer.put(in.readFloat());
	             artCoordinatesBuffer.put(in.readFloat());
	             artCoordinatesBuffer.put(in.readFloat());
	             artCoordinatesBuffer.put(in.readFloat());
	            }
	        artCoordinatesBuffer.position(0);     
	        //read the collision map here
	        in.read(this.collisionMap,0,65536);
	        //initialize a copy of the collision map
	        this.initialCollisionMap=new byte[this.collisionMap.length];	         
	        for(i=0;i<this.collisionMap.length;i++)
	            {if(this.collisionMap[i]==MOVING_AND_BREAKABLE)
	                 {//detect a bot and add it to the bot container
	                  //+32768 -> put the bot at the center of the case
	                  this.botList.add(new BotModel(((i%256)*65536)+32768,0,((i/256)*65536)+32768));
	                  //System.out.println(((i%256)*65536)+" "+((i/256)*65536));
	                  this.collisionMap[i]=EMPTY;
	                 }
	             //copy the collision map
	             this.initialCollisionMap[i]=this.collisionMap[i];
	            }
	        System.out.println(this.botList.size()+" bots added");
	        //4 bounds * 2 animations * 11 frames * 5 elements in a primitive
	        botCoordinatesBuffer=BufferUtil.newFloatBuffer(88*floatPerPrimitive);
	        for(i=0;i<botCoordinatesBuffer.capacity();i++)
	            botCoordinatesBuffer.put(in.readFloat());
	        botCoordinatesBuffer.position(0);
	        //4 bounds * 8 primitive groups * 1 animation * 1 frame * 5 elements in a primitive
	        unbreakableObjectCoordinatesBuffer=BufferUtil.newFloatBuffer(32*floatPerPrimitive);
	        for(i=0;i<unbreakableObjectCoordinatesBuffer.capacity();i++)
	            unbreakableObjectCoordinatesBuffer.put(in.readFloat());     
	        unbreakableObjectCoordinatesBuffer.position(0);
	        //4 bounds * 4 primitive groups * 1 animation * 1 frame * 5 elements in a primitive
	        vendingMachineCoordinatesBuffer=BufferUtil.newFloatBuffer(16*floatPerPrimitive);
	        for(i=0;i<vendingMachineCoordinatesBuffer.capacity();i++)
	            vendingMachineCoordinatesBuffer.put(in.readFloat());
	        vendingMachineCoordinatesBuffer.position(0);	     
	        //4 bounds * 2 primitive groups * 1 animation * 1 frame * 5 elements in a primitive
	        lampCoordinatesBuffer=BufferUtil.newFloatBuffer(8*floatPerPrimitive);
	        for(i=0;i<lampCoordinatesBuffer.capacity();i++)
	            lampCoordinatesBuffer.put(in.readFloat());
	        lampCoordinatesBuffer.position(0);
	        //4 bounds * 2 primitive groups * 1 animation * 1 frame * 5 elements in a primitive
	        chairCoordinatesBuffer=BufferUtil.newFloatBuffer(8*floatPerPrimitive);
	        for(i=0;i<chairCoordinatesBuffer.capacity();i++)
	            chairCoordinatesBuffer.put(in.readFloat());
	        chairCoordinatesBuffer.position(0);
	        //4 bounds * 2 primitive groups * 1 animation * 1 frame * 5 elements in a primitive
	        flowerCoordinatesBuffer=BufferUtil.newFloatBuffer(8*floatPerPrimitive);
	        for(i=0;i<flowerCoordinatesBuffer.capacity();i++)
	            flowerCoordinatesBuffer.put(in.readFloat());
	        flowerCoordinatesBuffer.position(0);
	        //4 bounds * 2 primitive groups * 1 animation * 1 frame * 5 elements in a primitive
	        tableCoordinatesBuffer=BufferUtil.newFloatBuffer(8*floatPerPrimitive);
	        for(i=0;i<tableCoordinatesBuffer.capacity();i++)
	            tableCoordinatesBuffer.put(in.readFloat());
	        tableCoordinatesBuffer.position(0);
	        //4 bounds * 2 primitive groups * 1 animation * 1 frame * 5 elements in a primitive
	        bonsaiCoordinatesBuffer=BufferUtil.newFloatBuffer(8*floatPerPrimitive);
	        for(i=0;i<bonsaiCoordinatesBuffer.capacity();i++)
	            bonsaiCoordinatesBuffer.put(in.readFloat());
	        bonsaiCoordinatesBuffer.position(0);
	        //4 bounds * 1 primitive group * 1 animation * 1 frame * 5 elements in a primitive
	        upperWallCoordinatesBuffer=BufferUtil.newFloatBuffer(4*floatPerPrimitive);
	        for(i=0;i<upperWallCoordinatesBuffer.capacity();i++)
	            upperWallCoordinatesBuffer.put(in.readFloat());
	        upperWallCoordinatesBuffer.position(0);
	        //4 bounds * 1 primitive group * 1 animation * 1 frame * 5 elements in a primitive
	        lowerWallCoordinatesBuffer=BufferUtil.newFloatBuffer(4*floatPerPrimitive);
	        for(i=0;i<lowerWallCoordinatesBuffer.capacity();i++)
	            lowerWallCoordinatesBuffer.put(in.readFloat());
	        lowerWallCoordinatesBuffer.position(0);
	        //4 bounds * 1 primitive group * 1 animation * 1 frame * 5 elements in a primitive
	        leftWallCoordinatesBuffer=BufferUtil.newFloatBuffer(4*floatPerPrimitive);
	        for(i=0;i<leftWallCoordinatesBuffer.capacity();i++)
	            leftWallCoordinatesBuffer.put(in.readFloat());
	        leftWallCoordinatesBuffer.position(0);
	        //4 bounds * 1 primitive group * 1 animation * 1 frame * 5 elements in a primitive
	        rightWallCoordinatesBuffer=BufferUtil.newFloatBuffer(4*floatPerPrimitive);
	        for(i=0;i<rightWallCoordinatesBuffer.capacity();i++)
	            rightWallCoordinatesBuffer.put(in.readFloat());
	        rightWallCoordinatesBuffer.position(0);
	        //4 bounds * 1 primitive group * 1 animation * 1 frame * 5 elements in a primitive
	        ceilCoordinatesBuffer=BufferUtil.newFloatBuffer(4*floatPerPrimitive);
	        for(i=0;i<ceilCoordinatesBuffer.capacity();i++)
	            ceilCoordinatesBuffer.put(in.readFloat());	     
	        ceilCoordinatesBuffer.position(0);
	        //4 bounds * 1 primitive group * 1 animation * 1 frame * 5 elements in a primitive
	        floorCoordinatesBuffer=BufferUtil.newFloatBuffer(4*floatPerPrimitive);
	        for(i=0;i<floorCoordinatesBuffer.capacity();i++)
	            floorCoordinatesBuffer.put(in.readFloat());	     
	        floorCoordinatesBuffer.position(0);
	        //dirty walls
	        //4 bounds * 1 primitive group * 1 animation * 1 frame * 5 elements in a primitive
	        dirtyUpperWallCoordinatesBuffer=BufferUtil.newFloatBuffer(4*floatPerPrimitive);
	        for(i=0;i<dirtyUpperWallCoordinatesBuffer.capacity();i++)
	            dirtyUpperWallCoordinatesBuffer.put(in.readFloat());
	        dirtyUpperWallCoordinatesBuffer.position(0);
	        //4 bounds * 1 primitive group * 1 animation * 1 frame * 5 elements in a primitive
	        dirtyLowerWallCoordinatesBuffer=BufferUtil.newFloatBuffer(4*floatPerPrimitive);
	        for(i=0;i<dirtyLowerWallCoordinatesBuffer.capacity();i++)
	            dirtyLowerWallCoordinatesBuffer.put(in.readFloat());
	        dirtyLowerWallCoordinatesBuffer.position(0);
	        //4 bounds * 1 primitive group * 1 animation * 1 frame * 5 elements in a primitive
	        dirtyLeftWallCoordinatesBuffer=BufferUtil.newFloatBuffer(4*floatPerPrimitive);
	        for(i=0;i<dirtyLeftWallCoordinatesBuffer.capacity();i++)
	            dirtyLeftWallCoordinatesBuffer.put(in.readFloat());
	        dirtyLeftWallCoordinatesBuffer.position(0);
	        //4 bounds * 1 primitive group * 1 animation * 1 frame * 5 elements in a primitive
	        dirtyRightWallCoordinatesBuffer=BufferUtil.newFloatBuffer(4*floatPerPrimitive);
	        for(i=0;i<dirtyRightWallCoordinatesBuffer.capacity();i++)
	            dirtyRightWallCoordinatesBuffer.put(in.readFloat());
	        dirtyRightWallCoordinatesBuffer.position(0);
	        in.close();
	        //read the rocket launcher here
	        in=new DataInputStream(new BufferedInputStream(getClass().getResourceAsStream("/pic256/rocketLauncher.data")));
	        //1520=((4 octagons * 3 quad primitives calls)+(9 links * 8 quad primitives calls))(4 primitives per quad primitives call*5 elements in a primitive)
	        rocketLauncherCoordinatesBuffer=BufferUtil.newFloatBuffer(336*floatPerPrimitive);
	        for(i=0;i<rocketLauncherCoordinatesBuffer.capacity();i++)
	            rocketLauncherCoordinatesBuffer.put(in.readFloat());
	        rocketLauncherCoordinatesBuffer.position(0);
	        in.close();
	        //read the binary version of the world map built from the pixmap
	        mapData = new int[256*256];
	        in=new DataInputStream(new BufferedInputStream(getClass().getResourceAsStream("/pic256/binaryWorldmap.data")));
	        for(i=0;i<mapData.length;i++)
	            mapData[i]=in.readInt();
	        in.close();
	       }
	    catch(IOException ioe)
	    {ioe.printStackTrace();     
	     throw new RuntimeException("Unable to read the data files",ioe);
	    }				
	    player=new PlayerModel();
	    lastShot=currentTime();
    }    

    int getObjectsCount(){
        return(objectsCount);
    }
    
    int getSubObjectsCount(){
        return(subObjectsCount);
    }
    
    int getUnbreakableObjectsCount(){
        return(unbreakableObjectsCount);
    }
    
    int getBigBreakableObjectsCount(){
        return(bigBreakableObjectsCount);
    }
    
    byte[] getInitialCollisionMap(){
        return(initialCollisionMap);
    }
    
    byte[] getCollisionMap(){
        return(collisionMap);
    }
    
    byte getCollisionMap(int index){
        return(collisionMap[index]);
    }
    
    void reinitializeCollisionMap(){
        for(int i=0;i<this.collisionMap.length;i++)	         
	    this.collisionMap[i]=this.initialCollisionMap[i];
    }
    
    List<BotModel> getBotList(){
        return(botList);
    }
    
    List<Integer> getClearedArea(){
        return(this.clearedArea);
    }
    
    final void reinitializeClearedArea(){
        this.clearedArea.clear();
    }
    
    final void respawnAllBots(){
        for(BotModel bot:botList)
	        bot.respawn();
    }
    
    boolean getBcheat(){
        return(bcheat);
    }        
         	        
    FloatBuffer getLevelCoordinatesBuffer(){
        return(levelCoordinatesBuffer);
    }
    
    FloatBuffer getArtCoordinatesBuffer(){
        return(artCoordinatesBuffer);
    }
    
    /*FloatBuffer getObjectsCoordinatesBuffer(){
        return(objectsCoordinatesBuffer);
    }*/
    
    FloatBuffer getBotCoordinatesBuffer(){
        return(botCoordinatesBuffer);
    }
       
    FloatBuffer getUnbreakableObjectCoordinatesBuffer(){
        return(unbreakableObjectCoordinatesBuffer);
    }         
       
    FloatBuffer getVendingMachineCoordinatesBuffer(){
        return(vendingMachineCoordinatesBuffer);
    }  
                       
    FloatBuffer getLampCoordinatesBuffer(){
        return(lampCoordinatesBuffer);
    }
    
    FloatBuffer getChairCoordinatesBuffer(){
        return(chairCoordinatesBuffer);
    }
    
    FloatBuffer getFlowerCoordinatesBuffer(){
        return(flowerCoordinatesBuffer);
    }
    
    FloatBuffer getTableCoordinatesBuffer(){
        return(tableCoordinatesBuffer);
    }
    
    FloatBuffer getBonsaiCoordinatesBuffer(){
        return(bonsaiCoordinatesBuffer);
    }
    
    FloatBuffer getUpperWallCoordinatesBuffer(){
        return(upperWallCoordinatesBuffer);
    }
    
    FloatBuffer getLowerWallCoordinatesBuffer(){
        return(lowerWallCoordinatesBuffer);
    }
    
    FloatBuffer getLeftWallCoordinatesBuffer(){
        return(leftWallCoordinatesBuffer);
    }
    
    FloatBuffer getRightWallCoordinatesBuffer(){
        return(rightWallCoordinatesBuffer);
    }
    
    FloatBuffer getDirtyUpperWallCoordinatesBuffer(){
        return(dirtyUpperWallCoordinatesBuffer);
    }
    
    FloatBuffer getDirtyLowerWallCoordinatesBuffer(){
        return(dirtyLowerWallCoordinatesBuffer);
    }
    
    FloatBuffer getDirtyLeftWallCoordinatesBuffer(){
        return(dirtyLeftWallCoordinatesBuffer);
    }
    
    FloatBuffer getDirtyRightWallCoordinatesBuffer(){
        return(dirtyRightWallCoordinatesBuffer);
    }
    
    FloatBuffer getCeilCoordinatesBuffer(){
        return(ceilCoordinatesBuffer);
    }  
    
    FloatBuffer getFloorCoordinatesBuffer(){
        return(floorCoordinatesBuffer);
    }
    
    FloatBuffer getRocketLauncherCoordinatesBuffer(){
        return(rocketLauncherCoordinatesBuffer);
    }
       
    boolean getPlayerWins(){
        return(player.isWinning());
    }
    
    boolean getInnerLoop(){
        return(innerLoop);
    }         
    
    double getPlayerXpos(){
        return(player.getX());
    }
    
    double getPlayerZpos(){
        return(player.getZ());
    }
    
    double getPlayerDirection(){
        return(player.getDirection());
    }
    
    int getHealth(){
        return(player.getHealth());
    }
    
    boolean getBDistSnd(){
        return(bDistSnd);
    }

    boolean getPlayerHit(){
        return(!player.isAlive());
    }
    
    boolean getBpause(){
        return(bpause);
    }
    
    final boolean isGameRunning(){
        return(gameRunning);
    }
    
    void setBcheat(boolean bcheat){
        this.bcheat=bcheat;
    } 
    
    void setTurningLeft(boolean turningLeft){
        this.turningLeft=turningLeft;
    }  
      
    void setTurningRight(boolean turningRight){
        this.turningRight=turningRight;
    }
    
    void setRunningForwards(boolean runningForwards){
        this.runningForwards=runningForwards;
    }
    
    void setRunningBackwards(boolean runningBackwards){
        this.runningBackwards=runningBackwards;
    }
    
    void setRunningFast(boolean runningFast){
        this.runningFast=runningFast;
    }
    
    void setRightStepping(boolean rightStepping){
        this.rightStepping=rightStepping;
    }
    
    void setLeftStepping(boolean leftStepping){
        this.leftStepping=leftStepping;
    }
    
    void setBpause(boolean bpause){
        this.bpause=bpause;
    }
    
    void setIClLastClearedArea(int iClLastClearedArea){
        this.iClLastClearedArea=iClLastClearedArea;
    }
    
    void setInnerLoop(boolean innerLoop){
        this.innerLoop=innerLoop;
    }
    
    void setBDistSnd(boolean bDistSnd){
        this.bDistSnd=bDistSnd;
    }   
    
    void handleMouseMotion(byte shiftx,byte shifty){
        if(shiftx==-1)
	    {turningLeft=true;
	     turningRight=false;
	    }
	else 
	    if(shiftx==1)
	        {turningLeft=false;
		 turningRight=true;
                }
	    else
	        {turningLeft=false;
		 turningRight=false;
		}
	if(shifty==-1)
	    {lookingDown=true;
	     lookingUp=false;
	    }
	else 
	    if(shifty==1)
	        {lookingDown=false;
		 lookingUp=true;
                }
	    else
	        {lookingDown=false;
		 lookingUp=false;
		}
    }                    

    // "botmap" also is a synonym for area map.
    // every area should have a sector of pixels
    // without holes within this map.
    private final void setBotMap(int ioff, byte igroup) {
        botmap[ioff] = igroup;
    }

    /*TODO : do not use this method anymore*/
    private void genMap(){
       int cx,cy,tmp;
       for(cy=0;cy<256;cy++)
           {tmp=cy*256;	    
	        for(cx=0;cx<256;cx++)                
		        map[tmp+cx]=-1;
	       }
       // analyze world map, build objects from it
       int ipix,ired,igrn,iblu,ioff,icode,irel,narea;
       byte igroup;
       byte ceilstate=0; // initial default: inside
       d3object obj;
       int ipix2,igrn2,imgcnt=1;

       for (cy=0; cy<256; cy++)
       for (cx=0; cx<256; cx++)
       {
          ioff = cy*256+cx;
          ipix = mapData[ioff]&0xFFFFFF;
          ired = (ipix>>16)&0xFF;
          igrn = (ipix>> 8)&0xFF;
          iblu = (ipix    )&0xFF;
          if (ired==0xFF && igrn==0xFF && iblu==0) {
             ceilstate = (byte)(1-ceilstate); // switch ceiling default
             // replace yellow by blue (wall)
             ired=igrn=0; iblu=0xFF;
             // fall through
          }
          if (iblu==0xFF && ired==0xFF && igrn==0) {
             movemap[ioff]    = 3; // exit point            
             // create a dummy area object
             igroup = (byte)(0xFE-235);
             if (area[igroup]==null)
        	area[igroup] = new d3area(igroup);
             continue;
          }
          if (ired==100 && igrn==100 && iblu==00) { // inside            
             continue;
          }
          if (ired==0 && igrn==0 && iblu==0) { // outside            
             continue;
          }

          if (ired<=200 && igrn==0 && iblu<=200 && (ired==iblu))
          {
             // deko object handling
             movemap[ioff] = 2;
             // allocate a new deko object
             for (icode=IndexDeko; icode<IndexDeko+maxDeko; icode++)
        	if (object[icode].getShape()==-1)
                   break;
             if (icode==IndexDeko+maxDeko) {
        	System.out.println("x25341353");
        	continue;
             }
             object[icode].setX((cx<<16)+32768);
             object[icode].setZ((cy<<16)+32768);
             object[icode].setShape(ShapeDeko);
             object[icode].setSpeed((short)0);
             switch (ired) {
        	case 200: object[icode].setFace((short)0); break; // flowers
        	case 100: object[icode].setFace((short)1); break; // table
        	case 150: object[icode].setFace((short)2); break; // vending machine
        	case 151: object[icode].setFace((short)3); break; // group of chairs
        	case 152: object[icode].setFace((short)4); break; // tree
        	case 153: object[icode].setFace((short)5); break; // lamp
        	default:  object[icode].setFace((short)0); break;
             }
             // whatever is standing within an area, must always
             // register its location also with the "botmap",
             // which tells which position belongs to which area.
             igroup=0;
             if ((narea=withinAnArea(cx,cy))>=0) { // -1 if not
        	setBotMap(ioff,(byte)narea);
        	// light emitting objects: only w/in area for performance reasons
        	if (ired==153) {
                   igroup = (byte)narea;
                   if (area[igroup]==null)
                      area[igroup] = new d3area(igroup);
                   area[igroup].addLight(cx,cy);
        	}
             }
             continue;
          }

          if (ired==0 && igrn==0) 
          {
           if (iblu==0xE0) {  // bush, obstacle
             movemap[ioff] = 2;
             // allocate a new bush
             for (icode=IndexBushes; icode<IndexBushes+maxBushes; icode++)
        	if (object[icode].getShape()==-1)
                   break;
             if (icode==IndexBushes+maxBushes) {
        	System.out.println("x20342010");
        	continue;
             }
             object[icode].setX((cx<<16)+32768);
             object[icode].setZ((cy<<16)+32768);
             object[icode].setShape(ShapeBush);  // alloc
             object[icode].setSpeed((short)0);
             // have to register bush location in "botmap",
             // otherwise there would be a hole in the area.
             igroup=0;
             if ((narea=withinAnArea(cx,cy))>=0)
        	setBotMap(ioff,(byte)narea);
             continue;
           }
           if (iblu==0xFF) {  // simple wall
             // wall blocks adjacing an area are
             // also registered with the area,
             // for better dynamic light support.
             igroup=0;
             if ((narea=withinAnArea(cx,cy))>=0)
        	igroup = (byte)narea;
             map[ioff]      = (1+(igroup%(numWallPlainNetto-1)))*2;
             movemap[ioff]  = 1;
             continue;
           }
           if (iblu==100) // switchable image wall
           {
             // this image can be associated with an area.
             // it is then switched once the area is cleared.
             // to be associated, it is sufficient to be
             // adjacent, or next to an area's pixel.
             igroup=0;
             if ((narea=withinAnArea(cx,cy))>=0) {
        	igroup = (byte)narea;
        	if (area[igroup]==null)
                   area[igroup] = new d3area(igroup);
        	area[igroup].addImage(cx,cy);
             }
             irel = imgcnt;
             if ((++imgcnt)>=numLoWallImages)
        	imgcnt = 1; // picture 0 is reserved
             map[ioff]      = (iwallimglo-iwallplain)+irel;
             movemap[ioff]  = 1;
             continue;
           }
           if (iblu==101) // reserved switchable image wall
           {
             // same as above, only for chief bigbot's pic.
             igroup=0;
             if ((narea=withinAnArea(cx,cy))>=0) {
        	igroup = (byte)narea;
        	if (area[igroup]==null)
                   area[igroup] = new d3area(igroup);
        	area[igroup].addImage(cx,cy);
             }
             irel = 0;
             map[ioff]      = (iwallimglo-iwallplain)+irel;
             movemap[ioff]  = 1;
             continue;
           }
           if (iblu >= 0xA0 && iblu < 0xF0) {  // high image wall
             irel = (iblu-0xA0)%numHiWallImages;
             map[ioff]      = (iwallimghi-iwallplain)+irel;
             movemap[ioff]  = 1;
             continue;
           }
          }
          if (ired==0xFF && igrn==0 && iblu==0) { // player start point
             //playerXpos = cx<<16;
	     player.setX(cx<<16);
             //playerYpos = cy<<16;
	     player.setZ(cy<<16);
             igroup=0;
             if ((narea=withinAnArea(cx,cy))>=0) {
        	igroup = (byte)narea;
        	if (area[igroup]==null)
                   area[igroup] = new d3area(igroup);
        	//playerArea = area[igroup];
        	setBotMap(ioff,(byte)narea);
             }
             continue;
          }

          // ----- AREA handling -----
          if (ired==0 && iblu==0 && (igrn >=0xA0 && igrn <= 0xFE)) {  // attack area of bot
             igroup = (byte)(0xFE-igrn);
             setBotMap(ioff,igroup);
             if (area[igroup]==null)
        	area[igroup]=new d3area(igroup);            
             continue;
          }
          if (igrn==0 && iblu==0 && (ired >=0xA0 && ired <= 0xFE)) { // area announcement/preload
             igroup = (byte)(0xFE-ired);
             areamap[ioff] = igroup;
             continue;
          }
          if (   (ired==0 && igrn==0xFF && iblu==0xFF)
              || (ired==0 && igrn==200  && iblu==200)
             ) 
          {
             // create bot, auto-detect surrounding area
             igroup=0;
             if ((narea=withinAnArea(cx,cy))>=0) 
             {
        	igroup = (byte)narea;
        	if (area[igroup]==null)
                   area[igroup] = new d3area(igroup);
        	// create bot
        	setBotMap(ioff,igroup);
        	// allocate a new bot
        	for (icode=IndexBots; icode<IndexBots+maxBots; icode++)
                   if (object[icode].getShape()==-1)
                      break;
        	if (icode==IndexBots+maxBots) {
                   System.out.println("X20342033"); continue;
        	}
        	obj = object[icode];
        	obj.setX((cx<<16)+32768);
        	obj.setZ((cy<<16)+32768);				
        	obj.setShape(ShapeBot);   // alloc
        	obj.setSpeed((short)1);          // pseudo
        	obj.setGroup(igroup);
        	if (igrn==200) {
                   obj.setFlags(1);    // distance bot
                   obj.setSleep(nextRand(10));
        	}
        	else {
                   obj.setFlags(0);    // standard bot
                   obj.setSleep(nextRand(6)+3);
        	}
        	area[igroup].addMember(obj);
        	obj.setMyarea(area[igroup]);
		
        //TODO: optimize the model to drive this loop useless
		for(BotModel bot:botList)
		    if(bot.getRespawnX()==obj.getX() && bot.getRespawnZ()==obj.getZ() && area[igroup]!=null)
		        {bot.setAreaIndex(igroup);
			 break;
			}
			
             }
             else // bot MUST be within an area
        	System.out.println("X1634234A");
             continue;
          }
          if (ired==50 && igrn==50 && iblu==50) {  // area light preset
             // dark area, target indicated in next pixel
             ipix2=mapData[ioff+1]&0xFFFFFF;
             igrn2=(ipix2>>8)&0xFF;
             igroup = (byte)(0xFE-igrn2);
             if (area[igroup]==null)
        	area[igroup]=new d3area(igroup);
             area[igroup].setLight(40);
          }
          if (ired==100 && igrn==100 && iblu==100) {  // respawn point
             igroup=0;
             if ((narea=withinAnArea(cx,cy))>=0) 
             {
        	igroup = (byte)narea;
        	if (area[igroup]==null)
                   area[igroup] = new d3area(igroup);
        	setBotMap(ioff,igroup);
        	if (area[igroup].getSpawnx()==-1)
        	{
                   area[igroup].setSpawnPoint(cx,cy);
                   // IF the next pix is same color,
                   ipix2=mapData[ioff+1]&0xFFFFFF;
                   if (ipix2==ipix)
                      // SWITCH spawn direction to downwards
                      area[igroup].setPlayerdir(0.0);
        	}
             }
             else // this MUST be within an area
        	System.out.println("X16342349");
             continue;
          }
          if (ired==150 && igrn==150 && iblu==150) {  // half-dark
             igroup=0;
             if ((narea=withinAnArea(cx,cy))>=0) {
        	igroup = (byte)narea;
        	if (area[igroup]==null)
                   area[igroup] = new d3area(igroup);
        	area[igroup].setLightlevel(150);
        	setBotMap(ioff,igroup);
             }
             else // this MUST be within an area
        	System.out.println("X27341354");
             continue;
          }
          if (ired==255 && igrn==255 && iblu==255) {  // light source
             igroup=0;
             if ((narea=withinAnArea(cx,cy))>=0) {
        	igroup = (byte)narea;
        	if (area[igroup]==null)
                   area[igroup] = new d3area(igroup);
        	area[igroup].addLight(cx,cy);
        	setBotMap(ioff,igroup);
             }
             else // this MUST be within an area
        	System.out.println("X2912433");
             continue;
          }
       }  // endfor scan
    }

    // check the 8 pixels around cx,cy if we're standing
    // within or nearby an area. this is used just in genMap(),
    // which is not performance critical.
    private final int withinAnArea(int cx,int cy)
    {
        int sx,sy,ipix2,ired2,iblu2,igrn2;
        if (cx>1 && cx<255 && cy>1 && cy<255)
            for (sx=-1;sx<=1;sx++)
                {
                    for (sy=-1;sy<=1;sy++)
                        {
                            ipix2 = mapData[(cy+sy)*256+(cx+sx)];
                            ired2 = (ipix2>>16)&0xFF;
                            igrn2 = (ipix2>> 8)&0xFF;
                            iblu2 = (ipix2    )&0xFF;
                            if (   igrn2 >= 0xA0 && igrn2 <= 0xFE
                                    && ired2 == 0x00 && iblu2 == 0x00)
                                return 0xFE-igrn2;
                        }
                }
        return -1; // not within an area
    }
        
    private final void initialize(){
        if(numLoWallImages!=numHiWallImages)
            System.out.println("X18341622");
        if(numLoWallImages>ainfoabs.length) 
            System.out.println("X18341623");
        if(numHiWallImages>ainfosur.length)
            System.out.println("X18341624");
        rg = new Random(345641);
        System.out.println("allocating maps");
        map         = new   int[65536];
        movemap     = new  byte[65536];       
        botmap      = new  byte[65536];
        areamap     = new  byte[65536];
        Arrays.fill(botmap,(byte)0xFF);     
        System.out.println("allocating rest");	
        object=new d3object[numObjects];
        for(counter=0; counter<numObjects; counter++)
            object[counter] = new d3object();
        iClLastClearedArea = -1;	    	  	
    }

    final void reinit(boolean playerHasBeenKilled){
       //playerHit         = false;
       //playerWins        = false;
       if(!playerHasBeenKilled)
           player.respawn();
       //respawn him later if he has been killed
       player.setAsLoser();
       bpause            = false;    
       soveradd[0]       = null;
       // locate player at default x=128.5, y=240.5.
       // however, this is overridden in genMap().
       player.setX((128*65536)+32768);
       player.setZ((240*65536)+32768);
       player.setDirection(fullCircle/4*2);
       System.out.println("reinit call");
       // by default, all object slots are passive.
       for (counter=0; counter<numObjects; counter++) {
          object[counter].setZ(0);
          object[counter].setX(0);
          object[counter].setDir(0);
          object[counter].setSpeed((short)0);
          object[counter].setShape(-1);
          object[counter].setGroup((byte)0xFF);
          object[counter].setMyarea(null);
          object[counter].setFlags(0);
          object[counter].setSleep(0);
          object[counter].setSleep2(0);
          object[counter].setSeenPlayer(false);
          object[counter].setFace((short)0);
          object[counter].setFaceskip((short)0);
          object[counter].setIanim(0);
          object[counter].setIdamage(0);	  
       }       
       // init the floor texture with large random patches,
       // to make it look a bit more interesting.
       area = new d3area[256];
       Arrays.fill(area,null);      
       Arrays.fill(areamap,(byte)0xFF);            
       genMap(); // may change playerXpos etc...              
       //respawn the bots (except those which are in a clean area)
       boolean respawn;
       for(BotModel bot:botList)	   
           {respawn=true;
            //check if the bot is inside a cleared area
            for(Integer index:this.clearedArea)
                if(index.intValue()==bot.getAreaIndex())
                    {respawn=false;
                     break;
                    }
            if(respawn)
                bot.respawn();
           } 
       lookingDown=false;
       lookingUp=false;
       rightStepping=false;
       leftStepping=false;
       turningLeft=false;
       turningRight=false;
       runningForwards=false;
       runningBackwards=false;
       playerMoving=false;
       runningFast=false;

       gameView.stopMovingSound(0xFFFF); // in case it's still playing
       initBotwalkSound();

       gameView.restartMusic();    // i.e. initial background track

       if(iClLastClearedArea != -1)
           {
            // may player respawn in a higher area?
            d3area d3a = area[iClLastClearedArea];
            if(d3a != null && d3a.getSpawnx() != -1)
                respawnWithin(d3a);
           }
       resetPlayerPosition();       
    }

    final void resetPlayerPosition(){
        //if the user wants to start a new game, 
        //it reinitializes the respawn position
        if(this.clearedArea.isEmpty())
            {player.setX((115*65536)+32768);
             player.setZ((223*65536)+32768);
	         player.setDirection(Math.PI);       
	        }
    }

    private final static long currentTime() {
       return System.currentTimeMillis();
    }

    private final void turnLeft(){       
        byte turnspeed;
        if(runningFast) 
            turnspeed=1;
        else
            turnspeed=2;
        player.setDirection(player.getDirection()+(fullCircle/(24*turnspeed)));
        if(player.getDirection()>=fullCircle)
            player.setDirection(player.getDirection()-fullCircle);	     
    }

    private final void lookDown(){}
    
    private final void lookUp(){}

    final void runEngine(){
        lastBotShotTime=System.currentTimeMillis();
        initialize();  // load stuff, raw setup
        gameRunning=true;
        innerLoop=false;
        boolean hasBeenKilled=false;
        while(gameRunning)
            {reinit(hasBeenKilled);     // re-set all positions
	         while(gameView.getCycle()!=2 && gameRunning)
	             {gameView.display();}         
	         if(gameRunning)
	             {if(hasBeenKilled)
	                  {player.respawn();
	                   hasBeenKilled = false;   
	                  }	         
	              innerLoop = true;
	              tryToForceGarbageCollection(true);
	             }
             while(innerLoop)
        	     {if(sover!=null) 
        	          {// paint overhead status message       		        		      
        	           if(soveradd[0]==null)
        	               paintBufferString(sover);       	          
        	           if(lover < currentTime()) 
        	               {sover=null;
        	                soveradd[0]=null;
        	               }
        	          }		        	      			 
                  gameView.display();		         	             
                  if(bpause) 
                      {continue;}
                  // task that should run as fast as possible       	 
                  checkForImageTitles();      	 
                  hasBeenKilled=stepObjects();	 
                  stepBotwalkSound();               
		          if(!player.isAlive())
        	          continue;
        	      // step player
        	      boolean bmoved = false;
        	      byte turnspeed=2;
        	      if(runningFast) 
        	          turnspeed=1;
        	      if(turningLeft)
        	          {turnLeft();
        	           turningLeft=false;
        	          }		     
        	      if(turningRight)
        	          {player.setDirection(player.getDirection()-(fullCircle/(24*turnspeed)));
        	           if(player.getDirection()<0.0)
        	               player.setDirection(player.getDirection()+fullCircle);
        	           turningRight=false;
        	          }
        	      if(lookingDown)
        	          {lookDown();
        	           lookingDown=false;
        	          }
        	      if(lookingUp)
        	          {lookUp();
        	           lookingUp=false;
        	          }
        	      double playerXnew = player.getX();
        	      double playerYnew = player.getZ();
        	      int ispeed=1;
        	      if(runningFast) 
        	          ispeed=3;
        	      if(rightStepping)
        	          {playerXnew+=Math.sin(player.getDirection()-(fullCircle/4))*10000*ispeed;
        	           playerYnew+=Math.cos(player.getDirection()-(fullCircle/4))*10000*ispeed;
        	          }
        	      if(leftStepping)
        	          {playerXnew+=Math.sin(player.getDirection()+(fullCircle/4))*10000*ispeed;
        	           playerYnew+=Math.cos(player.getDirection()+(fullCircle/4))*10000*ispeed;
        	          }
        	      if(runningForwards) 
        	          {playerXnew+=Math.sin(player.getDirection())*10000*ispeed;
        	           playerYnew+=Math.cos(player.getDirection())*10000*ispeed;
        	          }
        	      if(runningBackwards)
        	          {playerXnew-=Math.sin(player.getDirection())*10000*ispeed;
        	           playerYnew-=Math.cos(player.getDirection())*10000*ispeed;
        	          }                
        	      if(playerXnew != player.getX() || playerYnew != player.getZ())
        	          {//old position
        	           int xidx0 = (int)(player.getX()/65536);
        	           int yidx0 = (int)(player.getZ()/65536);
        	           //new position under test
        	           int xidx1 = (int)(playerXnew/65536);
        	           int yidx1 = (int)(playerYnew/65536);
        	           //get the voxel matching with the position of the player
        	           byte b = collisionMap[(yidx1*256)+xidx1];
        	           //if the voxel entirely described by the new position is empty
        	           //then the player can go to this new position
        	           if(b==EMPTY)
        	               {player.setX(playerXnew);
        	                player.setZ(playerYnew);
        	                bmoved=true;
        	               }
        	           else
        	               {if(collisionMap[(yidx0*256)+xidx1]==EMPTY)
        	                    {player.setX(playerXnew);
        	                     bmoved=true;				   
        	                    }
        	                else
        	                    {if(collisionMap[(yidx1*256)+xidx0]==EMPTY)
        	                         {player.setZ(playerYnew);
        	                          bmoved=true;				   
        	                         }
        	                     else
        	                         {bmoved=false;}
        	                    }
        	               }
        	          }		     	     
        	      //started player to move?
        	      if(!playerMoving && bmoved)
        	          {playerMoving = true;
        	           gameView.startMovingSound(1<<1);
        	          }
        	      else
        	          if(!bmoved && playerMoving)
        	              {// player stopped moving:
        	               playerMoving = false;
        	               gameView.stopMovingSound(1<<1);
        	              }       	      
	             }  // innerloop
             gameView.stopCarpetSound();	  
            }  // outerloop      
    }
    
    private final void tryToForceGarbageCollection(boolean forceEvenThoughNoGCCallNeeded){	
        if(forceEvenThoughNoGCCallNeeded==true || rt.freeMemory()<10485760)
            {long freedMemory=0;
             do{freedMemory=rt.freeMemory();
                rt.runFinalization();
                rt.gc();
                freedMemory=rt.freeMemory()-freedMemory;
               }
             while(freedMemory>0);
            }
    }
 
    final void performAtExit(){
        innerLoop=false;
        gameRunning=false;
    }

    // ============= walking bot support =====================    

    private final void stepBotFace(d3object obj)
    {
       // animation delay
       if (obj.getFaceskip() > 0) {
          obj.setFaceskip((short)(obj.getFaceskip()-1));
          return;
       }
       // default case: bot standing still
       if (obj.getSpeed() < 2) {
          obj.setFaceskip((short)3);
          obj.setIanim(obj.getIanim()+1);
	  /*for(BotModel bot:botList)
	      if(bot.getX()==obj.getX() && bot.getZ()==obj.getZ())
	          {//bot.setFace((short)((bot.getFace()+1)%11));		   
		   break;
		  } */
          if (obj.getIdamage() == 0)
             obj.setFace((short)(obj.getIanim() % 5));
          else
             obj.setFace((short)(11+(obj.getIanim() % 5)));
       }
    }

    private final void tryStepBot(d3object obj,double dxp,double dzp)
    {
       double  xnew = obj.getX();
       double  znew = obj.getZ();
       boolean bStepLeft  = false;
       boolean bStepRight = false;
       boolean bmoved = false;
       int     ispeed = 1;

       if (obj.getSleep2() > 0)
          obj.setSleep2(obj.getSleep2()-1);  // suspend walking (after rocket launch)
       else
       {
	if (bStepLeft) {
          xnew+=Math.sin(obj.getDir()-(fullCircle/4))*10000*obj.getSpeed();
          znew+=Math.cos(obj.getDir()-(fullCircle/4))*10000*obj.getSpeed();
	}
	if (bStepRight) {
          xnew+=Math.sin(obj.getDir()+(fullCircle/4))*10000*obj.getSpeed();
          znew+=Math.cos(obj.getDir()+(fullCircle/4))*10000*obj.getSpeed();
	}
	if (obj.getSpeed() >= 1) {
          // no matter if speed 1 or more, we always probe
          if (obj.getSpeed() >= 2)
             ispeed = obj.getSpeed()-1;
          xnew+=Math.sin(obj.getDir())*10000*ispeed/10;
          znew+=Math.cos(obj.getDir())*10000*ispeed/10;
	}
       }

       if (xnew != obj.getX() || znew != obj.getZ())
       {
          // how far can the bot walk, if at all?         
          int xidx1 = ((((int)xnew)>>16)&0xFF);
          int yidx1 = ((((int)znew)>>16)&0xFF);

          // about to leave area?
          boolean bstop = false;
          double dx, dz;
          d3object d3o;
          byte b;
          if (((b = botmap[(yidx1<<8)+xidx1])&0xFF) == 0xFF)
             bstop = true;
          else {
             d3area d3a = area[b];
             if (d3a == null)
        	bstop = true;
             else
             if (d3a != obj.getMyarea())
        	bstop = true;
             else 
             {
        	// research minimum distance to all other bots
        	// of the same area. make sure bots always
        	// keep some distance between them.
        	for (int n=0;n<d3a.getNmembers();n++) {
                   d3o = d3a.getAmember()[n];
                   if (d3o != null && d3o.getShape()==2 && d3o != obj) {
                      dx = d3o.getX()-xnew;
                      dz = d3o.getZ()-znew;
                      if ((Math.abs(dx) < (2<<16)) && (Math.abs(dz) < (2<<16))) {
                         bstop = true;
                         break;
                      }  // endif
                   }
        	}  // endfor area members
             }
          }  // endelse botmap

          // keep minimum distance also to player
          if (!bstop
        	&& (Math.abs(dxp) < (1<<16))
        	&& (Math.abs(dzp) < (1<<16))  )
             bstop = true;

          // check for obstacles and move
          if (!bstop) {
             b = movemap[(yidx1<<8)+xidx1];
             if (b==0) {
        	double oldX=obj.getX();
		double oldZ=obj.getZ();
		obj.setX(xnew);
        	obj.setZ(znew);
		//System.out.println("[slow mode] bot moved");
		//System.out.println("bot moved = "+xnew+" "+znew);
		//change the position of the bot using its old and its new coordinates
        //TODO: optimize the model to drive this loop useless
        for(BotModel bot:botList)
		    if(bot.getX()==oldX && bot.getZ()==oldZ)
	        	{bot.setX(xnew);
        	         bot.setZ(znew);
			 //System.out.println("[accelerated mode] bot moved");
			 break;			 
			}	            
        	bmoved = true;
             }
          }

       }  // endif position changed

       if (bmoved) {
          if (obj.getSpeed() < 2) {
             // this determines the bot speeds. the number
             // gets divided by 10. so 10==1.0, 5==0.5 etc.
             obj.setSpeed((short)8);
             obj.setIanim(0);
         //TODO: optimize the model to drive this loop useless
	     for(BotModel bot:botList)
		     if(bot.getX()==obj.getX() && bot.getZ()==obj.getZ())
	             {//bot.setFace((short)0);
		          bot.setRunning(true);	   
		          break;
		         } 
          }
          obj.setFaceskip((short)0);
          obj.setIanim(obj.getIanim()+1);
        //TODO: optimize the model to drive this loop useless
	  for(BotModel bot:botList)
	      if(bot.getX()==obj.getX() && bot.getZ()==obj.getZ())
	          {//bot.setFace((short)((bot.getFace()+1)%11));
		   bot.setRunning(true);		   
		   break;
		  } 
          if (obj.getIdamage()==0)
             obj.setFace(aBotWalk1[obj.getIanim() % aBotWalk1.length]);
          else
             obj.setFace((short)(11+aBotWalk1[obj.getIanim() % aBotWalk1.length]));
          // count walking bots, for stepObjects()
          nClBotsWalking++;
       }  else {
          if (obj.getSpeed() >= 2) {
             obj.setSpeed((short)1);
             obj.setIanim(0);
        //TODO: optimize the model to drive this loop useless 
        for(BotModel bot:botList)
	        if(bot.getX()==obj.getX() && bot.getZ()==obj.getZ())
	            {//bot.setFace((short)0);
		         bot.setRunning(false);		   
		         break;
		        } 
             obj.setFaceskip((short)0);
          }
       }  // endif bmoved
    }

    // =========================================

    // if player is standing in front of an image, show its title.
    private final void checkForImageTitles(){
       double dmod = Math.abs(player.getDirection() % (fullCircle/4));
       if (dmod < fullCircle/16 || dmod > (fullCircle/4-fullCircle/16)) 
           {
            double sx = Math.sin(player.getDirection());
            double sy = Math.cos(player.getDirection());
            int x1 = ((int)(player.getX() + sx*65536.0)>>16)&0xFF;
            int z1 = ((int)(player.getZ() + sy*65536.0)>>16)&0xFF;
            int ipix = map[(z1<<8)+x1];
            if (ipix<(iwallimglo-iwallplain))
                return;
            overMessage(imageInfo(ipix), 100, false);         
           }
    }    

    private final String imageInfo(int ipix) 
    {
       ipix += iwallplain;
       if (ipix >= iwallimglo && ipix <iwallimghi)
          return ainfoabs[(ipix-iwallimglo)%ainfoabs.length];
       if (ipix >= iwallimghi && ipix <iwallimghi+numHiWallImages)
          return ainfosur[(ipix-iwallimghi)%ainfosur.length];
       return "?"; // shouldn't happen
    }
    
    final void overMessage(String s, int duration, boolean bred) { 
       soveradd[0] = null;
       sover = s;
       lover = currentTime()+duration;      
    }
    
    private final void paintBufferString(String s){        
        gameView.pushInfoMessage(s);
    }
    
    private final boolean stepObjects(){
        boolean hasBeenKilled=false;
        double objectXnew;
        double objectZnew;
        int ispeed;
        boolean bhit;
        int iobj;
        int xidx1,yidx1;
        double xdiff,ydiff;
        final double hitrange  = 0.30 * 65536.0;
        final double rockrange = 0.10 * 65536.0;
        int ishape,ipix;
        int xplr,yplr;
        d3object obj;
        int nOldBotsWalking = nClBotsWalking;
        nClBotsWalking = 0;
        // cycle through all object slots
        for(counter=0; counter<numObjects; counter++)
            {// check where are active objects
             if((ispeed=object[counter].getSpeed())==0)
                 continue;
             obj = object[counter];
             if((ishape=obj.getShape())==ShapeExplo)
                 {// cycle explosion animation
                  if(obj.getFace()>=15)
                      {// remove explosion object after 16th frame
                       obj.setFace((short)0);
                       obj.setSpeed((short)0);
                       obj.setShape(-1);
                      }
                  else
                      obj.setFace((short)(obj.getFace()+1));
                  continue;
                 }
             if(ishape==2) // bot
                 {stepBotFace(obj);
                  //check if player is within firing range
                  xplr = (((int)player.getX())>>16)&0xFF;
                  yplr = (((int)player.getZ())>>16)&0xFF;
                  if(botmap[(yplr<<8)+xplr]==obj.getGroup()) 
                      {double dx = player.getX()-obj.getX(); // x-distance to player
                       double dz = player.getZ()-obj.getZ(); // y-distance to player
                       boolean bfire = true;
                       if((obj.getFlags() & 1) != 0 // a near-bot?
                               && (Math.abs(dx) > (3<<16) || Math.abs(dz) > (3<<16)) )
                           {bfire = false;}
                       if(playerVisibleFrom(obj))
                           {if(!obj.getSeenPlayer())
                                {obj.setSeenPlayer(true);
                                 // "NOW..."
                                gameView.playSound(6,(int)obj.getX(),(int)obj.getZ(),(int)player.getX(),(int)player.getZ());
                                }
                           }
                       else 
                           {//player not visible by bot
                            bfire = false;
                           }
                       if(bfire && (obj.getSleep() > 0)) 
                           {//just for initial sound
                            obj.setSleep(obj.getSleep()-1);   // bot may hesitate by random
                            bfire = false;
                           }
                       if(bfire)
                           {// bot wants to fire. calc direction to player.
                            obj.setDir(reverseDir(dx,dz));
		                    //System.out.println("[slow mode] bot turned"); 
		                    //set bot direction for the accelerated mode
                            //TODO: optimize the model to drive this loop useless
                            for(BotModel bot:botList)
		                        if(bot.getX()==obj.getX() && bot.getZ()==obj.getZ())
	        	                    {bot.setDirection(obj.getDir());
			                         //System.out.println("[accelerated mode] bot turned");
			                         break;
			                        }                 
		                    if(player.isAlive() && !player.isWinning() && 
		                            System.currentTimeMillis() > lastBotShotTime+500)
                                {if(tryLaunchBotRocket(counter, obj.getDir(),counter-IndexBots,obj.getFlags())) 
                                     obj.setSleep2(10); // avoid walking into own rocket
                                 lastBotShotTime=System.currentTimeMillis();
                                }
                            tryStepBot(obj,dx,dz);
                           }
                      }
                  continue;
                 }
             //the following is used only for rockets
             objectXnew = obj.getX() + Math.sin(obj.getDir())*10000*ispeed;
             objectZnew = obj.getZ() + Math.cos(obj.getDir())*10000*ispeed;
             // reached a discrete new map position?
             xidx1 = ((((int)objectXnew)>>16)&0xFF);
             yidx1 = ((((int)objectZnew)>>16)&0xFF);
             bhit = false;
             if(obj.getShape()==ShapeRocket)
                 {// create rocket's light trail
                  //lightFlash((int)objectXnew,(int)objectZnew,1,20);
                  // check for rocket<->object collision
                  for(iobj=0; iobj<numObjects; iobj++) 
                      {if(object[iobj].getShape()==-1
                           || object[iobj].getShape()==ShapeBush
                           || object[iobj].getShape()==ShapeExplo
                           || iobj==counter // ourselves
                         )
                           continue;
        	           xdiff = Math.abs(object[iobj].getX()-objectXnew);
        	           ydiff = Math.abs(object[iobj].getZ()-objectZnew);
        	           if(xdiff < hitrange && ydiff < hitrange) 
        	               {if(object[iobj].getShape()==ShapeRocket)
                                {// rocket nearby another rocket. check precise.
                                 if(xdiff < rockrange && ydiff < rockrange)
                                     {blastObject(object[iobj]);
                                      bhit = true;
                                     }
                                }
                            else
                                {// rocket hit a non-rocket object.
                                 blastObject(object[iobj]);
                                 bhit = true;
                                }
        	               }
                      }
                  //check for rocket<->player collision
                  xdiff = Math.abs(player.getX()-objectXnew);
                  ydiff = Math.abs(player.getZ()-objectZnew);
                  if(xdiff < hitrange && ydiff < hitrange && player.isAlive()) 
                      {// player is hit
                       bhit = true;
                       if(!bcheat)
                           player.decreaseHealth(20);
                       //lightFlash((int)objectXnew,(int)objectZnew,10,127);
                       gameView.stopMovingSound(1<<1);
                       gameView.playSound(2,(int)objectXnew,(int)objectZnew,(int)player.getX(),(int)player.getZ());
                       if(!player.isAlive())
                           {gameView.setCycle(1);         
                            innerLoop=false;
                            hasBeenKilled=true;
                            gameView.playTermSound();
                           }
                      }
                  else
                      if(xdiff < hitrange*3 && ydiff < hitrange*3) 
                          {//rocket just passed the player. make some noise,
                           //but not too often, and if it's not his own.
                           if(obj.getFlags()==0 && (currentTime() > lClLastPassBy + 1000))
                               {lClLastPassBy = currentTime();
                               gameView.playSound(11,(int)objectXnew,(int)objectZnew,(int)player.getX(),(int)player.getZ());
                               }
                          }
                 }
             if(map[(yidx1<<8)+xidx1] > -1) 
                 {// handle a wall impact
                  bhit = true;
                  ipix = map[(yidx1<<8)+xidx1];
                  //show impact on plain wall tile. this is done
                  //by stepping the wall texture one step higher.
                  if(ipix < numWallPlainText && (ipix&1)==0)
                      {//I change the state of my wall in the accelerated model
                       //collisionMap[(yidx1*256)+xidx1]=UNAVOIDABLE_AND_UNBREAKABLE_DIRTY;
		               switch(collisionMap[(yidx1*256)+xidx1])
		               {case UNAVOIDABLE_AND_UNBREAKABLE_UP:
		               {collisionMap[(yidx1*256)+xidx1]=UNAVOIDABLE_AND_UNBREAKABLE_UP_DIRTY;
		               break;
		               }
		               case UNAVOIDABLE_AND_UNBREAKABLE_DOWN:
		               {collisionMap[(yidx1*256)+xidx1]=UNAVOIDABLE_AND_UNBREAKABLE_DOWN_DIRTY;
		               break;
		               }
		               case UNAVOIDABLE_AND_UNBREAKABLE_LEFT:
		               {collisionMap[(yidx1*256)+xidx1]=UNAVOIDABLE_AND_UNBREAKABLE_LEFT_DIRTY;
		               break;
		               }
		               case UNAVOIDABLE_AND_UNBREAKABLE_RIGHT:
		               {collisionMap[(yidx1*256)+xidx1]=UNAVOIDABLE_AND_UNBREAKABLE_RIGHT_DIRTY;
		               break;
		               }
		               case UNAVOIDABLE_AND_UNBREAKABLE_UP_DOWN:
		               {collisionMap[(yidx1*256)+xidx1]=UNAVOIDABLE_AND_UNBREAKABLE_UP_DOWN_DIRTY;
		               break;
		               }
		               case UNAVOIDABLE_AND_UNBREAKABLE_UP_LEFT:
		               {collisionMap[(yidx1*256)+xidx1]=UNAVOIDABLE_AND_UNBREAKABLE_UP_LEFT_DIRTY;
		               break;
		               }
		               case UNAVOIDABLE_AND_UNBREAKABLE_UP_RIGHT:
		               {collisionMap[(yidx1*256)+xidx1]=UNAVOIDABLE_AND_UNBREAKABLE_UP_RIGHT_DIRTY;
		               break;
		               }
		               case UNAVOIDABLE_AND_UNBREAKABLE_DOWN_LEFT:
		               {collisionMap[(yidx1*256)+xidx1]=UNAVOIDABLE_AND_UNBREAKABLE_DOWN_LEFT_DIRTY;
		               break;
		               }
		               case UNAVOIDABLE_AND_UNBREAKABLE_DOWN_RIGHT:
		               {collisionMap[(yidx1*256)+xidx1]=UNAVOIDABLE_AND_UNBREAKABLE_DOWN_RIGHT_DIRTY;
		               break;
		               }
		               case UNAVOIDABLE_AND_UNBREAKABLE_LEFT_RIGHT:
		               {collisionMap[(yidx1*256)+xidx1]=UNAVOIDABLE_AND_UNBREAKABLE_LEFT_RIGHT_DIRTY;
		               break;
		               }
		               case UNAVOIDABLE_AND_UNBREAKABLE_UP_DOWN_LEFT:
		               {collisionMap[(yidx1*256)+xidx1]=UNAVOIDABLE_AND_UNBREAKABLE_UP_DOWN_LEFT_DIRTY;			      
		               break;
		               }
		               case UNAVOIDABLE_AND_UNBREAKABLE_UP_DOWN_RIGHT:
		               {collisionMap[(yidx1*256)+xidx1]=UNAVOIDABLE_AND_UNBREAKABLE_UP_DOWN_RIGHT_DIRTY;
		               break;
		               }
		               case UNAVOIDABLE_AND_UNBREAKABLE_UP_LEFT_RIGHT:
		               {collisionMap[(yidx1*256)+xidx1]=UNAVOIDABLE_AND_UNBREAKABLE_UP_LEFT_RIGHT_DIRTY;
		               break;
		               }
		               case UNAVOIDABLE_AND_UNBREAKABLE_DOWN_LEFT_RIGHT:
		               {collisionMap[(yidx1*256)+xidx1]=UNAVOIDABLE_AND_UNBREAKABLE_DOWN_LEFT_RIGHT_DIRTY;
		               break;
		               }
		               case UNAVOIDABLE_AND_UNBREAKABLE_UP_DOWN_LEFT_RIGHT:
		               {collisionMap[(yidx1*256)+xidx1]=UNAVOIDABLE_AND_UNBREAKABLE_UP_DOWN_LEFT_RIGHT_DIRTY;
		               break;
		               }		      
		               }
		               //I change the state of my wall in the slow model
                       map[(yidx1<<8)+xidx1]++;
		              }           
                  //lightFlash((int)objectXnew,(int)objectZnew,6,90);           
                  gameView.playSound(1,(int)objectXnew,(int)objectZnew,(int)player.getX(),(int)player.getZ());
                 }
             if(bhit)
                 {// no matter what kind of object was hit,
                  // change its shape now to animated explosion
                  obj.setShape(ShapeExplo);
                  obj.setFace((short)0);
                 }
             else
                 {obj.setX(objectXnew);
                  obj.setZ(objectZnew);
                 }

            }  // endfor all objects
        //any changes in the bot walking soundscape?
        if(nClBotsWalking > nOldBotsWalking)
            {if(nOldBotsWalking < 3)
                 {int nDiff = Math.min(3,nClBotsWalking)-nOldBotsWalking;
                  for(int i=0;i<nDiff;i++)
                      {// System.out.println("=> start "+(6+nOldBotsWalking));
        	           // startMovingSound(1<<(6+nOldBotsWalking));
        	           requestBotwalkSound(nOldBotsWalking);
        	           nOldBotsWalking++;
                      }
                  // System.out.println(""+nOldBotsWalking+" walkers");
                 }
            }
        else
            if(nClBotsWalking < nOldBotsWalking)
                {if(nClBotsWalking <= 0) 
                     {//just in case we miscounted:
                      unRequestBotwalkSound(0);
                      unRequestBotwalkSound(1);
                      unRequestBotwalkSound(2);
                     }
                 else
                     if(nOldBotsWalking <= 3) 
                         {int nDiff = nOldBotsWalking-nClBotsWalking;
                          for(int i=0;i<nDiff;i++) 
                              {nOldBotsWalking--;
                               //System.out.println("=> stop "+(6+nOldBotsWalking));
                               //stopMovingSound(1<<(6+nOldBotsWalking));
                               unRequestBotwalkSound(nOldBotsWalking);
                              }
                          // System.out.println(""+nOldBotsWalking+" walkers");
                         }
                }
        return(hasBeenKilled);
    }
    
    private final void requestBotwalkSound(int inum) {
        //System.out.println("req "+inum);
        aBwShouldPlay[inum%3] = true;
    }
    
    private final void unRequestBotwalkSound(int inum) {
        //System.out.println("ureq "+inum);
        aBwShouldPlay[inum%3] = false;
    }
    
    private final void initBotwalkSound() {
       for(int i=0;i<3;i++)
           {aBwShouldPlay[i]     = false;
            aBwIsPlaying[i]      = false;
            aBwPlayingSince[i]   = 0;
           }
    }
    
    // called per frame:
    private final void stepBotwalkSound() {  
       int nplaying=0;     
       for (int i=0;i<3;i++) {
          // have to start anything?
          if (aBwShouldPlay[i] && !aBwIsPlaying[i]) {
              gameView.startMovingSound(1<<(6+i));
             aBwIsPlaying[i]    = true;
             aBwPlayingSince[i] = currentTime();            
          }
          // have to stop anything? we only stop a sound
          // if it played for at least 500 msec. this avoids
          // a sound system overload on quick start/stop changes.
          if (!aBwShouldPlay[i]
        	&& aBwIsPlaying[i]
        	&& ((aBwPlayingSince[i]+800) < currentTime())
             )
          {
              gameView.stopMovingSound(1<<(6+i));
             aBwIsPlaying[i] = false;            
          }
          if (aBwIsPlaying[i])
             nplaying++;
       }
       //if (btell)
       //   System.out.println("botwalk "+nplaying);      
    }

    // used by bots, to tell if player can be seen
    private final boolean playerVisibleFrom(d3object obj) {
       double x1 = obj.getX();
       double z1 = obj.getZ();
       double x2 = player.getX();
       double z2 = player.getZ();
       double ddx = x2-x1;
       double ddz = z2-z1;
       int    idx = ((int)ddx)>>(16-3); // i.e. and multiply by 8
       int    idz = ((int)ddz)>>(16-3); // i.e. and multiply by 8
       int isteps = Math.max(Math.abs(idx),Math.abs(idz));
           isteps = Math.max(isteps,1); // FIX/1.0.3: potential division by zero
       int cx,cz;
       for (int i=0;i<=isteps;i++) {
          cx = (((int)(x1+i*ddx/isteps))>>16)&0xFF;
          cz = (((int)(z1+i*ddz/isteps))>>16)&0xFF;
          if (map[(cz<<8)+cx] != -1)
             return false;
       }
       return true;
    }
    
    // this is called after a rocket impact
    private final void blastObject(d3object obj){
       if(obj.getShape()==ShapeBot) 
           {// a bot was hit.
    	   
            //lightFlash((int)obj.getX(),(int)obj.getZ(),40,127);
            
            gameView.playSound(2,(int)obj.getX(),(int)obj.getZ(),(int)player.getX(),(int)player.getZ());
            //increase the damage of the bot
        //TODO: optimize the model to drive this loop useless
        for(BotModel bot:botList)
		    if(bot.getX()==obj.getX() && bot.getZ()==obj.getZ())
	            {bot.decreaseHealth(20);
		         if(bot.isAlive())
			         {//System.out.println("[accelerated mode] bot hurt");
			         }
		         else
			         {//remove the bot in the accelerated model
		              //botList.remove(bot);
		              //System.out.println("[accelerated mode] bot removed");
			         }
		         break;
		        }
	    // first hit on this bot?
	    if (obj.getIdamage()==0) {
               // then just change shape
               obj.setIdamage(obj.getIdamage()+1);
	       //System.out.println("[slow mode] bot hurt");	     
               return;
            }

            // bot is terminated
            gameView.playBotHit((int)obj.getX(),(int)obj.getZ(),(int)player.getX(),(int)player.getZ());
	    //remove the bot in the slow model
	    obj.getMyarea().removeMember(obj);
	    //System.out.println("[slow mode] bot removed");	    
	    if (obj.getMyarea().getNmembers()>0) 
            {
               // check if only near-bots remain in area
               d3area d3a = obj.getMyarea();
               boolean btruebots = false;
               int i;
               for (i=0;i<d3a.getAmember().length;i++)
        	  if(d3a.getAmember()[i]!=null
                      && d3a.getAmember()[i].getShape()==ShapeBot
                      && d3a.getAmember()[i].getFlags()==0) {
                     btruebots = true;
                     break;
        	  }
               // if so, switch them all to far-bots
               if (!btruebots)
        	for (i=0;i<d3a.getAmember().length;i++)
        	  if (   d3a.getAmember()[i]!=null
                      && d3a.getAmember()[i].getShape()==ShapeBot)
                     d3a.getAmember()[i].setFlags(0);
            }
            if (obj.getMyarea().getNmembers()==0) 
            {
               // no bots remaining in area
               d3area d3a = obj.getMyarea();
	       //register the area as cleared
	       for(int a=0;a<area.length;a++)
	           if(area[a]!=null && area[a]==d3a)
		       {clearedArea.add(Integer.valueOf(a));
			break;
		       }

               gameView.stopCarpetSound();
               gameView.playAreaCleared();
               overMessage("area cleared, establishing new art.", 5000, false);
               // allow respawn?
               if (d3a.getSpawnx() != -1)
        	  iClLastClearedArea = d3a.getIname();
               // remove alien art
               //switch between alien art and human art in the slow model
	       for (int i=0;i<d3a.getNimages();i++) {
        	  map[d3a.getAimagez()[i]*256+d3a.getAimagex()[i]]
                     += (iwallimghi-iwallimglo);
               }
               // lights up!
               d3a.setLightsUpCnt(200);
               d3a.setFoglevel(1);
               d3a.setLightlevel(256);
               // disable light sources to reduce cpu usage
               d3a.setNlights(0);	     
            }
            obj.setMyarea(null);
           }  
       else 
           {// a non-bot was hit. this could be
            // another rocket, or a deko
    	   
            //lightFlash((int)obj.getX(),(int)obj.getZ(),10,127);
            
            
            if (obj.getShape()==ShapeDeko) {
               if (obj.getFace()==0 || obj.getFace()>=3)
        	  gameView.playSound(3,(int)obj.getX(),(int)obj.getZ(),(int)player.getX(),(int)player.getZ());
               else // table etc.
        	  gameView.playSound(4,(int)obj.getX(),(int)obj.getZ(),(int)player.getX(),(int)player.getZ());
               // was this a light emitting object?
               if (obj.getFace()==5) {
        	  // so, if it' w/in an area, remove light source
        	  byte igroup =
                   botmap[ ((((int)obj.getZ())>>16)&0xFF)*256
                	  +((((int)obj.getX())>>16)&0xFF)];
        	  d3area d3a = area[igroup];
        	  if (d3a != null)
                     d3a.tryRemoveLight(((int)obj.getX())>>16,((int)obj.getZ())>>16);
               }
            }
            else
               gameView.playSound(1,(int)obj.getX(),(int)obj.getZ(),(int)player.getX(),(int)player.getZ());
           }
       // this spot may have been blocked by the object.
       // re-allow player movement here.
       //update the slow model
       movemap[ ((((int)obj.getZ())>>16)&0xFF)*256
               +((((int)obj.getX())>>16)&0xFF)] = 0;
       //update the accelerated model
       collisionMap[((int)(obj.getZ()/65536))*256+((int)(obj.getX()/65536))]=EMPTY;
       /*int www=((int)(obj.getZ()/65536))*256+((int)(obj.getX()/65536));
       System.out.println(""+www);*/
       // turn the object into an explosion object
       obj.setSpeed((short)1); // pseudo, for explo anim
       obj.setShape(ShapeExplo);
    }

    final void tryLaunchPlayerRocket(){
       /*It prevents the player from shooting 6 rockets together instantaneously*/
       if(currentTime()-lastShot<GameModel.timeBetweenShots)
           return;
       // a maximum of 3 active rockets applies.
       // if they're all currently active,
       // tryLaunch returns without any action.
       int irocket;
       d3object obj;
       boolean blaunched = false;
       final int maxactive = 6;

       // right rocket
       for (irocket=0; irocket<maxactive; irocket++)
          if (object[IndexPlayerRockets+irocket].getShape()==-1)
             break;
       if (irocket<maxactive)
       {
          obj = object[irocket];
          obj.setX(player.getX() - Math.sin(player.getDirection()+fullCircle/4)*10000*1);
          obj.setZ(player.getZ() - Math.cos(player.getDirection()+fullCircle/4)*10000*1);
          obj.setShape(ShapeRocket);
          obj.setFace((short)0);
          obj.setDir(player.getDirection());
          obj.setSpeed((short)3);
          obj.setFlags(1); // my own rocket
          blaunched = true;
       }

       // left rocket
       for (irocket=0; irocket<maxactive; irocket++)
          if (object[IndexPlayerRockets+irocket].getShape()==-1)
             break;
       if (irocket<maxactive)
       {
          obj = object[irocket];
          obj.setX(player.getX() - Math.sin(player.getDirection()+fullCircle*3/4)*10000*1);
          obj.setZ(player.getZ() - Math.cos(player.getDirection()+fullCircle*3/4)*10000*1);
          obj.setShape(ShapeRocket);
          obj.setFace((short)0);
          obj.setDir(player.getDirection());
          obj.setSpeed((short)3);
          obj.setFlags(1); // my own rocket
          blaunched = true;
       }

       if(blaunched)
           {gameView.playSound(0,(int)player.getX(),(int)player.getZ(),(int)player.getX(),(int)player.getZ());
	        lastShot=currentTime();
	       }
    }

    private final boolean tryLaunchBotRocket(int ifrom, double ddir, int irocket, int ibotflags){
       d3object obj;

       // there are two sets of rockets,
       // one for std, and one for dist bots.
       // both together shall not exceed 9 active rockets.
       if ((ibotflags&1)!=0) 
       {
          // take from dist bot contingent.
          irocket = IndexBotRockets + 5 + (irocket % 4);
          if (!bcheat && object[irocket].getShape()==-1)
          {
             obj = object[irocket];
             obj.setX(object[ifrom].getX());
             obj.setZ(object[ifrom].getZ());
             obj.setShape(ShapeRocket);
             obj.setFace((short)0);
             obj.setDir(ddir);
             obj.setSpeed((short)3);
             gameView.playSound(0,(int)obj.getX(),(int)obj.getZ(),(int)player.getX(),(int)player.getZ());
             return true;
          }
       }
       else 
       {
          // take from std bot contingent.
          irocket = IndexBotRockets + (irocket % 5);
          if (!bcheat && object[irocket].getShape()==-1)
          {
             obj = object[irocket];
             obj.setX(object[ifrom].getX());
             obj.setZ(object[ifrom].getZ());
             obj.setShape(ShapeRocket);
             obj.setFace((short)0);
             obj.setDir(ddir);
             obj.setSpeed((short)3);
             gameView.playSound(0,(int)obj.getX(),(int)obj.getZ(),(int)player.getX(),(int)player.getZ());
             return true;
          }
       }
       return false;
    }

    // reverse calculate a direction from a position delta
    private final double reverseDir(double dx, double dz){
       int n1;

       final double aquaddelta[] = {
          0.0, fullCircle/2.0, fullCircle/2.0, fullCircle
       };

       if (dx>0) {
          if (dz > 0) n1 = 0;
          else        n1 = 1;
       }  else  {
          if (dz > 0) n1 = 3;
          else        n1 = 2;
       }

       final double dthresh = 0.01 * 65536.0;
       if (Math.abs(dx) < dthresh) {
          if (dz > 0.0)
             return 0.0;
          else
             return fullCircle/2.0;
       }
       if (Math.abs(dz) < dthresh) {
          if (dx > 0.0)
             return fullCircle/4.0;
          else
             return fullCircle*3.0/4.0;
       }

       double d = Math.atan(dx/dz) + aquaddelta[n1];

       if (d < 0.0) d += fullCircle;

       return d;
    }   

    private final int nextRand(int i) {
       return((rg.nextInt()&65535)%i);
    }

    private final void respawnWithin(d3area d3a){
       d3object d3o;
       // clear the area
       for (int n=0;n<d3a.getNmembers();n++) {
          d3o = d3a.getAmember()[n];
          if (d3o != null) {
             d3o.setSpeed((short)0);
             d3o.setShape(-1);
          }
       }
       // switch area's images
       for (int n=0;n<d3a.getNimages();n++) {
          int ioff = d3a.getAimagez()[n]*256+d3a.getAimagex()[n];
          int itxt = map[ioff]+iwallplain;
          if (itxt>=iwallimglo && itxt<iwallimghi)
             map[ioff] += (iwallimghi-iwallimglo);
       }
       // warp player into there
       player.setX(d3a.getSpawnx()<<16);
       player.setZ(d3a.getSpawnz()<<16);
       player.setDirection(d3a.getPlayerdir());
       // lights up!
       d3a.setLightsUpCnt(200);
       d3a.setFoglevel(1);
       d3a.setLightlevel(256);
       // disable light sources to reduce cpu usage
       d3a.setNlights(0);
       // avoid double spawn
       d3a.setSpawnx(-1);
       d3a.setSpawnz(-1);
       d3a.setAnnounced(true);
       overMessage(d3a.name(),4000,false);
       gameView.stopCarpetSound();
    }
}
