/*This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation, version 2
  of the License.
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston,
  MA 02111-1307, USA.
*/

package main;

class PlayerModel{
    
    
    private static final int startingHealth=100;
    
    private int health;
    
    private boolean invincible;
    
    private boolean winner;
    
    private double x;
    
    private double y;
    
    private double z;
    
    private double direction;
    
    
    PlayerModel(){
        this.health=startingHealth;
	this.invincible=false;
	this.winner=false;
	this.x=0;
	this.y=0;
	this.z=0;
	this.direction=0;
    }
    
    void decreaseHealth(int damage){
        if(!invincible)
	    {this.health-=damage;
	     if(this.health<0)
	         this.health=0;
	    }
    }
    
    boolean isAlive(){
        return(this.health>0);
    }
    
    int getHealth(){
        return(health);
    }
    
    boolean isWinning(){
        return(winner);
    }
    void respawn(){
        this.health=startingHealth;
    }
    
    void setAsWinner(){
        this.winner=true;
    }
    
    void setAsLoser(){
        this.winner=false;
    }
    
    double getX(){
        return(x);
    }
    
    double getY(){
        return(y);
    }
    
    double getZ(){
        return(z);
    }
    
    double getDirection(){
        return(direction);
    }
    
    void setX(double x){
        this.x=x;
    }
    
    void setY(double y){
        this.y=y;
    }
    
    void setZ(double z){
        this.z=z;
    }
    
    void setDirection(double direction){
        this.direction=direction;
    }
}
