package main;

public enum MenuItemState {DISABLED,UNSELECTED,SELECTED,PRESSED}
