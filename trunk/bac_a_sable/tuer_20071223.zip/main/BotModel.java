/*This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation, version 2
  of the License.
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston,
  MA 02111-1307, USA.
*/

package main;

class BotModel{
    
    
    static final int startingHealth=40;
    
    private int health;
    
    private boolean invincible;
    
    private boolean winner;
    
    private double x;
    
    private double y;
    
    private double z;
    
    private double respawnX;
    
    private double respawnY;
    
    private double respawnZ;
    
    private double direction;
    
    private short face;
    
    private int areaIndex;
    
    private boolean running;
    
    private long time;
    
    static final int NO_AREA=-1;
    
    private static final int frameLength = 50;//in milliseconds
    
    private static final int frameCount = 11;
    
    
    BotModel(){
        this.health=startingHealth;
	this.invincible=false;
	this.winner=false;
	this.x=0;
	this.y=0;
	this.z=0;
	this.respawnX=x;
	this.respawnY=y;
	this.respawnZ=z;
	this.direction=0;
	this.face=0;
	this.areaIndex=NO_AREA;
	this.running=false;
	this.time=System.currentTimeMillis();
    }
    
    BotModel(double x,double y,double z){
        this.health=startingHealth;
	this.invincible=false;
	this.winner=false;
	this.x=x;
	this.y=y;
	this.z=z;
	this.respawnX=x;
	this.respawnY=y;
	this.respawnZ=z;
	this.direction=0;
	this.face=0;
	this.areaIndex=NO_AREA;
	this.running=false;
	this.time=System.currentTimeMillis();
    }
    
    
    void setAreaIndex(int areaIndex){
        this.areaIndex=areaIndex;
    }
    
    int getAreaIndex(){
        return(areaIndex);
    }
    
    void decreaseHealth(int damage){
        if(!invincible)
	    {this.health-=damage;
	     if(this.health<0)
	         this.health=0;
	    }
    }
    
    short getFace(){
        updateFace();	
	return(face);
    }
    
    boolean isAlive(){
        return(this.health>0);
    }
    
    int getHealth(){
        return(health);
    }
    
    boolean isWinning(){
        return(winner);
    }
    void respawn(){
        this.direction=0;
	this.face=0;
	this.invincible=false;
	this.winner=false;
        this.x=this.respawnX;
	this.y=this.respawnY;
	this.z=this.respawnZ;
        this.health=startingHealth;
    }
    
    void setAsWinner(){
        this.winner=true;
    }
    
    void setAsLoser(){
        this.winner=false;
    }
    
    double getX(){
        return(x);
    }
    
    double getY(){
        return(y);
    }
    
    double getZ(){
        return(z);
    }
    
    double getRespawnX(){
        return(respawnX);
    }
    
    double getRespawnY(){
        return(respawnY);
    }
    
    double getRespawnZ(){
        return(respawnZ);
    }
    
    double getDirection(){
        return(direction);
    }
    
    void setX(double x){
        this.x=x;
    }
    
    void setY(double y){
        this.y=y;
    }
    
    void setZ(double z){
        this.z=z;
    }
    
    void setDirection(double direction){
        this.direction=direction;
    }
    
    void setRunning(boolean running){
        if(running!=this.running)
	    toggleRunning();
    }
    
    private void toggleRunning(){
        this.running=!this.running;
	this.time=System.currentTimeMillis();
    }
    
    private void setFace(short face){
        this.face=face;	
    }
    
    private void updateFace(){
        if(!running)
	    setFace((short)(((System.currentTimeMillis()-time)/frameLength)%2));
	else
	    setFace((short)(((System.currentTimeMillis()-time)/frameLength)%frameCount));
    }
}
