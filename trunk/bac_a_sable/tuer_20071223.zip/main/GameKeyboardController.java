/*This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation, version 2
  of the License.
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston,
  MA 02111-1307, USA.
*/

package main;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

/**
 * This class has the role of being the controller 
 * (in the meaning of the design pattern "MVC") of
 * the keyboard events. It is a tool which is used by the
 * view and the model to communicate together. 
 * It avoids us to modify the model when we modify the view
 * and vice versa. It only handles the events related on
 * the keyboard strokes.
 *
 * @author Julien Gouesse
 */

public class GameKeyboardController implements KeyListener{
    
    
    private GameModel gameModel;

    private GameGLEventController gameView;
    
    private GameView gameFrame;
    
    
    public GameKeyboardController(GameModel gameModel,GameGLEventController gameView,GameView gameFrame){
        this.gameModel=gameModel;
        this.gameView=gameView;
        this.gameFrame=gameFrame;
    }
    
    
    public void keyPressed(KeyEvent event){
        switch(gameView.getCycle())
	        {case 0:
	             {break;}
	         case 1:
	             {if(gameView.getGLMenu()!=null)
	                  gameView.getGLMenu().keyPressed(event);
	              break;
	             }
	         case 2:
	             {gameModel.setRunningFast(event.isShiftDown());
	              switch(event.getKeyCode())
	                  {case KeyEvent.VK_UP:
	                       {if(!gameModel.getPlayerHit())
	                            gameModel.setRunningForwards(true);
	                        break;
	                       }
        	           case KeyEvent.VK_DOWN:
        		           {if(!gameModel.getPlayerHit())
        		                gameModel.setRunningBackwards(true);
        		            break;
			               }
        	           case KeyEvent.VK_LEFT:            
                           {if(!gameModel.getPlayerHit())
                                gameModel.setTurningLeft(true);
                	        break;
                           }
        	           case KeyEvent.VK_RIGHT:             
                           {if(!gameModel.getPlayerHit())
                                gameModel.setTurningRight(true);
                	        break;
                           }
        	           case KeyEvent.VK_W:
        		           {if(!gameModel.getPlayerHit())
        		                gameModel.setRunningForwards(true);
        		            break;
			               }
        	           case KeyEvent.VK_Z:
        		           {if(!gameModel.getPlayerHit())
        		                gameModel.setRunningForwards(true);
        		            break;
			               }
        	           case KeyEvent.VK_S:
        		           {if(!gameModel.getPlayerHit())
        		                gameModel.setRunningBackwards(true);
        		            break;
			               }
        	           case KeyEvent.VK_Q:            
                           {if(!gameModel.getPlayerHit())
                                gameModel.setLeftStepping(true);            
                	        break;
                           }
        	           case KeyEvent.VK_A:            
                           {if(!gameModel.getPlayerHit())
                                gameModel.setLeftStepping(true);            
                	        break;
                           }
        	           case KeyEvent.VK_D:             
                           {if(!gameModel.getPlayerHit())
                                gameModel.setRightStepping(true);           
                	        break;
                           }
        	           case KeyEvent.VK_ESCAPE:
	        	           {//it will require to be modified when the game will be online
	        	            gameModel.performAtExit();
                	        break;
                           }  
        	           case KeyEvent.VK_SPACE:
	        	           {if(!gameModel.getPlayerHit())
	        		            gameModel.tryLaunchPlayerRocket();
                           }                  
			          }
		          break;
		         }	     
	        }
    }

    public void keyTyped(KeyEvent event){
        switch(gameView.getCycle())
            {case 0:
                 {break;}
             case 1:
                 {if(gameView.getGLMenu()!=null)
                      gameView.getGLMenu().keyTyped(event);
                  break;
                 }
             case 2:
                 {break;}
            }
    }

    public void keyReleased(KeyEvent event){       
        switch(gameView.getCycle())
            {case 0:
                 {switch(event.getKeyCode()) 
                      {case KeyEvent.VK_F1:            
                           {gameView.setRecSnapShot(true);
                            break;
                           }
                      }
                  break;
                 }
             case 1:
                 {if(gameView.getGLMenu()!=null)
                      gameView.getGLMenu().keyReleased(event);
                  break;
                 }
             case 2:
                 {switch(event.getKeyCode()) 
                     {case KeyEvent.VK_UP:   
                          {gameModel.setRunningForwards(false);
                           break;
                          }
                      case KeyEvent.VK_DOWN: 
                          {gameModel.setRunningBackwards(false);
                           break;
                          }
                      case KeyEvent.VK_LEFT:            
                          {gameModel.setTurningLeft(false);
                           break;
                          }
                      case KeyEvent.VK_RIGHT:             
                          {gameModel.setTurningRight(false);
                           break;
                          }
                      case KeyEvent.VK_W:
                          {gameModel.setRunningForwards(false);
                           break;
                          }
                      case KeyEvent.VK_Z:
                          {gameModel.setRunningForwards(false);
                           break;
                          }
                      case KeyEvent.VK_S:
                          {gameModel.setRunningBackwards(false);
                           break;
                          }
                      case KeyEvent.VK_Q:            
                          {gameModel.setLeftStepping(false);            
                           break;
                          }
                      case KeyEvent.VK_A:            
                          {gameModel.setLeftStepping(false);            
                           break;
                          }
                      case KeyEvent.VK_D:             
                          {gameModel.setRightStepping(false);           
                           break;
                          }
                      case KeyEvent.VK_F7:
                          {gameModel.setBDistSnd(!gameModel.getBDistSnd());
                           gameFrame.setSoundOption("dist-snd:"+gameModel.getBDistSnd());
                           if(gameModel.getBDistSnd())
                               gameModel.overMessage("distance relative loudness", 4000, false);
                           else
                               gameModel.overMessage("static loudness", 4000, false);
                           break;
                          }
                      case KeyEvent.VK_F1:            
                          {gameView.setRecSnapShot(true);
                           break;
                          }
                      case KeyEvent.VK_F2:           
                          {gameView.setRecSnapFilm(!gameView.getRecSnapFilm());
                           break;
                          }
                      case KeyEvent.VK_F8:
                          {if(!gameModel.getPlayerHit())
                               gameModel.setBcheat(!gameModel.getBcheat());
                           break;
                          }
                      case KeyEvent.VK_P:
                          {if(!gameModel.getBpause())
                               {gameModel.setBpause(true);
                                gameView.setCycle(1);
                               }
                           break;
                          }
                     }                
                 break;
                }
            }       
    }
}
