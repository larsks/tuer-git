package main;

public enum GLProgressBarShape {HORIZONTAL_STRAIGHT,VERTICAL_STRAIGHT}
