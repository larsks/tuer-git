/*This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation, version 2
  of the License.
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston,
  MA 02111-1307, USA.
*/

/**
 * This class has the role of the model  
 * (in the meaning of the design pattern "MVC") 
 * of a 3D object
 * @author Julien Gouesse
 */

package main;

import com.sun.opengl.util.BufferUtil;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.util.List;
import java.util.Vector;


//TODO : add a mechanism to update the buffers inside the view 
//if the buffers inside the model are changed
class Object3DModel{

    
    //contains a list of coordinates buffer, a coordinates buffer per frame
    protected List<FloatBuffer> coordinatesBuffersList;
    
    protected long lastStartOfAnimationTime;//last start of an animation 
    
    protected float x;
    
    protected float y;
    
    protected float z;
    
    protected float horizontalDirection;
    
    protected float verticalDirection;
    
    protected int currentFrameIndex;
    
    protected int currentAnimationIndex;
    
    protected List<AnimationInfo> animationList;
    
    protected Object3DController controller;
    
    // 3 vertices + 2 texture coordinates
    protected final static int coordinatesPerPrimitive = 5;
    
    
    Object3DModel(){
        this.coordinatesBuffersList=new Vector<FloatBuffer>();	
	this.lastStartOfAnimationTime=System.currentTimeMillis();
	this.x=0.0f;
	this.y=0.0f;
	this.z=0.0f;
	this.horizontalDirection=0.0f;
	this.verticalDirection=0.0f;
	this.currentFrameIndex=0;
	this.currentAnimationIndex=0;
	this.animationList=new Vector<AnimationInfo>();
	this.controller=null;
    }
    
    Object3DModel(float x,float y,float z){
        this.coordinatesBuffersList=new Vector<FloatBuffer>();	
	this.lastStartOfAnimationTime=System.currentTimeMillis();
	this.x=x;
	this.y=y;
	this.z=z;
	this.horizontalDirection=0.0f;
	this.verticalDirection=0.0f;
	this.currentFrameIndex=0;
	this.currentAnimationIndex=0;
	this.animationList=new Vector<AnimationInfo>();
	this.controller=null;
    }
    
    Object3DModel(float x,float y,float z,List<FloatBuffer> coordinatesBuffersList){
        this.coordinatesBuffersList=coordinatesBuffersList;	
	this.lastStartOfAnimationTime=System.currentTimeMillis();
	this.x=x;
	this.y=y;
	this.z=z;
	this.horizontalDirection=0.0f;
	this.verticalDirection=0.0f;
	this.currentFrameIndex=0;
	this.currentAnimationIndex=0;
	this.animationList=new Vector<AnimationInfo>();
	this.controller=null;
    }
    
    Object3DModel(float x,float y,float z,List<FloatBuffer> coordinatesBuffersList,List<AnimationInfo> animationList){
        this.coordinatesBuffersList=coordinatesBuffersList;	
	this.lastStartOfAnimationTime=System.currentTimeMillis();
	this.x=x;
	this.y=y;
	this.z=z;
	this.horizontalDirection=0.0f;
	this.verticalDirection=0.0f;
	this.currentFrameIndex=0;
	this.currentAnimationIndex=0;
	this.animationList=new Vector<AnimationInfo>();
	this.animationList.addAll(animationList);
	this.controller=null;
    }
    
    
    List<FloatBuffer> getCoordinatesBuffersList(){
        return(coordinatesBuffersList);
    }
    
    FloatBuffer getCoordinatesBuffer(int index){
        return(coordinatesBuffersList.get(index));
    }
    
    void setCoordinatesBuffersList(List<FloatBuffer> coordinatesBuffersList){
        this.coordinatesBuffersList=coordinatesBuffersList;
    }
    
    void setCoordinatesBuffer(int index,FloatBuffer coordinatesBuffer){
        if(index<this.coordinatesBuffersList.size())
	    this.coordinatesBuffersList.set(index,coordinatesBuffer);
	else
	    if(index==this.coordinatesBuffersList.size())
	        this.coordinatesBuffersList.add(coordinatesBuffer);
    }       
    
    long getLastStartOfAnimationTime(){
        return(lastStartOfAnimationTime);
    }
    
    void setLastStartOfAnimationTime(long lastStartOfAnimationTime){
        this.lastStartOfAnimationTime=lastStartOfAnimationTime;
    }
    
    float getX(){
        return(x);
    }
    
    void setX(float x){
        this.x=x;
    }
    
    float getY(){
        return(y);
    }
    
    void setY(float y){
        this.y=y;
    }
    
    float getZ(){
        return(z);
    }
    
    void setZ(float z){
        this.z=z;
    }
    
    float getHorizontalDirection(){
        return(horizontalDirection);
    }
    
    void setHorizontalDirection(float horizontalDirection){
        this.horizontalDirection=horizontalDirection;
    }
    
    float getVerticalDirection(){
        return(verticalDirection);
    }
    
    void setVerticalDirection(float verticalDirection){
        this.verticalDirection=verticalDirection;
    }
    
    int getCurrentFrameIndex(){
        return(currentFrameIndex);
    }
    
    void setCurrentFrameIndex(int currentFrameIndex){
        this.currentFrameIndex=currentFrameIndex;	
    }
            
    int getCurrentAnimationIndex(){
        return(currentAnimationIndex);
    }
    
    void setCurrentAnimationIndex(int currentAnimationIndex){
        this.currentAnimationIndex=currentAnimationIndex;	
    }
    
    void toggleCurrentAnimationIndex(int currentAnimationIndex){
        this.currentAnimationIndex=currentAnimationIndex;
	this.lastStartOfAnimationTime=System.currentTimeMillis();
    }
    
    List<AnimationInfo> getAnimationList(){
        return(animationList);
    }
    
    AnimationInfo getAnimation(int index){
        return(animationList.get(index));
    }
    
    void setAnimationList(List<AnimationInfo> animationList){
        this.animationList=animationList;
    }
    
    Object3DController getController(){
        return(controller);
    }
    
    void setController(Object3DController controller){
        this.controller=controller;
    }
    
    void setLocation(float x,float y,float z){
        this.x=x;
	this.y=y;
	this.z=z;
    }
    
    void translate(float dx,float dy,float dz){
        this.x+=dx;
	this.y+=dy;
	this.z+=dz;
    }
    
    void updateFrameIndex(){
        this.currentFrameIndex=(int)((((System.currentTimeMillis()-lastStartOfAnimationTime)*
	                       animationList.get(currentAnimationIndex).getFramesPerSecond())/1000)
			        %animationList.get(currentAnimationIndex).getFrameCount());	
    }
}
