/**
 * Generic Sound System Interface
 * This is required to allow different implementations
 * of sound systems, and to enable "trial and error"
 * loading of them.
 *
 * @author Vincent Stahl
 */

package stahlforce;

public abstract interface d3soundsys {
   public void    attach(java.applet.Applet a, String surlbase, boolean bloc);
   public boolean openSound();
   public void    closeSound();
   public boolean loadSounds();
   public void    stepSoundLoading();
   public void    stepMusic();
   public void    restartMusic();
   public String  soundInfo();
   public void    playSound(int id,int x,int z);
   public void    playSound(int id,int x,int z,int px,int pz);
   public void    playBotGreeting();
   public void    playBotHit(int x,int z,int px,int pz);
   public void    playAreaCleared();
   public void    playTermSound();
   public void    startMovingSound(int iMask);
   public void    stopMovingSound(int iMask);
   public void    startCarpetSound();
   public void    stopCarpetSound();
   public void    stopAllSounds();
   public void    setSoundOption(String s);
}
