package stahlforce;

import java.applet.Applet;
import java.applet.AudioClip;
import java.net.URL;

/**
 * Sound System For JDK 1, providing Art Attack Sounds
 * This will be loaded and used automatically by the
 * main applet IF the browser is not able to provide a JDK 2 
 * sound environment.
 *
 * @author Vincent Stahl, Julien Gouesse
 */

public class d3sound1
   implements d3soundsys
{
   // - - - - generic stuff - - - - 
   boolean bSound = false;
   java.applet.Applet clApplet = null;
   java.util.Random rg = null;
   String urlbase = "";
   boolean bLocal = false;

   void status(String s) { /*clApplet.getAppletContext().showStatus(s); */}
   int nextRand(int i) { return (rg.nextInt()&65535)%i; }
   long currentTime() { return System.currentTimeMillis(); }

   // - - - - - JDK dependent stuff - - - - -
   AudioClip aSound[] = null;
   boolean atoload[]  = null;
   boolean bStepSoundLoading=false;
   public void attach(java.applet.Applet a, String surlbase, boolean bloc) {
      clApplet = a;
      urlbase = surlbase;
      bLocal = bloc;
   }
   public boolean openSound() {
      bSound = true;
      rg = new java.util.Random(863153);
      System.out.println(soundInfo());
      return true;
   }
   public String soundInfo() { return "Simple Sound System (Java 1)"; }
   public void closeSound() { }
   final static String aSoundFiles[] = {
      "launch",      // 0 immediately
      "hit",         // "1"
      "hit2",
      "hit3",
      "hit4",
      "applause",    // 5
      "bot1",        // 6
      "bot2",        // 7
      "bot3",        // 8
      "bot4",        // 9
      "term3",       // 10

      "carpet",      // 11
      "walk",        // 12
      "anno",        // 13
      "mus1theone",  // 14
      "mus2evil",    // 15
      "mus3beyond",  // 16
      "launch",      // interleave

      "rockpass",    // 18 NEW/1.1.0, mapped from "11"
      "botwalk1",    // 19 NEW/1.1.0
      "botwalk2",    // 20 NEW/1.1.0
      "botwalk3",    // 21 NEW/1.1.0
   };
   AudioClip getClip(String sFileBase)
      throws Throwable
   {
      
      /*if (bLocal)*/
         /*return clApplet.getAudioClip(new URL("file:snd/"+sFileBase+".au"));*/
	 return Applet.newAudioClip(new URL("./snd/"+sFileBase+".au"));
      /*else
         return clApplet.getAudioClip(new URL(urlbase+"snd/"+sFileBase+".au"));*/
   }
   public boolean loadSounds() {
      aSound  = new AudioClip[aSoundFiles.length];
      atoload = new boolean[aSoundFiles.length];
      for (int i=0;i<aSound.length;i++) {
         aSound[i]  = null;
         atoload[i] = true;
      }
      try {
         for (int i=0;i<2;i++) {
            status("loading sounds ("+(i+1)+"/"+aSound.length+")");
            aSound[i]  = getClip(aSoundFiles[i]);
            atoload[i] = false;
         }
         aSound[12]  = getClip(aSoundFiles[12]);
         aSound[17]  = getClip(aSoundFiles[17]);
         atoload[12] = atoload[17] = atoload[11] = false;
         bStepSoundLoading = true;
         return true;
      }  catch (Throwable e) {
         System.out.println(""+e);
         return false;
      }
   }

   int  iPlayQueue = -1;
   long lPlayQueue = 0;
   int  iStopQueue = -1;
   long lStopQueue = 0;

   void setStopQueue(int iidx, long ltime) {
      if (iStopQueue!=-1)
         aSound[iStopQueue].stop();
      iStopQueue = iidx;
      lStopQueue = ltime;
   }

   public void stepMusic() { }
   public void restartMusic() { }

   public void stepSoundLoading() {
      if (iPlayQueue!=-1 && lPlayQueue < currentTime()) {
         playSound(iPlayQueue,128<<16,128<<16);
         iPlayQueue = -1;
      }
      if (iStopQueue!=-1 && lStopQueue < currentTime()) {
         aSound[iStopQueue].stop();
         iStopQueue = -1;
      }
      if (!bStepSoundLoading)
         return;
      try {
      int i;
      for (i=0;i<aSound.length;i++)
         if (atoload[i]) {
            status("loading sounds ("+(i+1)+"/"+aSound.length+")");
            aSound[i] = getClip(aSoundFiles[i]);
            atoload[i] = false;
            if (aSoundFiles[i].equals("anno"))
               aSound[i].play();
            break;
         }
      if (i==aSound.length)
         bStepSoundLoading = false;
      }  catch (Throwable e) {
         System.out.println(""+e);
         bStepSoundLoading = false;
      }
   }
   int aleave[]  = { 0,17 };
   int aleavecnt = 0;
   public void playSound(int id,int x,int z) {
      playSound(id,x,z,-1,-1);
   }
   public void playSound(int id,int x,int z,int px,int pz) 
   {
      // mappings for java2 call compatibility:
      if (id==11) id=18;
      if (id > aSound.length-1 || atoload[id])
         return;
      if (id==0)
         id = aleave[(++aleavecnt)&1];
      if (aSound[id] != null)
         aSound[id].play();
   }

   public void playBotGreeting() { 
      playSound(6,128<<16,128<<16); 
   }
   public void playBotHit(int x,int z,int px,int pz) {
      playSound(7+nextRand(3),128<<16,128<<16);
   }
   int asndlen[] = {
      34936, // mus1theone.au
      33418, // mus2evil.au
      37308, // mus3beyond.au
   };
   public void playAreaCleared() {
      playSound(5,128<<16,128<<16);
      int isnd = nextRand(3);
      aSound[14+isnd].loop();
      int ilen = asndlen[isnd]*1000/8000 * 2;
      setStopQueue(14+isnd,currentTime()+ilen);
   }
   public void playTermSound() {
      lPlayQueue = currentTime() + 200;
      iPlayQueue = 10;
   }

   public void startMovingSound(int iMask) { 
      if ((iMask & (1<<1))!=0 && aSound[12]!=null) {
         aSound[12].stop();
         aSound[12].loop();
      }
      if ((iMask & (1<<6))!=0 && aSound[19]!=null) {
         aSound[19].stop();
         aSound[19].loop();
      }
      if ((iMask & (1<<7))!=0 && aSound[20]!=null) {
         aSound[20].stop();
         aSound[20].loop();
      }
      if ((iMask & (1<<8))!=0 && aSound[21]!=null) {
         aSound[21].stop();
         aSound[21].loop();
      }
   }
   public void stopMovingSound(int iMask) { 
      if ((iMask & (1<<1))!=0 && aSound[12]!=null)
         aSound[12].stop();
      if ((iMask & (1<<6))!=0 && aSound[19]!=null)
         aSound[19].stop();
      if ((iMask & (1<<7))!=0 && aSound[20]!=null)
         aSound[20].stop();
      if ((iMask & (1<<8))!=0 && aSound[21]!=null)
         aSound[21].stop();
   }
   public void startCarpetSound() { }
   public void stopCarpetSound() { }
   public void stopAllSounds() {
      for (int i=0;i<aSound.length;i++) {
         if (aSound[i]!=null && !atoload[i])
            aSound[i].stop();
      }
   }
   public void setSoundOption(String sOpt) {
   }
}
