package stahlforce;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

/**
 * This class has the role of being the controller 
 * (in the meaning of the design pattern "MVC") of
 * the keyboard events. It is a tool which is used by the
 * view and the model to communicate together. 
 * It avoids us to modify the model when we modify the view
 * and vice versa. It only handles the events related on
 * the keyboard strokes.
 *
 * @author Julien Gouesse
 */

public class GameKeyboardController implements KeyListener{
    
    
    private d3caster gameModel;
    
    
    public GameKeyboardController(d3caster gameModel){
        this.gameModel=gameModel;
    }
    
    
    public void keyPressed(KeyEvent event){    
	gameModel.setRunningFast(event.isShiftDown());
	switch(event.getKeyCode())
	    {case KeyEvent.VK_UP:
        	 {gameModel.setRunningForwards(true);
        	  break;
		 }
             case KeyEvent.VK_DOWN:
        	 {gameModel.setRunningBackwards(true);
        	  break;
		 }
             case KeyEvent.VK_LEFT:            
                 {gameModel.setLeftStepping(true);            
                  break;
                 }
             case KeyEvent.VK_RIGHT:             
                 {gameModel.setRightStepping(true);             
                  break;
                 }
             case KeyEvent.VK_ESCAPE:
	         {gameModel.performAtExit();}          
	    }
    }

    public void keyTyped(KeyEvent event){}

    public void keyReleased(KeyEvent event){       
	switch (event.getKeyCode()) 
	{
           case KeyEvent.VK_UP:   {gameModel.setRunningForwards(false);break;}
           case KeyEvent.VK_DOWN: {gameModel.setRunningBackwards(false);break;}
           case KeyEvent.VK_LEFT: {gameModel.setLeftStepping(false);break;}
           case KeyEvent.VK_RIGHT:{gameModel.setRightStepping(false);break;}

           case KeyEvent.VK_X:
              if(gameModel.getPlayerHit() || gameModel.getPlayerWins()) 
	          {gameModel.setInnerLoop(false);
                   if(gameModel.getPlayerWins())
                       gameModel.setIClLastClearedArea(-1);
                  }
              break;
           case KeyEvent.VK_L:
              for (int i=0; i<65536; i++)
        	 gameModel.setLightMap(i,(short)(gameModel.getLightMap(i)/2));
              break;

           case KeyEvent.VK_F5:
              if(!gameModel.getBLightPerPix()) 
	          {gameModel.setBLightPerPix(true);
        	   gameModel.setBLightHiRes(false);
                  } 
	      else 
	          {gameModel.setBLightHiRes(!gameModel.getBLightHiRes());
        	   if(!gameModel.getBLightHiRes())
                       gameModel.setBLightPerPix(false);
                  }
	      if(gameModel.getBLightHiRes())
                  gameModel.setNLightMap2Size(65536*16); 
	      else
	          gameModel.setNLightMap2Size(65536*4);
              for(int i=0;i<gameModel.getNLightMap2Size();i++)
        	  gameModel.setLightMap2(i,(byte)127);
              if(!gameModel.getBLightPerPix())
        	  gameModel.overMessage("low detail lightmap", 4000, false);
              else
              if(!gameModel.getBLightHiRes())
        	  gameModel.overMessage("medium detail lightmap", 4000, false);
              else
        	  gameModel.overMessage("high detail lightmap", 4000, false);
              break;

           case KeyEvent.VK_F6:
              gameModel.setBFog(!gameModel.getBFog());
              if(gameModel.getBFog())
        	  gameModel.overMessage("fog on", 4000, false);
              else
        	  gameModel.overMessage("fog off", 4000, false);
              break;

           case KeyEvent.VK_F7:
              gameModel.setBDistSnd(!gameModel.getBDistSnd());
              gameModel.setSoundOption("dist-snd:"+gameModel.getBDistSnd());
              if(gameModel.getBDistSnd())
        	 gameModel.overMessage("distance relative loudness", 4000, false);
              else
        	 gameModel.overMessage("static loudness", 4000, false);
              break;

           case KeyEvent.VK_F1:            
        	 gameModel.setRecSnapShot(true);
                 break;
           case KeyEvent.VK_F2:           
        	 gameModel.setRecSnapFilm(!gameModel.getRecSnapFilm());
                 break;
	}

	if(event.getKeyChar()=='p')
            gameModel.setBpause(!gameModel.getBpause());
     }
}
