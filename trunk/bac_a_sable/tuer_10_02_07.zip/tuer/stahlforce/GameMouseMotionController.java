package stahlforce;


import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.InputEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

/**
 * This class has the role of being the controller 
 * (in the meaning of the design pattern "MVC") of
 * the keyboard events. It is a tool which is used by the
 * view and the model to communicate together. 
 * It avoids us to modify the model when we modify the view
 * and vice versa. It only handles the events related on
 * the mouse actions, including motions and clicks.
 * It uses a Robot to move the cursor which may be a 
 * problem when using it inside an applet, this kind of
 * action may be stricty restricted by the security manager
 *
 * @author Julien Gouesse
 */

public class GameMouseMotionController implements MouseListener,MouseMotionListener{


    private boolean autoCenter;
    
    private boolean isCentering;
    
    private int screenWidth;
    
    private int screenHeight;
    
    private Robot robot;
    
    private int centerx;
    
    private int centery;
    
    private int oldx;
    
    private int oldy;
    
    private int margin;
    
    private d3caster gameFrame;
    
    
    public GameMouseMotionController(boolean autoCenter,d3caster gameFrame,int margin){
        this(autoCenter,gameFrame,margin,(gameFrame.getScreenWidth()/2)-1,(gameFrame.getScreenHeight()/2)-1);
    }
    
    public GameMouseMotionController(boolean autoCenter,d3caster gameFrame,int margin,int centerx,int centery){        
	this.autoCenter=autoCenter;
	this.isCentering=true;
	this.gameFrame=gameFrame;
	this.screenWidth=gameFrame.getScreenWidth();
	this.screenHeight=gameFrame.getScreenHeight();
	if(autoCenter)
	    if(margin<0)
	        throw new java.lang.IllegalArgumentException("the margin cannot be negative when using auto-center");
	    else
	        if(margin>screenWidth)
		    throw new java.lang.IllegalArgumentException("the margin cannot be greater than the screen width when using auto-center");
		else
		    if(margin>screenHeight)
		        throw new java.lang.IllegalArgumentException("the margin cannot be greater than the screen height when using auto-center");
		    else
		        this.margin=margin;
	else 
	    this.margin=margin;	
	try{
	    robot=new Robot(gameFrame.getGraphicsConfiguration().getDevice());
	   }
	catch(AWTException e)
	{System.out.println("problem during new Robot() call : "+e);}		
	this.centerx=centerx;
	this.centery=centery;
	this.warpCursorAtCenter();
	//this.isCentering=false;		
    }
    
    
    void giveFocus(){
        robot.mousePress(InputEvent.BUTTON1_MASK);
    }
    
    private void warpCursorAt(int x,int y){
        //check if correct
	robot.mouseMove(x,y);
    }
    
    private void warpCursorAtCenter(){
        robot.mouseMove(this.centerx,this.centery);
    }
    
    private boolean cursorAtEdge(){        
	return(oldx<=margin||oldx>=screenWidth-margin-1||oldy<=margin||oldy>=screenHeight-margin-1);
    }
    
    public void mouseClicked(MouseEvent me){
        
    }
    
    public void mouseEntered(MouseEvent me){
        if(!autoCenter)
	    {oldx=me.getX();
	     oldy=me.getY();
	    }
    }
    
    public void mouseExited(MouseEvent me){
        if(autoCenter)
	    {this.isCentering=true;
	     this.warpCursorAtCenter();
	     mouseMoved(me);
	    }
    }
    
    public void mousePressed(MouseEvent me){       
	switch(me.getButton())
	    {case MouseEvent.BUTTON1:{if(!gameFrame.getPlayerHit())
	                                  gameFrame.tryLaunchPlayerRocket();			              
				      break;
				     }
	     case MouseEvent.BUTTON2:{break;}
	     case MouseEvent.BUTTON3:{break;}
	    }
	
	
    }
    
    public void mouseReleased(MouseEvent e){
        
    }
           
    public void mouseMoved(MouseEvent me){        
	if(!isCentering)
	    {byte shiftx,shifty;
	     int x,y;
	     x=me.getX();
	     y=me.getY();
	     if(x>oldx)
	         shiftx=1;
	     else
	         if(x<oldx)
		     shiftx=-1;
		 else
		     shiftx=0;
	     if(y>oldy)
	         shifty=1;
	     else
	         if(y<oldy)
		     shifty=-1;
		 else
		     shifty=0;     
	     gameFrame.handleMouseMotion(shiftx,shifty);
	     oldx=x;
	     oldy=y;
	     if(autoCenter&&cursorAtEdge())
	         {this.isCentering=true;
		  warpCursorAtCenter();
		 }
	    }
	else
	    {this.isCentering=false;
	     this.oldx=this.centerx;
	     this.oldy=this.centery;	     
	    }
    }
    
    public void mouseDragged(MouseEvent me){
        mouseMoved(me);
    }

}
