/**
 *This class performs the main tasks in the game. 
 *
 *@author Vincent Stahl, Julien Gouesse
 */

/* 
  TODO LIST
  
  use -Xss..., -Xms...M and -Xmx..M options to increase the size of the heap 
  check how the collisions are tested
  reduce the use of PixelGrabber
  display a menu or at least an image during the loading  
*/
/*
  atext[...] are changed only in prepareImageMasks() and runImageLoader().
  Therefore, we could store the files on the video card AND use accelerated filtering
             (Texture, TextureIO, TextureData, ImageUtil, FileUtil)
	         OR
  create multiple filter classes with RGBImageFilter (FilteredImageSource)
*/
/*gl.glGenTextures(1,texture);
  gl.glBindTexture(GL.GL_TEXTURE_2D,texture[0]);
  gl.glTexParameteri(GL.GL_TEXTURE_2D,GL.GL_TEXTURE_MIN_FILTER,GL.GL_NEAREST);
  gl.glTexParameteri(GL.GL_TEXTURE_2D,GL.GL_TEXTURE_MAG_FILTER,GL.GL_NEAREST);
  gl.glTexImage2D(GL.GL_TEXTURE_2D,0,4,width,height,0,GL.GL_BGRA,GL.GL_UNSIGNED_BYTE,data);
                    OR
	Texture texture=TextureIO.newTexture(filename,false);
	
  I will create only textures, modify pixels when needed with RGBA GL filters
  -> no more storage for all the pixels AND no more PixelGrabber
  
  select AUXi buffer with GLDrawBuffer -> draw the texture with glDrawPixels
  -> draw the modification -> get the texture pixels with GLReadPixels
  -> rebuild the texture with the same ID
*/
/*
          d3caster, a 3-D java raycasting game engine 
         =============================================
         rel. 1.1.0, Vincent Stahl, www.stahlforce.com

         OPTIMISED BY JULIEN GOUESSE
	 
	 require at least Java 1.5 and JOGL Beta 5
*/

package stahlforce;

import com.sun.opengl.util.GLUT;
import com.sun.opengl.util.BufferUtil;
import com.sun.opengl.util.Screenshot;
import java.awt.Color;
import java.awt.AWTException;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.GraphicsConfiguration;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.awt.Cursor;
import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.Point;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseMotionListener;
import java.awt.image.BufferedImage;
import java.awt.image.ColorModel;
import java.awt.image.ImageObserver;
import java.awt.image.MemoryImageSource;
import java.awt.image.PixelGrabber;
import java.awt.image.VolatileImage;
import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.Buffer;
import java.nio.BufferOverflowException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.IntBuffer;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Random;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
/*use rather the line below if you use an other JOGL version*/
/*import net.java.games.jogl.*;*/
import javax.media.opengl.GL;
import javax.media.opengl.GLAutoDrawable;
import javax.media.opengl.GLCanvas;
import javax.media.opengl.GLCapabilities;
import javax.media.opengl.GLDrawable;
import javax.media.opengl.GLDrawableFactory;
import javax.media.opengl.GLEventListener;
import javax.media.opengl.glu.GLU;

final class d3caster extends Frame{
   
   
    private GLCanvas canvas;//canvas for OpenGL rendering
    
    private GL gl;
    
    private GLU glu;
   
    private IntBuffer pixelsBuffer;//pixel buffer for raycasting and for glDrawPixels
    
    private int pixelsBufferSize;
    
    private Toolkit toolkit=Toolkit.getDefaultToolkit();
   
    private final Runtime rt=Runtime.getRuntime();   
    
    private GameMouseMotionController gameMouseMotionController;//controls the mouse
    
    private GameGLEventController gameGLEventController;
    
    private boolean lookingDown;
    
    private boolean lookingUp;
    
    private long lastShot;//time of last shof of rocket
    
    private final static long timeBetweenShots=500;
    
    private boolean bcheat  = false;
    private boolean bFog    = false;   // enable fog
    private boolean bDistSnd= true;    // sound loudness relative to distance

    // resolution setup
    private final int tresls = 0+2;       // left-shift    1  2  3
    private final int treslx = 6+tresls;  // absolute shift
    private final int tresf  = 1<<tresls; //              128 256 512
    private final int tres   = 64*tresf;  // texture res. *2 *4 *8

    // basic setup
    private final static double fullCircle = Math.PI*2;
    private final int numWallPlainText = 10;
    private final int numWallPlainNetto= numWallPlainText/2;
    private final int numLoWallImages  = 27; // 240804: 20
    private final int numHiWallImages  = numLoWallImages; // MUST be identical
    private final int numFloorTextures = 3;
    private final int numCeilTextures  = 2; // 0==inside, 1==outside

    // generic helper variables. in "decent" programming,
    // these should be declared locally, when they're used.
    // for maximum performance, they are declared globally,
    // reducing the creation of local stack frames.
    private int counter, cnt2, cnt3;   
    private int itext;
    private int clIDcnt;
    private int statusIndex = -1;    
    private long nextGC=currentTime()+60000;    //never modified????????
    private int stringColor=0; // paintBuffer
    private int stringColorMask=0;
    private Random rg;

    // object handling
    private final int maxBots=200;
    private final int maxBushes=800;
    private final int maxDeko=450;
    private final int numObjects=100+maxBots+maxBushes+maxDeko;
    private final int ShapeRocket=0; // must add iobjtext for atext[] index!
    private final int ShapeExplo =1;
    private final int ShapeBot   =2;
    private final int ShapeBush  =3;
    private final int ShapeDeko  =4;

    private d3object object[];
    private d3area   area[];

    private final int IndexPlayerRockets=0;  // plr rockets are on index 0 to 9
    private final int IndexBotRockets=10;    // bot rockets are on index 10 to 19
    private final int IndexBots=20;          // bots are on index 20 to 119 (see maxBots)
    private final int IndexBushes=IndexBots+maxBots; // bushes are on index 120 ff.
    private final int IndexDeko=IndexBushes+maxBushes;
    private boolean playerHit;
    private boolean playerWins;
    private boolean innerLoop;

    private byte botmap[];
    private byte areamap[];

    private boolean bpause;

    // NEW/1.1.0
    private boolean  recSnapFilm = false;
    private boolean  recSnapShot = false;

    // object sorting and drawing
    private final int nmaxsort=numObjects;
    private double aobjdist[];
    private int aobjsort[];
    private int ntabtop;
    private double dsinp, dcosp;

    // texture storage
    private d3texture atext[];
    private int ntext;  // number of array entries
    private int iwallplain, iwallimglo, iwallimghi, iobjtext, ifloortext, iceiltext;

    private int map[];
    private byte movemap[];   // determines where player can move
    private short floorMap[];
    private byte ceilingMap[];

    private short lightMap[];       // static lightmap
    private byte  lightMap2[];      // dynamic lightmap
    private boolean bLightPerPix;   // if false, lowest dynamic light precision
    private boolean bLightHiRes;    // select medium of high dyanmic light resol.
    private int nLightMap2Size;

    // player handling
    private double playerXpos, playerYpos;
    private double playerDirection;
    private boolean runningForwards;
    private boolean runningBackwards;
    private boolean rightStepping;
    private boolean leftStepping;
    private boolean playerMoving;
    private boolean turningLeft;
    private boolean turningRight;
    private boolean runningFast;
    private boolean firstAnnoPlayed;
    private d3area  playerArea;
    private int     iClLastClearedArea;

    // rendering    
    private int zBuffer[];
    private int loadBuffer[];
    private byte loadBuffer2[];

    private d3texture ctext;
    private double multiplierX,multiplierY;
    private int screenWidth, screenHeight;
    private int intersectionX, intersectionY;
    private int screenX;
    private double XHops, YHops, XHopSize, YHopSize;
    private int currentRayXpos, currentRayYpos;
    private double startRayXpos, startRayYpos;
    private int blockHit, blockDistance;
    private int blockLightRecord[];
    private int blockHitRecord[];
    private int blockDistanceRecord[];
    private int textureXRecord[];
    private double xMeasure, yMeasure;
    private double copyOfPlayerDirection;
    private double rayDirection, rotationStep;
    private double distanceAdjuster[];
    private double firstRayXMove, firstRayYMove;
    private double lastRayXMove, lastRayYMove;
    private double furthestWall, aspect, aspect2;

    // renderbufferVline
    private int offset, endOffset, step, source;
    private byte colour;

    // drawfloor
    private int floorDestOffset;
    private int ceilingDestOffset;
    private int floorY, floorX;
    private double runStartX, runEndX;
    private double runStartY, runEndY;
    private double runMiddleX, runDeltaX;
    private double runMiddleY, runDeltaY;
    private int textureXStep, textureYStep;
    private int textureXpos, textureYpos;
    private int pixel, tileOffset, ppix;
    private int oldTileOffset=-1;
    private int pixelOffset;

    private short[] floorTexture;
    private short[] ceilingTexture;

    private int[] fogOffsetTable;

    // object rendering
    private double ax,az, tx,tz;
    private int sx,sy;

    // tools
    private int ipeekcnt=0;        
    
    private byte sourceLightMap[] = null;
    
    //light
    private int ilightpix, ilightoffs;
    private int flashTable[][] = null;
    private int currentLight=256;
    
    private int currentFoglevel; // 1 to 127
    
    private int ishred, ishgrn, ishblu, ishoff;
    private byte afogtable[] = null;
    
    private int[] mapData = null;    
    
    //walking bot support
    private short aBotWalk1[] = { 0,5,6,7,6,5,0,8,9,10,9,8 };
    
    private String sover = null;
    private String soveradd[] = new String[10+5];
    private long   lover = 0; // elapse time
    private int    mover = 0; // color mask
    private int    dover = 0; // blink delay
        
    private int hchar = 24;  
    
    private long lClLastPassBy = 0;
    private int nClBotsWalking = 0;
    
    private boolean aBwShouldPlay[]   = new boolean[3];
    private boolean aBwIsPlaying[]    = new boolean[3];
    private long    aBwPlayingSince[] = new long[3];
    
    private int nAreaLightToStep;  
    
    private d3soundsys sif = null;
    private boolean bJava2Attached = false;
    
    private HashMap<String,Image> imageMap;
    
    // abstract artworks titles
    private static String ainfoabs[] = {
       // reserved
       "Chief Big Bot - 1953 - $5,000,000",
       // generic
       "Breakfast Sushi - 1972 - $350,000",
       "Egg And Sausage - 1966 - $1,200,000",
       "Momo And Susu - 1927 - $1,900,000",
       "Three Armed Tarantulas - 1942 - $930,000",
       "Comments On Wurst - 1959 - $490,000",
       "A Jar Of Nothing - 1961 - $670,000",
       "Maria Di Lala - 1968 - $1,600,000",
       "Rooms Of Rubber - 1904 - $2,450,000",
       "Questionmark Castles - 1939 - $960,000",

       "Inductions Of Njet - 1952 - $780,000",
       "Riddle From Wall - 1956 - $870,000",
       "Bush And Banana - 1955 - $630,000",
       "Visions Of A Squirrel - 1951 - $1,100,000",
       "Sleepless Monkey - 1949 - $930,000",
       "Bowl Of Goo - 1920 - $1,350,000",
       "Wacky Jungles - 1932 - $550,000",
       "Cat Behind Moon - 1976 - $590,000",
       "Paper In The Loo - 1978 - $240,000",
       "Brain Spotting - 1944 - $960,000",

       "Cow Behind Chicken - 1911 - $450,000",
       "Behind The Coal Shed - 1970 - $475,000",
       "Doc Beavers Bum - 1965 - $630,000",
       "The Goo Gardens - 1909 - $990,000",
       "Photo of Uncle Ted - 1969 - $650,000",
       "Sociopolitical Frown - 1905 - $1,250,000",
       "Portrait Of A Mango - 1973 - $570,000",
    };

    // surreal artworks titles
    private static String ainfosur[] = {
       "Lanis At Park",          
       "Lanis At Lake",          
       "Lanis Caribe",           
       "Alaska Green",           
       "Alaska Gold",            
       "Torii",                  
       "Deserted Roads",         
       "Scarabaeus Wood",        
       "Pink Orchids",           
       "Floatbergs",             
       "Mammoth Park",           
       "Sleeping Mammoth",       
       "Neolithic View",         
       "Neolithic Caribbean",    
       "Blue Window",            
       "Hacienda Of Bricks",     
       "Hacienda Sunrise",       
       "Throne At Seascape",     
       "Throne At Sunset",       
       "Blue Room",              
       "Light Hall",             
       "Polar Industrial Estate",
       "Dream Cruiser",          
       "Icebergs",               
       "Orchids On Ice",         
       "Steel Moon",             
       "Sky Cities",             
    };
    
    private static String imageFiles[]={
	"pic256/basetext.jpg",     "pic256/obj0201.jpg",  "pic256/obj0403.jpg",    "pic256/wallabs19.jpg",  "pic256/wallsur17.jpg",
	"pic256/ceiltext00.jpg",   "pic256/obj0202.jpg",  "pic256/obj0404.jpg",    "pic256/wallabs20.jpg",  "pic256/wallsur18.jpg",
	"pic256/ceiltext01.jpg",   "pic256/obj0203.jpg",  "pic256/obj0405.jpg",    "pic256/wallabs21.jpg",  "pic256/wallsur19.jpg",
	"pic256/floortext00.jpg",  "pic256/obj0204.jpg",  "pic256/obj0406.jpg",    "pic256/wallabs22.jpg",  "pic256/wallsur20.jpg",
	"pic256/floortext01.jpg",  "pic256/obj0205.jpg",  "pic256/obj0407.jpg",    "pic256/wallabs23.jpg",  "pic256/wallsur21.jpg",
	"pic256/floortext02.jpg",  "pic256/obj0206.jpg",  "pic256/objbase.jpg",    "pic256/wallabs24.jpg",  "pic256/wallsur22.jpg",
	"pic256/lightmap.jpg",     "pic256/obj0207.jpg",  "pic256/wallabs00.jpg",  "pic256/wallabs25.jpg",  "pic256/wallsur23.jpg",
	"pic256/obj00.jpg",        "pic256/obj0208.jpg",  "pic256/wallabs01.jpg",  "pic256/wallabs26.jpg",  "pic256/wallsur24.jpg",
	"pic256/obj0100.jpg",      "pic256/obj0209.jpg",  "pic256/wallabs02.jpg",  "pic256/wallsur00.jpg",  "pic256/wallsur25.jpg",
	"pic256/obj0101.jpg",      "pic256/obj0210.jpg",  "pic256/wallabs03.jpg",  "pic256/wallsur01.jpg",  "pic256/wallsur26.jpg",
	"pic256/obj0102.jpg",      "pic256/obj0211.jpg",  "pic256/wallabs04.jpg",  "pic256/wallsur02.jpg",  "pic256/walltext00.jpg",
	"pic256/obj0103.jpg",      "pic256/obj0212.jpg",  "pic256/wallabs05.jpg",  "pic256/wallsur03.jpg",  "pic256/walltext01.jpg",
	"pic256/obj0104.jpg",      "pic256/obj0213.jpg",  "pic256/wallabs06.jpg",  "pic256/wallsur04.jpg",  "pic256/walltext02.jpg",
	"pic256/obj0105.jpg",      "pic256/obj0214.jpg",  "pic256/wallabs07.jpg",  "pic256/wallsur05.jpg",  "pic256/walltext03.jpg",
	"pic256/obj0106.jpg",      "pic256/obj0215.jpg",  "pic256/wallabs08.jpg",  "pic256/wallsur06.jpg",  "pic256/walltext04.jpg",
	"pic256/obj0107.jpg",      "pic256/obj0216.jpg",  "pic256/wallabs09.jpg",  "pic256/wallsur07.jpg",  "pic256/walltext05.jpg",
	"pic256/obj0108.jpg",      "pic256/obj0217.jpg",  "pic256/wallabs10.jpg",  "pic256/wallsur08.jpg",  "pic256/walltext06.jpg",
	"pic256/obj0109.jpg",      "pic256/obj0218.jpg",  "pic256/wallabs11.jpg",  "pic256/wallsur09.jpg",  "pic256/walltext07.jpg",
	"pic256/obj0110.jpg",      "pic256/obj0219.jpg",  "pic256/wallabs12.jpg",  "pic256/wallsur10.jpg",  "pic256/walltext08.jpg",
	"pic256/obj0111.jpg",      "pic256/obj0220.jpg",  "pic256/wallabs13.jpg",  "pic256/wallsur11.jpg",  "pic256/walltext09.jpg",
	"pic256/obj0112.jpg",      "pic256/obj0221.jpg",  "pic256/wallabs14.jpg",  "pic256/wallsur12.jpg",  "pic256/worldmap.gif",
	"pic256/obj0113.jpg",      "pic256/obj03.jpg",    "pic256/wallabs15.jpg",  "pic256/wallsur13.jpg",
	"pic256/obj0114.jpg",      "pic256/obj0400.jpg",  "pic256/wallabs16.jpg",  "pic256/wallsur14.jpg",
	"pic256/obj0115.jpg",      "pic256/obj0401.jpg",  "pic256/wallabs17.jpg",  "pic256/wallsur15.jpg",
	"pic256/obj0200.jpg",      "pic256/obj0402.jpg",  "pic256/wallabs18.jpg",  "pic256/wallsur16.jpg"
    };
                

    private d3caster() { 
	super();                	
	setLocation(0,0);//sets the window at the topleft corner
	setUndecorated(true);//makes the decoration disappear
	setIgnoreRepaint(true);//prevents the system from calling repaint automatically
	
	/*these lines are used to load the images which will 
	  be used "as" textures
	*/
	imageMap=new HashMap<String,Image>();		
	MediaTracker tmpTracker=new MediaTracker(this);	
	for(int i=0;i<imageFiles.length;i++)
	    {System.out.println("PRELOAD         loading image "+imageFiles[i]);
	     Image tmpImage=toolkit.getImage(imageFiles[i]);
	     tmpTracker.addImage(tmpImage,0);	     
	     try {tmpTracker.waitForID(0);	          
		  while(tmpTracker.statusID(0,false)!=MediaTracker.COMPLETE)
		      if(tmpTracker.isErrorAny())
		          {System.err.println("error while loading image "+imageFiles[i]);
			   System.exit(0);
			  }
	         } 
	     catch(InterruptedException e)
	     {System.err.println("error while loading image "+imageFiles[i]);
	      System.exit(0);
	     }	     
	     tmpTracker.removeImage(tmpImage,0);	     
	     imageMap.put(imageFiles[i],tmpImage);	     	     	
	    }
	//gets the size of the screen    
	screenWidth=(int)toolkit.getScreenSize().getWidth();
        screenHeight=(int)toolkit.getScreenSize().getHeight();
	/*screenWidth=620;
        screenHeight=300;*/
	setSize(screenWidth,screenHeight);	
	setResizable(false);		
	addWindowListener(new WindowClosingListener());	//allows the closure of the game
	GraphicsDevice gd=this.getGraphicsConfiguration().getDevice();
	/*if(gd.isFullScreenSupported())
	    gd.setFullScreenWindow(this);//set full screen mode (crashs under Microsoft Windows)
	else*/
	    System.out.println("full screen mode not supported");		
	//builds a transparent cursor
	BufferedImage cursor=new BufferedImage(1,1,BufferedImage.TYPE_INT_ARGB);
	cursor.setRGB(0,0,0);
	setCursor(toolkit.createCustomCursor(cursor,new Point(0,0),"empty cursor"));     
	pixelsBuffer=BufferUtil.newIntBuffer(screenWidth*screenHeight);
	/*uncomment the line below and comment the line above if you use an other JOGL version*/
	/*pixelsBuffer=(ByteBuffer.allocateDirect(renderBuffer.length*4)).order(ByteOrder.nativeOrder()).asIntBuffer();*/		
	pixelsBufferSize=pixelsBuffer.capacity();     	
	/*pixelsBuffer=IntBuffer.wrap(renderBuffer);*/	
	GLCapabilities capabilities=new GLCapabilities();
	capabilities.setDoubleBuffered(true);//enables double buffering
	capabilities.setHardwareAccelerated(true);//enables hardware acceleration
	canvas=new GLCanvas(capabilities);
	/*uncomment the line below and comment the line above if you use an other JOGL version*/
	/*canvas=GLDrawableFactory.getFactory().createGLCanvas(capabilities);*/			
	canvas.addKeyListener(new GameKeyboardController(this));	
	canvas.addMouseMotionListener(gameMouseMotionController=new GameMouseMotionController(true,this,10));		
	canvas.addMouseListener(gameMouseMotionController);	
	canvas.setAutoSwapBufferMode(false);//prevents any auto buffer swapping
	/*the line below works only on the stable version of september 2006*/
	/*canvas.setNoAutoRedrawMode(true);*///prevents any auto redraw (display)
	gl=canvas.getGL();
	glu=new GLU();
	/*uncomment the line below and comment the line above if you use an other JOGL version*/
	/*glu=canvas.getGLU();*/	
	canvas.addGLEventListener(gameGLEventController=new GameGLEventController(this));		
	gameGLEventController.display();
	lastShot=currentTime();
	add(canvas);
	setVisible(true);	
	runEngine();         
    }
        	   
        
    int getScreenWidth(){
        return(screenWidth);
    }
    
    int getScreenHeight(){
        return(screenHeight);
    }
       
    boolean getPlayerWins(){
        return(playerWins);
    }
    boolean getInnerLoop(){
        return(innerLoop);
    }
    
    boolean getRecSnapFilm(){
        return(recSnapFilm);
    }
    
    boolean getRecSnapShot(){
        return(recSnapShot);
    }    
        
    boolean getBLightPerPix(){
        return(bLightPerPix);
    }
    boolean getBLightHiRes(){
        return(bLightHiRes);
    }
    
    short getLightMap(int index){
        return(lightMap[index]);
    }
    
    short[] getLightMap(){
        return(lightMap);
    }
    
    byte getLightMap2(int index){
        return(lightMap2[index]);
    }
    
    byte[] getLightMap2(){
        return(lightMap2);
    }
    
    int getNLightMap2Size(){
        return(nLightMap2Size);
    }
        
    boolean getBFog(){
        return(bFog);
    }
    
    boolean getBDistSnd(){
        return(bDistSnd);
    }
            
    GL getGL(){
        return(gl);
    }
    
    IntBuffer getPixelsBuffer(){
        return(pixelsBuffer);
    }
    
    GLCanvas getCanvas(){
        return(canvas);
    }
    
    boolean getPlayerHit(){
        return(playerHit);
    }
    
    boolean getBpause(){
        return(bpause);
    }
    
    void setTurningLeft(boolean turningLeft){
        this.turningLeft=turningLeft;
    }  
      
    void setTurningRight(boolean turningRight){
        this.turningRight=turningRight;
    }
    
    void setRunningForwards(boolean runningForwards){
        this.runningForwards=runningForwards;
    }
    
    void setRunningBackwards(boolean runningBackwards){
        this.runningBackwards=runningBackwards;
    }
    
    void setRunningFast(boolean runningFast){
        this.runningFast=runningFast;
    }
    
    void setRightStepping(boolean rightStepping){
        this.rightStepping=rightStepping;
    }
    
    void setLeftStepping(boolean leftStepping){
        this.leftStepping=leftStepping;
    }
    
    void setBpause(boolean bpause){
        this.bpause=bpause;
    }
    
    void setIClLastClearedArea(int iClLastClearedArea){
        this.iClLastClearedArea=iClLastClearedArea;
    }
           
    void setPlayerHit(boolean playerHit){
        this.playerHit=playerHit;
    }
    
    void setPlayerWins(boolean playerWins){
        this.playerWins=playerWins;
    }
    
    void setInnerLoop(boolean innerLoop){
        this.innerLoop=innerLoop;
    }
    
    void setRecSnapFilm(boolean recSnapFilm){
        this.recSnapFilm=recSnapFilm;
    }
    
    void setRecSnapShot(boolean recSnapShot){
        this.recSnapShot=recSnapShot;
    }
           
    void setLightMap(short[] lightMap){
        this.lightMap=lightMap;
    }
    
    void setLightMap(int index,short lightMap){
        this.lightMap[index]=lightMap;
    }
    
    void setLightMap2(byte[] lightMap2){
        this.lightMap2=lightMap2;
    }
    
    void setLightMap2(int index,byte lightMap2){
        this.lightMap2[index]=lightMap2;
    }
    
    void setBLightPerPix(boolean bLightPerPix){
        this.bLightPerPix=bLightPerPix;
    }
    
    void setBLightHiRes(boolean bLightHiRes){
        this.bLightHiRes=bLightHiRes;
    }
    
    void setNLightMap2Size(int nLightMap2Size){
        this.nLightMap2Size=nLightMap2Size;
    }    
    
    void setBFog(boolean bFog){
        this.bFog=bFog;
    }
    
    void setBDistSnd(boolean bDistSnd){
        this.bDistSnd=bDistSnd;
    }    
    
    void handleMouseMotion(byte shiftx,byte shifty){
        if(shiftx==-1)
	    {turningLeft=true;
	     turningRight=false;
	    }
	else 
	    if(shiftx==1)
	        {turningLeft=false;
		 turningRight=true;
                }
	    else
	        {turningLeft=false;
		 turningRight=false;
		}
	if(shifty==-1)
	    {lookingDown=true;
	     lookingUp=false;
	    }
	else 
	    if(shifty==1)
	        {lookingDown=false;
		 lookingUp=true;
                }
	    else
	        {lookingDown=false;
		 lookingUp=false;
		}
    }           
    
    void updateRenderbuffer(int offset,int value){
        //offset is the position of the pixel in the AWT coordinates system
	//value is the value of the pixel that we wish to store in the render buffer
        //lineIndex and columnIndex are the coordinates in the AWT coordinates system
	int lineIndex=offset/screenWidth;
	int columnIndex=offset-(lineIndex*screenWidth);
	//we convert lineIndex into the OpenGL coordinates system
	lineIndex=screenHeight-lineIndex-1;	
	pixelsBuffer.put(lineIndex*screenWidth+columnIndex,value);		
	/*we could have used the method flipImageVertically of ImageUtil*/	
    }
    
    void performScreenshot(){
        File f=null;
	//try to find an unused abstract pathname
	for(int i=0;i<Integer.MAX_VALUE;i++)
	    if(!(f=new File("snap/snapshot_"+i+".tga")).exists())
	        {try {//then create a file with this pathname
		      f.createNewFile();
		      //save screenshot
		      gameGLEventController.performScreenshot(f);		      		     
		     }
		 catch(IOException ioe)
		 {ioe.printStackTrace();}
		 return;
		}
	//print an error message if there's no unused abstract pathname
	System.out.println("warning! the screenshot had not been successfully made");
    }
    
    Image getPreloadedImage(String sName){	    
	return(imageMap.get(sName));
    }            

    void createLightMap(){
       if (sourceLightMap == null)
       {
          status("[lightmap]");
          int[] tempTextureData=new int[256*256];
	  Image lightMapImage = getPreloadedImage("pic256/lightmap.jpg");
          MediaTracker watch=new MediaTracker(this);
          watch.addImage(lightMapImage,1);
          try { watch.waitForAll(); }
          catch (InterruptedException i) {
             System.out.println("Image loading interrupted");
             System.exit(1);
          }
          if (watch.isErrorAny()==true) {
             System.out.println("Problems loading lightmap");
             System.exit(1);
          }          
          try {(new PixelGrabber(lightMapImage,0,0,256,256,tempTextureData,0,256)).grabPixels(); }
          catch(InterruptedException i){
             System.out.println("Pixel grabber interrupted");
          }
          lightMapImage.flush();
          sourceLightMap = new byte[65536];
          for (int i=0; i<65536; i++)
             sourceLightMap[i] = (byte)(tempTextureData[i]&0xFF);
       }

       for (int doc=0; doc<65536; doc++)
       {
          lightMap[doc] = (short)((sourceLightMap[doc]&0xFF)+64);
          if (lightMap[doc]>255)
             lightMap[doc] = (short)255;
       }

       if (flashTable == null) {
          flashTable = new int[100+1][100+1];
          for (int dz=0; dz<=100; dz++)
          for (int dx=0; dx<=100; dx++)
             flashTable[dz][dx] =
        	(int)Math.sqrt(dx*dx+dz*dz);
       }
    }
    
    int light(int x,int z){
	// this method is PERFORMANCE CRITICAL.
	// therefore all multiplications are down by
	// highly optimized bitshifts.
	if(bLightHiRes)
            return lightHiRes(x,z);
	// input is "world.256" pseudofloat.
	// for z, we have to: convert to world.512 (-1),
	//    normalize downshift (+16), find rowbase.512 (-9)
	//    => resulting in a total right shift of 6
	// for x, we have to convert to world.512 (-1),
	//    normalize downshift (+16), done.
	//    => resulting in a total right shift of 15
	if ((ilightpix=
             ((lightMap [((z>>8)&0xFF00)+((x>>16)&0xFF)]*currentLight)>>8)
            + (lightMap2[((z>>6)&0x3FE00)+((x>>15)&0x1FF)]<<1))<256
            )
           return ilightpix;
	return 255;
    }
    
    int lightHiRes(int x,int z){
       // 1048575 = 1111 11111111 11111111 for hires
       // 0xFFC00 = 1111 11111100 00000000 for hires
       // 0x003FF = 0000 00000011 11111111 for hires
       // input is "world.256" pseudofloat.
       if ((ilightpix=
            ((lightMap [((z>>8)&0xFF00)+((x>>16)&0xFF)]*currentLight)>>8)
           + (lightMap2[((z>>4)&0xFFC00)+((x>>14)&0x3FF)]<<1))<256
           )
          return ilightpix;
       return 255;
    }
    
    void stepLight() {
       for (int i=0; i<nLightMap2Size; i++)
          if (lightMap2[i]>0)
             if ((lightMap2[i] -= 16) < 0)
        	lightMap2[i] = (byte)0;
    }
    
    void lightFlash(int x,int z,int r,int ilevel)
    {
      if (bLightHiRes)
          lightFlashHiRes(x,z,r,ilevel);
      else 
      {
       // input is "world.256" pseudofloat coords.
       x <<= 1; // convert to "world.512"
       z <<= 1; // convert to "world.512"
       // given radius is thought for world.512
       r = Math.max(1,r); // enforce positiveInteger
       if (x < (r<<16))   x = (r<<16);
       if (z < (r<<16))   z = (r<<16);
       if (x > ((256*2-1)-r)<<16) x = ((256*2-1)-r)<<16;
       if (z > ((256*2-1)-r)<<16) z = ((256*2-1)-r)<<16;
       int dx,dz;
       int sdx,sdz,ioff,ipix;
       int sqfact = (int)(126 / Math.sqrt(r*r+r*r));
       for (dx=-r+1; dx<r; dx++)
       for (dz=-r+1; dz<r; dz++)
       {
          sdx = Math.abs(dx) * 100 / r;
          sdz = Math.abs(dz) * 100 / r;
          //  262143 = 0011 11111111 11111111 for lores
          // 0x3FE00 = 0011 11111110 00000000 for lores
          // 0x001FF = 0000 00000001 11111111 for lores
          ioff = (((z+(dz<<16))>>7) & 0x3FE00)+(((x+(dx<<16))>>16) & 0x1FF);
          ipix = lightMap2[ioff];
          ipix += ((141-flashTable[sdz][sdx]) * ilevel / 141);
          if (ipix > 127)
             lightMap2[ioff] = (byte)127;
          else
             lightMap2[ioff] = (byte)ipix;
          // flashTable max entry value is 141 (sqrt of 20000)
       }
      }
    }
    
    void lightFlashAbs(int x,int z,int r,int ilevel)
    {
      if (bLightHiRes)
          lightFlashAbsHiRes(x,z,r,ilevel);
      else 
      {
       // input is "world.256" pseudofloat coords.
       x <<= 1; // convert to "world.512"
       z <<= 1; // convert to "world.512"
       // given radius is thought for world.512
       r = Math.max(1,r); // enforce positiveInteger
       if (x < (r<<16))   x = (r<<16);
       if (z < (r<<16))   z = (r<<16);
       if (x > ((256*2-1)-r)<<16) x = ((256*2-1)-r)<<16;
       if (z > ((256*2-1)-r)<<16) z = ((256*2-1)-r)<<16;
       int dx,dz;
       int sdx,sdz,ioff,ipix,ipix2;
       int sqfact = (int)(126 / Math.sqrt(r*r+r*r));
       for (dx=-r+1; dx<r; dx++)
       for (dz=-r+1; dz<r; dz++)
       {
          sdx = Math.abs(dx) * 100 / r;
          sdz = Math.abs(dz) * 100 / r;
          //  262143 = 0011 11111111 11111111 for lores
          // 0x3FE00 = 0011 11111110 00000000 for lores
          // 0x001FF = 0000 00000001 11111111 for lores
          ioff = (((z+(dz<<16))>>7) & 0x3FE00)+(((x+(dx<<16))>>16) & 0x1FF);
          ipix  = lightMap2[ioff];
          ipix2 = ((141-flashTable[sdz][sdx]) * ilevel / 141);
          if (ipix2 > ipix)
             ipix = ipix2;
          if (ipix > 127)
             lightMap2[ioff] = (byte)127;
          else
             lightMap2[ioff] = (byte)ipix;
          // flashTable max entry value is 141 (sqrt of 20000)
       }
      }
    }

    void lightFlashHiRes(int x,int z,int r,int ilevel)
    {
       // input is "world.256" pseudofloat coords.
       x <<= 2; // convert to "world.1024"
       z <<= 2; // convert to "world.1024"
       r <<= 1; // same applies for the radius
       r = Math.max(1,r); // enforce positiveInteger
       if (x < (r<<16))   x = (r<<16);
       if (z < (r<<16))   z = (r<<16);
       if (x > ((256*4-1)-r)<<16) x = ((256*4-1)-r)<<16;
       if (z > ((256*4-1)-r)<<16) z = ((256*4-1)-r)<<16;
       int dx,dz;
       int sdx,sdz,ioff,ipix;
       int sqfact = (int)(126 / Math.sqrt(r*r+r*r));
       for (dx=-r+1; dx<r; dx++)
       for (dz=-r+1; dz<r; dz++)
       {
          sdx = Math.abs(dx) * 100 / r;
          sdz = Math.abs(dz) * 100 / r;
          //  262143 = 0011 11111111 11111111 for lores
          // 0x1FE00 = 0001 11111110 00000000 for lores
          // 0x001FF = 0000 00000001 11111111 for lores
          // 1048575 = 1111 11111111 11111111 for hires
          // 0xFFC00 = 1111 11111100 00000000 for hires
          // 0x003FF = 0000 00000011 11111111 for hires
          ioff = (((z+(dz<<16))>>6) & 0xFFC00)+(((x+(dx<<16))>>16) & 0x3FF);
          ipix = lightMap2[ioff];
          ipix += ((141-flashTable[sdz][sdx]) * ilevel / 141);
          if (ipix > 127)
             lightMap2[ioff] = (byte)127;
          else
             lightMap2[ioff] = (byte)ipix;
          // flashTable max entry value is 141 (sqrt of 20000)
       }
    }
    
    void lightFlashAbsHiRes(int x,int z,int r,int ilevel)
    {
       // input is "world.256" pseudofloat coords.
       x <<= 2; // convert to "world.1024"
       z <<= 2; // convert to "world.1024"
       r <<= 1; // same applies for the radius
       r = Math.max(1,r); // enforce positiveInteger
       if (x < (r<<16))   x = (r<<16);
       if (z < (r<<16))   z = (r<<16);
       if (x > ((256*4-1)-r)<<16) x = ((256*4-1)-r)<<16;
       if (z > ((256*4-1)-r)<<16) z = ((256*4-1)-r)<<16;
       int dx,dz;
       int sdx,sdz,ioff,ipix,ipix2;
       int sqfact = (int)(126 / Math.sqrt(r*r+r*r));
       for (dx=-r+1; dx<r; dx++)
       for (dz=-r+1; dz<r; dz++)
       {
          sdx = Math.abs(dx) * 100 / r;
          sdz = Math.abs(dz) * 100 / r;
          ioff  = (((z+(dz<<16))>>6) & 0xFFC00)+(((x+(dx<<16))>>16) & 0x3FF);
          ipix  = lightMap2[ioff];
          ipix2 = ((141-flashTable[sdz][sdx]) * ilevel / 141);
          if (ipix2 > ipix)
             ipix = ipix2;
          if (ipix > 127)
             lightMap2[ioff] = (byte)127;
          else
             lightMap2[ioff] = (byte)ipix;
       }
    }
    
    void flashAreaLights(){
       // this is called on every cycle
       d3area d3a;
       for (int k=0;k<256;k++) 
       {
          if (   area[k]!=null
              && area[k].getNlights()>0
              && playerWithinArea(k)
             )
          {
             d3a = area[k];
             // System.out.println("flashing");
             // refresh light emission
             for (int i=0;i<d3a.getNlights();i++) {
        	lightFlashAbs(
                   (d3a.getAlightx()[i]<<16)+32768,
                   (d3a.getAlightz()[i]<<16)+32768,
                   6+1,
                   127
                   );
             }
          }
       }
    }    

    void prepareTextures(){
       atext = new d3texture[500];

       // default textures, loaded immediately.
       // it is important that user sees something, to stay patient.
       atext[0] = new d3texture(1,tres,tres,null,
          "pic"+tres+"/basetext",".jpg",false);
       atext[1] = new d3texture(1,tres,tres,null,
          "pic"+tres+"/objbase",".jpg",true);

       ntext = 2;
       iwallplain = ntext;
       for (int i0=0; i0<numWallPlainText; i0++) {
          atext[ntext] = new d3texture(1,tres,tres,atext[0],
             "pic"+tres+"/walltext"+doubdig(i0),".jpg",false);
          ntext++;
       }
       iwallimglo = ntext;
       for (int i0=0; i0<numLoWallImages; i0++) {
          atext[ntext] = new d3texture(1,tres,tres,atext[0],
             "pic"+tres+"/wallabs"+doubdig(i0),".jpg",false);
          ntext++;
       }
       iwallimghi = ntext;
       for (int i0=0; i0<numHiWallImages; i0++) {
          atext[ntext] = new d3texture(1,tres,tres,atext[0],
             "pic"+tres+"/wallsur"+doubdig(i0),".jpg",false);
          ntext++;
       }

       ifloortext = ntext;
       for (int i=0; i<numFloorTextures; i++) {
          atext[ntext] = new d3texture(1,tres,tres,atext[0],
             "pic"+tres+"/floortext"+doubdig(i),".jpg",false);
          ntext++;
       }

       iceiltext = ntext;
       for (int i=0; i<numCeilTextures; i++) {
          atext[ntext] = new d3texture(1,tres,tres,atext[0],
             "pic"+tres+"/ceiltext"+doubdig(i),".jpg",false);
          ntext++;
       }

       iobjtext = ntext;

       // rocket, 1 face
       atext[ntext] = new d3texture(1,tres,tres,atext[1],
          "pic"+tres+"/obj00",".jpg",true);
       atext[ntext].setUsemask(true);
       ntext++;

       // explosion, 16 faces
       atext[ntext] = new d3texture(16,tres,tres,atext[1],
          "pic"+tres+"/obj01",".jpg",true);
       atext[ntext].setUsemask(true);
       ntext++;

       // walking bot, 22 faces
       atext[ntext] = new d3texture(22,tres,tres,atext[1],
          "pic"+tres+"/obj02",".jpg",true);
       atext[ntext].setUsemask(true);
       atext[ntext].setMaskAmbient(true);
       ntext++;

       // bush object, 1 face
       atext[ntext] = new d3texture(1,tres,tres,null,
          "pic"+tres+"/obj03",".jpg",true);
       atext[ntext].setUsemask(true);
       ntext++;

       // deko object, 8 faces
       atext[ntext] = new d3texture(8,tres,tres,null,
          "pic"+tres+"/obj04",".jpg",true);
       atext[ntext].setUsemask(true);
       ntext++;

       long ltotal = 0;
       for (int i2=0; i2<ntext; i2++)
          ltotal += atext[i2].getBytes();
       System.out.println("allocated "+(ltotal/1024)+" kbytes for textures");
    }

    void convertPixels(
       int width,int height, int[] sourcePixels,short[] destPixels,boolean btrans){
       int srcPix, dstPix, idiff;
       final int iMask = 0xFF;

       int first[] = new int[3];
       first[0] = (sourcePixels[2*height+2]>>16)&iMask;   // red
       first[1] = (sourcePixels[2*height+2]>>8)&iMask;    // green
       first[2] = (sourcePixels[2*height+2])&iMask;       // blue
       int itrans = 1; // green is transmask by default
       if (first[2] > 0xA0 && first[2] > first[itrans])
           itrans = 2; // switch to blue mask
       if (first[0] > 0xA0 && first[0] > first[itrans])
           itrans = 0; // switch to red mask

       // if (btrans)
       // System.out.println("it "+itrans+" "+first[0]+" "+first[1]+" "+first[2]);

       int src[] = new int[4];

       // for (currentPixel=0;currentPixel<(width*height); currentPixel++)
       for (int y1=0; y1<height; y1++)
       for (int x1=0; x1<width; x1++)
       {
          srcPix = y1*width+x1;
          dstPix = x1*width+y1; // turn 90 degrees due to render algos

          src[0] = ((sourcePixels[srcPix]>>16)&iMask);
          src[1] = ((sourcePixels[srcPix]>>8)&iMask);
          src[2] = ((sourcePixels[srcPix])&iMask);
          // src[3] = ((sourcePixels[srcPix]>>24)&iMask); // alpha

          idiff =
                   (src[0]-first[0])*(src[0]-first[0])
                  +(src[1]-first[1])*(src[1]-first[1])
                  +(src[2]-first[2])*(src[2]-first[2])
                  +(src[itrans]-first[itrans])*(src[itrans]-first[itrans])
                  +(src[itrans]-first[itrans])*(src[itrans]-first[itrans])
                  ;
          final int ithresh =
                  (255*255
                  +255*255
                  +255*255
                  +255*255
                  +255*255)*10/100;

          if (btrans && idiff < ithresh)
             destPixels[dstPix] = (short)0xFFFF; // transparent pixel
          else
          {
             // transmask component is always reduced
             //if (btrans)
             //    src[itrans] >>= 1;

             // convert from 24-bit to 15-bit color model:
             // each component reduced from 8 to 5 bits
             src[0] = (src[0] >> 3) & 0x1F;
             src[1] = (src[1] >> 3) & 0x1F;
             src[2] = (src[2] >> 3) & 0x1F;
             destPixels[dstPix] =
        	(short)((src[0]<<10)|(src[1]<<5)|src[2]);
          }
       }
    }


    /*updateRenderbuffer used here*/
    void renderBufferVLine(
       short texture[],int screenX,int height,
       int textureX, boolean transparent, int lightLevel,
       int fogOffset
       )
    {
       textureX=textureX*tres;

       if (height>0)
       {
          step=(tres<<16)/height;

          if (height>screenHeight)
          {
             height=screenHeight;
             source=((tres<<16)/2)-(step*(height/2));
             offset=screenX;
             endOffset=screenX+(height*screenWidth);
          }
          else
          {
             source=0;
             offset=(((screenHeight/2)-(height/2))*screenWidth)+screenX;
             endOffset=offset+(height*screenWidth);
          }

          if (transparent==true)
          {
             while (offset<endOffset)
             {
        	pixel = texture[textureX+(source>>16)];
        	if (pixel != 0xFFFFFFFF)
                   if (bFog)
                   updateRenderbuffer(offset,shadeRGBFog2((short)pixel, lightLevel, fogOffset));
                   else
                   updateRenderbuffer(offset,shadeRGB((short)pixel, lightLevel));
        	offset+=screenWidth;
        	source+=step;
             }
          }
          else
          {
             while (offset<endOffset)
             {
        	if (bFog)
        	updateRenderbuffer(offset,shadeRGBFog2(texture[textureX+(source>>16)], lightLevel, fogOffset));
        	else
        	updateRenderbuffer(offset,shadeRGB(texture[textureX+(source>>16)], lightLevel));
        	offset+=screenWidth;
        	source+=step;
             }
          }
       }
    }

    /*updateRenderbuffer used here*/
    void renderBufferVLineMix(
       short texture[],
       int   panel[],
       int screenX,int height,
       int textureX, boolean transparent, int lightLevel)
    {
       // textureX = textureX * tres;

       if (height>0)
       {
          step=(tres<<16)/height;

          if (height>screenHeight) {
             height=screenHeight;
             source=((tres<<16)/2)-(step*(height/2));
             offset=screenX;
             endOffset=screenX+(height*screenWidth);
          }
          else {
             source=0;
             offset=(((screenHeight/2)-(height/2))*screenWidth)+screenX;
             endOffset=offset+(height*screenWidth);
          }

          if (transparent==true)
          {
             while (offset<endOffset)
             {
        	pixel = texture[textureX+(source>>16)];
        	if (pixel != 0xFFFFFFFF)
                   updateRenderbuffer(offset,shadeRGBMix((short)pixel, lightLevel,
                      panel[textureX+(source>>16)]));
        	offset+=screenWidth;
        	source+=step;
             }
          }
          else
          {
             while (offset<endOffset)
             {
        	updateRenderbuffer(offset,shadeRGBMix(texture[textureX+((source>>16)<<treslx)],
                   lightLevel, panel[textureX+((source>>16)<<treslx)]));
        	offset+=screenWidth;
        	source+=step;
             }
          }
       }
    }

    int shadeRGB(short pix, int light)
    {
       // convert from 15-bit rgb, shade with light,
       // return as 24-bit rgb
       int ired = (((pix >> 10) & 0x1F) << 3) * light / 256;
       int igrn = (((pix >>  5) & 0x1F) << 3) * light / 256;
       int iblu = (((pix      ) & 0x1F) << 3) * light / 256;
       return
           0xFF000000     // required for RGB color model
          |((ired & 0xFF) << 16)
          |((igrn & 0xFF) <<  8)
          |((iblu & 0xFF)      );
    }

    int shadeRGBMix(short pix, int light, int pix2)
    {
       if ((pix2 & 0xFFFFFF) != 0)
          return 0xFF000000 | pix2;
       // convert from 15-bit rgb, shade with light,
       // return as 24-bit rgb
       int ired = (((pix >> 10) & 0x1F) << 3) * light / 256;
       int igrn = (((pix >>  5) & 0x1F) << 3) * light / 256;
       int iblu = (((pix      ) & 0x1F) << 3) * light / 256;
       return
           0xFF000000     // required for RGB color model
          |((ired & 0xFF) << 16)
          |((igrn & 0xFF) <<  8)
          |((iblu & 0xFF)      );
    }

    
    int fogOffset(int light, int ifogdist) {
       // map from world-distance to 0..127 range
       // ifogdist = (ifogdist*25)>>17;
       //          usg 0...20
       ifogdist = (ifogdist>>14)*currentFoglevel/20;
       if (ifogdist>127) ifogdist=127;
       return ((light&0xFF)<<(7+5))+((ifogdist&127)<<5);
    }
    
    int shadeRGBFog2(short pix, int light, int ioffset)
    {
       // input per component:
       //    color source value, 5 bits
       //    light, 8 bits
       //    fog distance, capped to 7 bits
       //  -> 8+7+5 bits = 20 bits, or 1 mbyte
       if (afogtable == null) {
          afogtable = new byte[1<<20];
          int xlight,xfog,xcol;
          for (xlight=0;xlight<256;xlight++)
          for (xfog=0;xfog<128;xfog++)
          for (xcol=0;xcol<32;xcol++)
             afogtable[(xlight<<(7+5))+(xfog<<5)+(xcol)] =
        	(byte)(((xlight-(xcol<<3))*xfog)>>8);
       }

       // ishred = ((((pix >> 10) & 0x1F) << 3) * light) >> 8;
       // ishgrn = ((((pix >>  5) & 0x1F) << 3) * light) >> 8;
       // ishblu = ((((pix      ) & 0x1F) << 3) * light) >> 8;
       // ishred += ((light-ishred)*ifog) >> 8;
       // ishgrn += ((light-ishgrn)*ifog) >> 8;
       // ishblu += ((light-ishblu)*ifog) >> 8;

       if ((pix & (1<<15))!=0) {
          // ambient one, e.g. bot eyes
          ishred = (((pix >> 10) & 0x1F) << 3);
          ishgrn = (((pix >>  5) & 0x1F) << 3);
          ishblu = (((pix      ) & 0x1F) << 3);
       } else {
          ishred = ((((pix >> 10) & 0x1F) << 3) * light) >> 8;
          ishgrn = ((((pix >>  5) & 0x1F) << 3) * light) >> 8;
          ishblu = ((((pix      ) & 0x1F) << 3) * light) >> 8;
          ishred += afogtable[ioffset+(ishred>>3)];
          ishgrn += afogtable[ioffset+(ishgrn>>3)];
          ishblu += afogtable[ioffset+(ishblu>>3)];
       }

       return
           0xFF000000     // required for RGB color model
          |((ishred & 0xFF) << 16)
          |((ishgrn & 0xFF) <<  8)
          |((ishblu & 0xFF)      );
    }

    void drawObject(int screenX, int height, int distance, int light,
       double ddir, int ishape, int itextface)
    {
       int currentScreenX;
       int textureXStep;
       int textureX;
       int endScreenX;
       int currentTextureX=0;
       int aheight    = (int)(height*aspect2);
       int halfheight = (int)aheight/2;

       if (height>0)
       {
          if (ddir < 0.0) ddir += fullCircle;
          if (itextface == -1)
             itextface = (int)(ddir * atext[iobjtext+ishape].getNfaces() / fullCircle);

          textureXStep   = (tres<<16) / aheight;
          currentScreenX = screenX - halfheight;

          if ( ((screenX+halfheight)>=0) && ((screenX-halfheight)<screenWidth) )
          {
             endScreenX = screenX + halfheight;

             if (endScreenX>screenWidth)
        	endScreenX=screenWidth;

             if (currentScreenX<0) {
        	currentTextureX-=(textureXStep*currentScreenX);
        	currentScreenX=0;
             }

             while (currentScreenX<endScreenX)
             {
        	if (zBuffer[currentScreenX]>distance)
                   renderBufferVLine(
                      atext[iobjtext+ishape].face(itextface),
                      currentScreenX,
                      height,currentTextureX>>16,true,light,
                      fogOffset(light,distance));
        	currentScreenX++;
        	currentTextureX+=textureXStep;
             }
          }
       }
    }

    // "botmap" also is a synonyme for area map.
    // every area should have a sector of pixels
    // without holes within this map.
    void setBotMap(int ioff, byte igroup) {
       botmap[ioff] = igroup;
    }

    
    void genMap(){
       int xpos,ypos,width,height,ystart,yend,tileColour,cx,cy;

       for (cy=0; cy<256; cy++)
          for (cx=0; cx<256; cx++)
                 map[(cy<<8)+cx]=-1;
       if(mapData==null)
           {mapData = new int[256*256];	  	  
	    Image mapImage = getPreloadedImage("pic256/worldmap.gif");
            try { (new PixelGrabber(mapImage,0,0,256,256,mapData,0,256)).grabPixels(); }
            catch (InterruptedException i) 
	    {System.out.println("Pixel grabber interrupted");}
            mapImage.flush();
           }
       // analyze world map, build objects from it
       int ipix,ired,igrn,iblu,ioff,icode,irel,narea;
       byte igroup;
       byte ceilstate=0; // initial default: inside
       d3object obj;
       int sx,sy,ioff2,ipix2,ired2,iblu2,igrn2,imgcnt=1;
       boolean bbail;

       for (cy=0; cy<256; cy++)
       for (cx=0; cx<256; cx++)
       {
          ioff = cy*256+cx;
          ipix = mapData[ioff]&0xFFFFFF;
          ired = (ipix>>16)&0xFF;
          igrn = (ipix>> 8)&0xFF;
          iblu = (ipix    )&0xFF;

          ceilingMap[ioff] = ceilstate;

          if (ired==0xFF && igrn==0xFF && iblu==0) {
             ceilstate = (byte)(1-ceilstate); // switch ceiling default
             // replace yellow by blue (wall)
             ired=igrn=0; iblu=0xFF;
             // fall through
          }
          if (iblu==0xFF && ired==0xFF && igrn==0) {
             floorMap[ioff]   = numFloorTextures-1;
             movemap[ioff]    = 3; // exit point
             ceilingMap[ioff] = (byte)1; // is outside
             // create a dummy area object
             igroup = (byte)(0xFE-235);
             if (area[igroup]==null)
        	area[igroup] = new d3area(igroup);
             continue;
          }
          if (ired==100 && igrn==100 && iblu==00) { // inside
             ceilingMap[ioff]=0;
             continue;
          }
          if (ired==0 && igrn==0 && iblu==0) { // outside
             ceilingMap[ioff]=(byte)1;
             continue;
          }

          if (ired<=200 && igrn==0 && iblu<=200 && (ired==iblu))
          {
             // deko object handling
             movemap[ioff] = 2;
             // allocate a new deko object
             for (icode=IndexDeko; icode<IndexDeko+maxDeko; icode++)
        	if (object[icode].getShape()==-1)
                   break;
             if (icode==IndexDeko+maxDeko) {
        	System.out.println("x25341353");
        	continue;
             }
             object[icode].setX((cx<<16)+32768);
             object[icode].setZ((cy<<16)+32768);
             object[icode].setShape(ShapeDeko);
             object[icode].setSpeed((short)0);
             switch (ired) {
        	case 200: object[icode].setFace((short)0); break; // flowers
        	case 100: object[icode].setFace((short)1); break; // table
        	case 150: object[icode].setFace((short)2); break; // vending machine
        	case 151: object[icode].setFace((short)3); break; // group of chairs
        	case 152: object[icode].setFace((short)4); break; // tree
        	case 153: object[icode].setFace((short)5); break; // lamp
        	default:  object[icode].setFace((short)0); break;
             }
             // whatever is standing within an area, must always
             // register it's location also with the "botmap",
             // which tells which position belongs to which area.
             igroup=0;
             if ((narea=withinAnArea(cx,cy))>=0) { // -1 if not
        	setBotMap(ioff,(byte)narea);
        	// light emitting objects: only w/in area for performance reasons
        	if (ired==153) {
                   igroup = (byte)narea;
                   if (area[igroup]==null)
                      area[igroup] = new d3area(igroup);
                   area[igroup].addLight(cx,cy);
        	}
             }
             continue;
          }

          if (ired==0 && igrn==0) 
          {
           if (iblu==0xE0) {  // bush, obstacle
             movemap[ioff] = 2;
             // allocate a new bush
             for (icode=IndexBushes; icode<IndexBushes+maxBushes; icode++)
        	if (object[icode].getShape()==-1)
                   break;
             if (icode==IndexBushes+maxBushes) {
        	System.out.println("x20342010");
        	continue;
             }
             object[icode].setX((cx<<16)+32768);
             object[icode].setZ((cy<<16)+32768);
             object[icode].setShape(ShapeBush);  // alloc
             object[icode].setSpeed((short)0);
             // have to register bush location in "botmap",
             // otherwise there would be a hole in the area.
             igroup=0;
             if ((narea=withinAnArea(cx,cy))>=0)
        	setBotMap(ioff,(byte)narea);
             continue;
           }
           if (iblu==0xFF) {  // simple wall
             // wall blocks adjacing an area are
             // also registered with the area,
             // for better dynamic light support.
             igroup=0;
             if ((narea=withinAnArea(cx,cy))>=0)
        	igroup = (byte)narea;
             map[ioff]      = (1+(igroup%(numWallPlainNetto-1)))*2;
             movemap[ioff]  = 1;
             continue;
           }
           if (iblu==100) // switchable image wall
           {
             // this image can be associated with an area.
             // it is then switched once the area is cleared.
             // to be associated, it is sufficient to be
             // adjacent, or next to an area's pixel.
             igroup=0;
             if ((narea=withinAnArea(cx,cy))>=0) {
        	igroup = (byte)narea;
        	if (area[igroup]==null)
                   area[igroup] = new d3area(igroup);
        	area[igroup].addImage(cx,cy);
             }
             irel = imgcnt;
             if ((++imgcnt)>=numLoWallImages)
        	imgcnt = 1; // picture 0 is reserved
             map[ioff]      = (iwallimglo-iwallplain)+irel;
             movemap[ioff]  = 1;
             continue;
           }
           if (iblu==101) // reserved switchable image wall
           {
             // same as above, only for chief bigbot's pic.
             igroup=0;
             if ((narea=withinAnArea(cx,cy))>=0) {
        	igroup = (byte)narea;
        	if (area[igroup]==null)
                   area[igroup] = new d3area(igroup);
        	area[igroup].addImage(cx,cy);
             }
             irel = 0;
             map[ioff]      = (iwallimglo-iwallplain)+irel;
             movemap[ioff]  = 1;
             continue;
           }
           if (iblu >= 0xA0 && iblu < 0xF0) {  // high image wall
             irel = (iblu-0xA0)%numHiWallImages;
             map[ioff]      = (iwallimghi-iwallplain)+irel;
             movemap[ioff]  = 1;
             continue;
           }
          }
          if (ired==0xFF && igrn==0 && iblu==0) { // player start point
             playerXpos = cx<<16;
             playerYpos = cy<<16;
             igroup=0;
             if ((narea=withinAnArea(cx,cy))>=0) {
        	igroup = (byte)narea;
        	if (area[igroup]==null)
                   area[igroup] = new d3area(igroup);
        	playerArea = area[igroup];
        	setBotMap(ioff,(byte)narea);
             }
             continue;
          }

          // ----- AREA handling -----
          if (ired==0 && iblu==0 && (igrn >=0xA0 && igrn <= 0xFE)) {  // attack area of bot
             igroup = (byte)(0xFE-igrn);
             setBotMap(ioff,igroup);
             if (area[igroup]==null)
        	area[igroup]=new d3area(igroup);
             // set pix around this pix to dark
             if (area[igroup].getLight()!=255)
             for (sx=-1;sx<=1;sx++)
        	for (sy=-1;sy<=1;sy++) {
                   ioff2=(cy+sy)*256+(cx+sx);
                   lightMap[ioff2] = (short)area[igroup].getLight();
        	}
             continue;
          }
          if (igrn==0 && iblu==0 && (ired >=0xA0 && ired <= 0xFE)) { // area announcement/preload
             igroup = (byte)(0xFE-ired);
             areamap[ioff] = igroup;
             continue;
          }
          if (   (ired==0 && igrn==0xFF && iblu==0xFF)
              || (ired==0 && igrn==200  && iblu==200)
             ) 
          {
             // create bot, auto-detect surrounding area
             igroup=0;
             if ((narea=withinAnArea(cx,cy))>=0) 
             {
        	igroup = (byte)narea;
        	if (area[igroup]==null)
                   area[igroup] = new d3area(igroup);
        	// create bot
        	setBotMap(ioff,igroup);
        	// allocate a new bot
        	for (icode=IndexBots; icode<IndexBots+maxBots; icode++)
                   if (object[icode].getShape()==-1)
                      break;
        	if (icode==IndexBots+maxBots) {
                   System.out.println("X20342033"); continue;
        	}
        	obj = object[icode];
        	obj.setX((cx<<16)+32768);
        	obj.setZ((cy<<16)+32768);
        	obj.setShape(ShapeBot);   // alloc
        	obj.setSpeed((short)1);          // pseudo
        	obj.setGroup(igroup);
        	if (igrn==200) {
                   obj.setFlags(1);    // distance bot
                   obj.setSleep(nextRand(10));
        	}
        	else {
                   obj.setFlags(0);    // standard bot
                   obj.setSleep(nextRand(6)+3);
        	}
        	area[igroup].addMember(obj);
        	obj.setMyarea(area[igroup]);
             }
             else // bot MUST be within an area
        	System.out.println("X1634234A");
             continue;
          }
          if (ired==50 && igrn==50 && iblu==50) {  // area light preset
             // dark area, target indicated in next pixel
             ipix2=mapData[ioff+1]&0xFFFFFF;
             igrn2=(ipix2>>8)&0xFF;
             igroup = (byte)(0xFE-igrn2);
             if (area[igroup]==null)
        	area[igroup]=new d3area(igroup);
             area[igroup].setLight(40);
          }
          if (ired==100 && igrn==100 && iblu==100) {  // respawn point
             igroup=0;
             if ((narea=withinAnArea(cx,cy))>=0) 
             {
        	igroup = (byte)narea;
        	if (area[igroup]==null)
                   area[igroup] = new d3area(igroup);
        	setBotMap(ioff,igroup);
        	if (area[igroup].getSpawnx()==-1)
        	{
                   area[igroup].setSpawnPoint(cx,cy);
                   // IF the next pix is same color,
                   ipix2=mapData[ioff+1]&0xFFFFFF;
                   if (ipix2==ipix)
                      // SWITCH spawn direction to downwards
                      area[igroup].setPlayerdir(0.0);
        	}
             }
             else // this MUST be within an area
        	System.out.println("X16342349");
             continue;
          }
          if (ired==150 && igrn==150 && iblu==150) {  // half-dark
             igroup=0;
             if ((narea=withinAnArea(cx,cy))>=0) {
        	igroup = (byte)narea;
        	if (area[igroup]==null)
                   area[igroup] = new d3area(igroup);
        	area[igroup].setLightlevel(150);
        	setBotMap(ioff,igroup);
             }
             else // this MUST be within an area
        	System.out.println("X27341354");
             continue;
          }
          if (ired==255 && igrn==255 && iblu==255) {  // light source
             igroup=0;
             if ((narea=withinAnArea(cx,cy))>=0) {
        	igroup = (byte)narea;
        	if (area[igroup]==null)
                   area[igroup] = new d3area(igroup);
        	area[igroup].addLight(cx,cy);
        	setBotMap(ioff,igroup);
             }
             else // this MUST be within an area
        	System.out.println("X2912433");
             continue;
          }
       }  // endfor scan
    }

    // check the 8 pixels around cx,cy if we're standing
    // within or nearby an area. this is used just in genMap(),
    // which is not performance critical.
    int withinAnArea(int cx,int cy)
    {
       int sx,sy,ipix2,ired2,iblu2,igrn2;
       if (cx>1 && cx<255 && cy>1 && cy<255)
       for (sx=-1;sx<=1;sx++)
       {
          for (sy=-1;sy<=1;sy++)
          {
             ipix2 = mapData[(cy+sy)*256+(cx+sx)];
             ired2 = (ipix2>>16)&0xFF;
             igrn2 = (ipix2>> 8)&0xFF;
             iblu2 = (ipix2    )&0xFF;
             if (   igrn2 >= 0xA0 && igrn2 <= 0xFE
                 && ired2 == 0x00 && iblu2 == 0x00)
        	return 0xFE-igrn2;
          }
       }
       return -1; // not within an area
    }

    /*updateRenderbuffer used here*/
    void drawFloor()
    {
       int light=0;
       int mapOffset;
       int textureOffset;
       int ifogOffset,ix1;

       // calculate starting point from furthestWall
       floorY=(int)((33280*screenHeight)/furthestWall)/2;
       if (floorY < 1)
           floorY = 1;

       if (floorY<screenHeight)
       {
          floorDestOffset  =(screenWidth*(screenHeight/2))+(floorY*screenWidth);
          ceilingDestOffset=(screenWidth*(screenHeight/2-1))-(floorY*screenWidth);

          for (ix1=0;ix1<screenWidth;ix1++) {
             runMiddleX = runStartX + (runEndX-runStartX)*ix1/screenWidth;
             runMiddleY = runStartY + (runEndY-runStartY)*ix1/screenWidth;
             runDeltaX  = Math.abs(playerXpos - runMiddleX);
             runDeltaY  = Math.abs(playerYpos - runMiddleY);
             fogOffsetTable[ix1] = fogOffset(light((int)runMiddleX,(int)runMiddleY),
        	(int)(Math.sqrt((runDeltaX*runDeltaX)+(runDeltaY*runDeltaY))/distanceAdjuster[screenWidth/2]));
          }

          for (; floorY<screenHeight/2; floorY++)
          {
             runStartX=startRayXpos+Math.sin(fullCircle+rayDirection)*multiplierX/floorY;
             runEndX=startRayXpos+Math.sin(rayDirection-(rotationStep*screenWidth))*multiplierX/floorY;
             textureXStep=(int)((runEndX-runStartX)/screenWidth);
             textureXpos=(int)runStartX;

             // multiplier was originally 33280*screenWidth/2*1.4
             runStartY=startRayYpos+Math.cos(fullCircle+rayDirection)*multiplierY/floorY;
             runEndY=startRayYpos+Math.cos(rayDirection-(rotationStep*screenWidth))*multiplierY/floorY;
             textureYStep=(int)((runEndY-runStartY)/screenWidth);
             textureYpos=(int)runStartY;

             {
        	int xidx, yidx;

        	for (floorX=0; floorX<screenWidth; floorX++)
        	{
                 xidx = (textureXpos>>16)&0xFFFF;
                 yidx = (textureYpos>>16)&0xFFFF;

                 ifogOffset = fogOffsetTable[floorX];

                 if (xidx >= 0 && xidx < 256 && yidx >= 0 && yidx < 256)
                 {
                   tileOffset=(((textureYpos&0xFFFF0000)>>8)+(textureXpos>>16));
                   if (tileOffset!=oldTileOffset) {
                      if (!bLightPerPix)
                         light=light(textureXpos,textureYpos);
                      floorTexture=atext[ifloortext+floorMap[tileOffset]].face(0);
                      ceilingTexture=atext[iceiltext+ceilingMap[tileOffset]].face(0);
                   }
                   if (bLightPerPix) // eats a bit of performance
                      light=light(textureXpos,textureYpos);
                   oldTileOffset=tileOffset;

                   pixelOffset =
                           (((textureYpos&65535)>>(16-treslx))<<treslx)
                          +((textureXpos&65535)>>(16-treslx));

                   if (bFog) {
                      // ifogfact = fogFactor(textureXpos,textureYpos);
                      updateRenderbuffer(floorDestOffset,shadeRGBFog2(floorTexture[pixelOffset], light, ifogOffset));
                      updateRenderbuffer(ceilingDestOffset,shadeRGBFog2(ceilingTexture[pixelOffset], light, ifogOffset));
                   }  else {
                      updateRenderbuffer(floorDestOffset,shadeRGB(floorTexture[pixelOffset], light));
                      updateRenderbuffer(ceilingDestOffset,shadeRGB(ceilingTexture[pixelOffset], light));
                   }
                 }
                 else
                 {
                   // use default color of WALLS: first pixel of first texture
                   if (bFog) {
                      // ifogfact = fogFactor(textureXpos,textureYpos);
                      updateRenderbuffer(floorDestOffset,shadeRGBFog2(atext[iwallplain].getAfaces()[0][0], 128, ifogOffset));
                      updateRenderbuffer(ceilingDestOffset,shadeRGBFog2(atext[iwallplain].getAfaces()[0][0], 128, ifogOffset));
                   }  else  {
                      updateRenderbuffer(floorDestOffset,shadeRGB(atext[iwallplain].getAfaces()[0][0], 128));
                      updateRenderbuffer(ceilingDestOffset,shadeRGB(atext[iwallplain].getAfaces()[0][0], 128));
                   }
                 }

                   textureXpos+=textureXStep;
                   textureYpos+=textureYStep;

                   floorDestOffset++;
                   ceilingDestOffset++;
        	}
        	ceilingDestOffset-=screenWidth*2;
             }
          }
       }
    }

    void render()
    {
       furthestWall=0;

       copyOfPlayerDirection=playerDirection;
       rayDirection=copyOfPlayerDirection+(rotationStep*(screenWidth/2));
       startRayXpos=playerXpos;
       startRayYpos=playerYpos;
       screenX=0;

       // now calculate walls
       firstRayXMove=Math.sin(fullCircle+rayDirection);
       firstRayYMove=Math.cos(fullCircle+rayDirection);
       lastRayXMove=Math.sin(rayDirection-(rotationStep*screenWidth));
       lastRayYMove=Math.cos(rayDirection-(rotationStep*screenWidth));

       while (screenX<screenWidth)
       {
          currentRayXpos=(int)startRayXpos;
          currentRayYpos=(int)startRayYpos;

          XHopSize = firstRayXMove+((lastRayXMove-firstRayXMove)*screenX/screenWidth);
          YHopSize = firstRayYMove+((lastRayYMove-firstRayYMove)*screenX/screenWidth);

          blockHit=-1;

          if (XHopSize>0) {
             if (YHopSize>0)
        	downRight();
             else
        	upRight();
          } else {
             if (YHopSize>0)
        	downLeft();
             else
        	upLeft();
          }

          xMeasure=currentRayXpos-startRayXpos;
          yMeasure=currentRayYpos-startRayYpos;
          zBuffer[screenX] = blockDistance =
             (int)(Math.sqrt((xMeasure*xMeasure)+(yMeasure*yMeasure))/distanceAdjuster[screenX]);

          if (blockDistance<=0) // FIX for division by zero
             zBuffer[screenX] = blockDistance = 1;

          if (blockDistance>furthestWall)
             furthestWall=blockDistance;

          blockHitRecord[screenX]=blockHit;
          blockDistanceRecord[screenX]=blockDistance;

          if ((blockHit&1)==0)
             textureXRecord[screenX]=(((int)currentRayXpos&65535)<<tresls)/1024;
          else
             textureXRecord[screenX]=(((int)currentRayYpos&65535)<<tresls)/1024;

          screenX++;
       }

       // calculate and draw the floor
       drawFloor();

       // draw walls
       for (screenX=0; screenX<screenWidth; screenX++)
       {
          ctext = atext[iwallplain+blockHitRecord[screenX]/2];
          renderBufferVLine(ctext.face(0),
             screenX,
             (int)((33280*screenHeight)/blockDistanceRecord[screenX]),
             textureXRecord[screenX],
             false,
             blockLightRecord[screenX],
             fogOffset(blockLightRecord[screenX],blockDistanceRecord[screenX])
             );
       }

       // calculate and draw objects

       // create a first pseudo entry to reduce checks
       aobjdist[0] = 10000*65536;
       aobjsort[0] = -1;
       dsinp = Math.sin(copyOfPlayerDirection);
       dcosp = Math.cos(copyOfPlayerDirection);

       ntabtop = 0;
       for (counter=0; counter<numObjects; counter++)
       {
          if (object[counter].getShape()==-1)
             continue;

          // determine nearest objects, sort them by distance
          tz = (object[counter].getX()-startRayXpos)*dsinp
             + (object[counter].getZ()-startRayYpos)*dcosp;

          if ((tz>0) && (tz<furthestWall))
          for (cnt2=0; cnt2<=ntabtop; cnt2++)
             if (tz < aobjdist[cnt2]) {
        	for (cnt3=ntabtop+1; cnt3>cnt2; cnt3--) {
                   aobjdist[cnt3] = aobjdist[cnt3-1];
                   aobjsort[cnt3] = aobjsort[cnt3-1];
        	}
        	aobjdist[cnt2] = tz;
        	aobjsort[cnt2] = counter;
        	if (ntabtop < nmaxsort)
                    ntabtop++;
        	break;
             }
       }

       int iface=0;
       d3object obj;
       for (cnt2=ntabtop; cnt2>=0; cnt2--)
       {
          if ((counter = aobjsort[cnt2]) < 0) // dummy entry
             continue;
          tz = aobjdist[cnt2];

          if ((tz>0) && (tz<furthestWall))
          {
             obj = object[counter];

             ax = obj.getX()-startRayXpos;
             az = obj.getZ()-startRayYpos;

             tx = ax*dcosp - az*dsinp;
             sx = (int)((screenWidth/2)-(tx*(screenWidth/2))/tz);

             //if (obj.shape==ShapeExplo || obj.shape==ShapeBot)
        	iface = obj.getFace();  // animated shape
             //else
             //   iface = -1; // select face by direction

             drawObject(
        	sx,      // screenx
        	(int)((33280*screenHeight)/tz),  // height
        	(int)tz, // distance
        	light((int)obj.getX(),(int)obj.getZ()),
        	copyOfPlayerDirection-obj.getDir(),
        	obj.getShape(),
        	iface
        	);
          }
       }
    }

    void downRight()
    {
       intersectionX=(((int)(currentRayXpos)&0xFFFF0000)+65536);
       intersectionY=(((int)(currentRayYpos)&0xFFFF0000)+65536);

       while (blockHit==-1)
       {
          XHops=(intersectionX-currentRayXpos)/XHopSize;
          YHops=(intersectionY-currentRayYpos)/YHopSize;
          if (XHops<YHops)
          {
             currentRayXpos=intersectionX;
             currentRayYpos+=(XHops*YHopSize);
             if (map[(((intersectionY>>16)-1)<<8)+(intersectionX>>16)]>-1) {
        	blockHit=map[(((intersectionY>>16)-1)<<8)+(intersectionX>>16)]*2+1;
        	blockLightRecord[screenX]=
                   light(intersectionX,intersectionY);
             }
             else
        	intersectionX+=65536;
          } else
          {
             currentRayYpos=intersectionY;
             currentRayXpos+=(YHops*XHopSize);
             if (map[((intersectionY>>16)<<8)+((intersectionX>>16)-1)]>-1) {
        	blockHit=map[((intersectionY>>16)<<8)+((intersectionX>>16)-1)]*2;
        	blockLightRecord[screenX]=
                   light(intersectionX,intersectionY);
             }
             else
        	intersectionY+=65536;
          }
       }
    }

    void upRight()
    {
       intersectionX=(((int)(currentRayXpos)&0xFFFF0000)+65536);
       intersectionY=(((int)(currentRayYpos)&0xFFFF0000));
       while (blockHit==-1)
       {
          XHops=(intersectionX-currentRayXpos)/XHopSize;
          YHops=(intersectionY-currentRayYpos)/YHopSize;
          if (XHops<YHops)
          {
             currentRayXpos=intersectionX;
             currentRayYpos+=(XHops*YHopSize);
             if (map[((intersectionY>>16)<<8)+(intersectionX>>16)]>-1) {
        	blockHit=map[((intersectionY>>16)<<8)+(intersectionX>>16)]*2+1;
        	blockLightRecord[screenX]=
                   light(intersectionX,intersectionY);
             }
             else
        	intersectionX+=65536;
          } else
          {
             currentRayYpos=intersectionY;
             currentRayXpos+=(YHops*XHopSize);
             if (map[(((intersectionY>>16)-1)<<8)+((intersectionX>>16)-1)]>-1) {
        	blockHit=map[(((intersectionY>>16)-1)<<8)+((intersectionX>>16)-1)]*2;
        	blockLightRecord[screenX]=
                   light(intersectionX,intersectionY);
             }
             else
        	intersectionY-=65536;
          }
       }
    }

    void downLeft()
    {
       intersectionX=(((int)(currentRayXpos)&0xFFFF0000));
       intersectionY=(((int)(currentRayYpos)&0xFFFF0000)+65536);
       while (blockHit==-1)
       {
          XHops=(intersectionX-currentRayXpos)/XHopSize;
          YHops=(intersectionY-currentRayYpos)/YHopSize;
          if (XHops<YHops)
          {
             currentRayXpos=intersectionX;
             currentRayYpos+=(XHops*YHopSize);
             if (map[(((intersectionY>>16)-1)<<8)+((intersectionX>>16)-1)]>-1) {
        	blockHit=map[(((intersectionY>>16)-1)<<8)+((intersectionX>>16)-1)]*2+1;
        	blockLightRecord[screenX]=
                   light(intersectionX,intersectionY);
             }
             else
        	intersectionX-=65536;
          } else {
             currentRayYpos=intersectionY;
             currentRayXpos+=(YHops*XHopSize);
             if (map[((intersectionY>>16)<<8)+(intersectionX>>16)]>-1) {
        	blockHit=map[((intersectionY>>16)<<8)+(intersectionX>>16)]*2;
        	blockLightRecord[screenX]=
                   light(intersectionX,intersectionY);
             }
             else
        	intersectionY+=65536;
          }
       }
    }

    void upLeft()
    {
       intersectionX=(((int)(currentRayXpos)&0xFFFF0000));
       intersectionY=(((int)(currentRayYpos)&0xFFFF0000));
       while (blockHit==-1) 
       {
          XHops=(intersectionX-currentRayXpos)/XHopSize;
          YHops=(intersectionY-currentRayYpos)/YHopSize;
          if (XHops<YHops) {
             currentRayXpos=intersectionX;
             currentRayYpos+=(XHops*YHopSize);
             if (map[((intersectionY>>16)<<8)+((intersectionX>>16)-1)]>-1) {
        	blockHit=map[((intersectionY>>16)<<8)+((intersectionX>>16)-1)]*2+1;
        	blockLightRecord[screenX]=
                   light(intersectionX,intersectionY);
             }
             else
        	intersectionX-=65536;
          } else {
             currentRayYpos=intersectionY;
             currentRayXpos+=(YHops*XHopSize);
             if (map[(((intersectionY>>16)-1)<<8)+(intersectionX>>16)]>-1) {
        	blockHit=map[(((intersectionY>>16)-1)<<8)+(intersectionX>>16)]*2;
        	blockLightRecord[screenX]=
                   light(intersectionX,intersectionY);
             }
             else
        	intersectionY-=65536;
          }
       }
    }
 
    public void update(Graphics g){}
    public void paint(Graphics g){}
        
    void initialize(){
	if (numLoWallImages!=numHiWallImages) System.out.println("X18341622");
	if (numLoWallImages>ainfoabs.length) System.out.println("X18341623");
	if (numHiWallImages>ainfosur.length) System.out.println("X18341624");

	clIDcnt =  1;      
	rg = new Random(345641);

	attachSound();
	openSound();   // mind the fixed maxSoundLength.
	loadSounds();  // ditto
	stepSoundLoading();		
	aspect      = screenHeight*1.0/screenWidth;
	aspect2     = screenWidth*1.0/screenHeight;
	multiplierX = 33280 * screenWidth/2 * 1.4 * aspect;
	multiplierY = 33280 * screenWidth/2 * 1.4 * aspect;

	long ltotal =   4*(screenWidth*screenHeight)
                       +4*(screenWidth*screenHeight);
	System.out.println("allocating "+(ltotal/1024)+" kbytes for fbuf");


	loadBuffer  = new int[256*256];     // 512k in integers
	loadBuffer2 = new byte[256*256*4];  // 512k in bytes

	System.out.println("allocating maps");
	bLightPerPix= false; // max. performance by default
	bLightHiRes = true;  // just for next statement
	nLightMap2Size = bLightHiRes ? 65536*16 : 65536*4;
	bLightHiRes = false; // OFF by default.
	map         = new   int[65536];
	movemap     = new  byte[65536];
	lightMap    = new short[65536];
	lightMap2   = new  byte[nLightMap2Size];
	floorMap    = new short[65536];
	ceilingMap  = new  byte[65536];
	botmap      = new  byte[65536];
	areamap     = new  byte[65536];
	for (int i=0; i<65536; i++) {
           botmap[i]=(byte)0xFF;
	}
	for (int i=0; i<nLightMap2Size; i++)
           lightMap2[i] = (byte)127;
	fogOffsetTable = new int[screenWidth];

	System.out.println("allocating rest");
	blockLightRecord=new int[screenWidth];
	blockHitRecord=new int[screenWidth];
	blockDistanceRecord=new int[screenWidth];
	textureXRecord=new int[screenWidth];

	System.out.println("preparing textures");
	prepareTextures();
	prepareImageMasks(loadBuffer2);  // relies on prepareTextures()
	System.out.println("textures prepared");

	int ipix = shadeRGB(atext[iwallplain].getAfaces()[0][0], 128);
	/*for (int i=0; i<screenWidth*screenHeight; i++)
           renderBuffer2[i] = ipix;*/

	object = new d3object[numObjects];
	for (counter=0; counter<numObjects; counter++)
           object[counter] = new d3object();

	rotationStep = fullCircle/(screenWidth*4);
	distanceAdjuster=new double[screenWidth];

	// prepare a geo adjustment table for faster rendering
	double firstRayXMove = Math.sin(fullCircle/8*3);
	double lastRayXMove  = Math.sin(fullCircle/8*5);
	double firstRayYMove = Math.cos(fullCircle/8*3);
	double lastRayYMove  = Math.cos(fullCircle/8*5);
	for (counter=0; counter<screenWidth; counter++) {
           XHopSize=firstRayXMove+((lastRayXMove-firstRayXMove)*counter/screenWidth);
           YHopSize=firstRayYMove+((lastRayYMove-firstRayYMove)*counter/screenWidth);
           distanceAdjuster[counter]=Math.sqrt((XHopSize*XHopSize)+(YHopSize*YHopSize))*1.4;
	}

	zBuffer  = new int[screenWidth];
	aobjdist = new double[nmaxsort+2];
	aobjsort = new int[nmaxsort+2];

	iClLastClearedArea = -1;

	/*The following line allows the canvas to get the focus from the frame immediately.
	  Without this, the user should have to click at first to be able to use the keyboard.
	  WARNING!!!     If you do it too early, the JVM crashes.
	*/
	gameMouseMotionController.giveFocus();		  	
    }

    void reinit()
    {
       playerHit         = false;
       playerWins        = false;
       bpause            = false;
       nextGC            = currentTime()+60000;
       nAreaLightToStep  = 0;
       playerArea        = null;
       currentFoglevel   = 1;
       currentLight      = 256;
       firstAnnoPlayed   = false;
       soveradd[0]       = null;

       createLightMap(); // loads image only on first call

       // locate player at default x=128.5, y=240.5.
       // however, this is overridden in genMap().
       playerXpos        = (128*65536)+32768;
       playerYpos        = (240*65536)+32768;
       playerDirection   = fullCircle/4*2;

       // by default, all object slots are passive.
       for (counter=0; counter<numObjects; counter++) {
          object[counter].setZ(0);
          object[counter].setX(0);
          object[counter].setDir(0);
          object[counter].setSpeed((short)0);
          object[counter].setShape(-1);
          object[counter].setGroup((byte)0xFF);
          object[counter].setMyarea(null);
          object[counter].setFlags(0);
          object[counter].setSleep(0);
          object[counter].setSleep2(0);
          object[counter].setSeenPlayer(false);
          object[counter].setFace((short)0);
          object[counter].setFaceskip((short)0);
          object[counter].setIanim(0);
          object[counter].setIdamage(0);
       }

       // init the floor texture with large random patches,
       // to make it look a bit more interesting.
       byte c;
       int i,d,x,y,x2,y2,xc,yc;
       for (d=0; d<5000; d++) {
          c=(byte)(Math.random()*(numFloorTextures-1));
          x=(int)(Math.random()*230);
          y=(int)(Math.random()*230);
          x2=x+(int)(Math.random()*12);
          y2=y+(int)(Math.random()*12);
          for (yc=y; yc<y2; yc++)
             for (xc=x; xc<x2; xc++)
        	floorMap[(yc*256)+xc]=c;
       }

       // this is probably superfluous,
       // as the ceiling texture is set by genMap()
       for (d=0; d<5000; d++) {
          c=(byte)(Math.random()*numCeilTextures);
          x=(int)(Math.random()*230);
          y=(int)(Math.random()*230);
          x2=x+(int)(Math.random()*12);
          y2=y+(int)(Math.random()*12);
          for (yc=y; yc<y2; yc++)
             for (xc=x; xc<x2; xc++)
        	ceilingMap[(yc*256)+xc]=0; // default: inside
       }

       area = new d3area[256];
       for (i=0; i<256; i++)
          area[i] = null;
       for (i=0; i<65536; i++)
          areamap[i] = (byte)0xFF;

       genMap(); // may change playerXpos etc.

       lookingDown=false;
       lookingUp=false;
       rightStepping=false;
       leftStepping=false;
       turningLeft=false;
       turningRight=false;
       runningForwards=false;
       runningBackwards=false;
       playerMoving=false;
       runningFast=false;

       stopMovingSound(0xFFFF); // in case it's still playing
       initBotwalkSound();

       restartMusic();    // i.e. initial background track

       if (iClLastClearedArea != -1) {
          // may player respawn in a higher area?
          d3area d3a = area[iClLastClearedArea];
          if (d3a != null && d3a.getSpawnx() != -1)
             respawnWithin(d3a);
       }
    }

    static long currentTime() {
       return System.currentTimeMillis();
    }

    void turnLeft(){       
        byte turnspeed;
        if(runningFast) 
	    turnspeed=1;
	else
	    turnspeed=2;
	playerDirection+=fullCircle/(48*turnspeed);
        if(playerDirection>=fullCircle)
            playerDirection-=fullCircle;	     
    }

    void lookDown(){}
    
    void lookUp(){}

    void runEngine(){
       initialize();  // load stuff, raw setup               
       // statistical stuff
       long  lnow;
       long  lStartPhase;             
       runImageLoader(); // if not running in an own thread       
       lStartPhase=currentTime()+5000;
       lnow=currentTime();
       while(true)
           {reinit();      // re-set all positions
            innerLoop = true;           
            getGraphics().setColor(Color.white);            
            while(innerLoop)
        	{try{Thread.sleep(1);}// give cpu time to OS, for keyboard handling
        	 catch(InterruptedException ie){} 
        	 status((rt.totalMemory()-rt.freeMemory())/1048576+"m used, "
		       +rt.freeMemory()/1048576+"m free, "
		       +Math.round(1000.0/(currentTime()-lnow))+" fps");
		 lnow = currentTime();       	       	
        	 // fallthrough: lnow also checked below!
		 
        	 render();  
		               
        	 if(playerWins)
		     {stringColor++;
        	      stringColorMask=0xFFFFFF;
        	      paintBufferString("C O N G R A T U L A T I O N S",20+hchar*1,false);
        	      paintBufferString("DEMO COMPLETED - COOL ART ESTABLISHED!",20+hchar*2,false);
        	      paintBufferString("PRESS X TO RESTART.",20+hchar*3,false);
        	     }
        	 else
        	     if(playerHit) 
			 {stringColor++;
        		  stringColorMask=0xFF1F1F;
        		  paintBufferString("G A M E   O V E R !",screenHeight/2-hchar,true);
        		  paintBufferString("PRESS X TO RESTART",screenHeight/2+hchar,true);
        		 }
        	     else
        		 if(lStartPhase>lnow)
			     {stringColor++;
        		      stringColorMask=0xFFFFFF;
        		      paintBufferString("T U E R",screenHeight/2-hchar*4,false);
        		      paintBufferString("powered by d3caster 1.1.0 (optimized version)",screenHeight/2+hchar*2,false);
			      paintBufferString("created by Vincent Stahl",screenHeight/2+hchar*6,false);
			      paintBufferString("optimized by Julien Gouesse",screenHeight/2+hchar*8,false);
        		      paintBufferString(soundInfo(),screenHeight/2+hchar*4,false);
        		     }
        		 else
        		 if(sover!=null) 
			     {// paint overhead status message
        		      if(((++dover)&1)!=0)
        			  stringColor++;
        		      stringColorMask=mover;
        		      if(soveradd[0]==null)
        			  paintBufferString(sover,screenHeight-hchar*6/4,false);
        		      else 
			          {// support for multi-line overhead msges, not yet used
        			   int hchar2 = hchar+2;
        			   int nadd = 0;
        			   for (int i=0; i<10; i++)
                		      if (soveradd[i]!=null)
                			 nadd++;
                		      else
                			 break;
        			   if (nadd > 0) nadd--;
        			   int ybase = screenHeight - hchar*6/4 - nadd*hchar2;
        			   for (int i=0; i<10; i++)
                		      if (soveradd[i]!=null)
                			 paintBufferString(soveradd[i],
                        		    ybase+hchar2*i,
                        		    false);
                		      else
                			 break;
        		          }
        		      if (lover < currentTime()) {
        			 sover=null;
        			 soveradd[0]=null;
        		      }
        		     } 		        	      			 
                 gameGLEventController.display();		 
        	 if(recSnapFilm)
                     performScreenshot();
        	 if(recSnapShot) 
		     {recSnapShot=false;
		      performScreenshot();
        	     }               
        	 if (bpause) {
        	    status("paused");
		    tryToForceGarbageCollection(true);
        	    continue;
        	 }

        	 // task that should run as fast as possible       	 
        	 checkForImageTitles();        	 

        	 // tasks with a discrete timing
        	 stepLight();
        	 stepObjects();
        	 stepAreaLight();
        	 stepAreaFog();
        	 flashAreaLights();
        	 stepBotwalkSound();
                 
        	 if (playerHit)
        	    continue;

        	 // step player
        	 boolean bmoved = false;

        	 byte turnspeed=2;
        	 if (runningFast) turnspeed=1;
       	         if(turningLeft)
		     {turnLeft();
		      turningLeft=false;
		     }		     

        	 if(turningRight)
		     {playerDirection -= fullCircle/(48*turnspeed);
        	      if (playerDirection<0.0)
        		 playerDirection+=fullCircle;
		      turningRight=false;
        	     }

                 if(lookingDown)
		     {lookDown();
		      lookingDown=false;
		     }
		 if(lookingUp)
		     {lookUp();
		      lookingUp=false;
		     }

        	 double playerXnew = playerXpos;
        	 double playerYnew = playerYpos;
        	 int ispeed=1;
        	 if (runningFast) ispeed=3;

        	 if (rightStepping) {
        	    playerXnew+=Math.sin(playerDirection-(fullCircle/4))*10000*ispeed;
        	    playerYnew+=Math.cos(playerDirection-(fullCircle/4))*10000*ispeed;
        	 }

        	 if (leftStepping) {
        	    playerXnew+=Math.sin(playerDirection+(fullCircle/4))*10000*ispeed;
        	    playerYnew+=Math.cos(playerDirection+(fullCircle/4))*10000*ispeed;
        	 }

        	 if (runningForwards) {
        	    playerXnew+=Math.sin(playerDirection)*10000*ispeed;
        	    playerYnew+=Math.cos(playerDirection)*10000*ispeed;
        	 }

        	 if (runningBackwards) {
        	    playerXnew-=Math.sin(playerDirection)*10000*ispeed;
        	    playerYnew-=Math.cos(playerDirection)*10000*ispeed;
        	 }

        	 if (playerXnew != playerXpos || playerYnew != playerYpos)
        	 {
        	    // wall or bush in the way?
        	    int xidx0 = ((((int)playerXpos)>>16)&0xFF);
        	    int yidx0 = ((((int)playerYpos)>>16)&0xFF);
        	    int xidx1 = ((((int)playerXnew)>>16)&0xFF);
        	    int yidx1 = ((((int)playerYnew)>>16)&0xFF);
        	    byte b = movemap[(yidx1<<8)+xidx1];
        	    if (b==3) {
        	       b = 0;
        	       if (!playerWins) 
                	  playerWins = true;
        	    }
        	    if (b==0) {
        	       playerXpos = playerXnew;
        	       playerYpos = playerYnew;
        	       bmoved = true;
        	    } else
        	    if (movemap[(yidx0<<8)+xidx1]==0) {
        	       playerXpos = playerXnew;
        	       bmoved = true;
        	    } else
        	    if (movemap[(yidx1<<8)+xidx0]==0) {
        	       playerYpos = playerYnew;
        	       bmoved = true;
        	    }
        	    // reached proximity of a new area?
        	    xidx0 = ((((int)playerXpos)>>16)&0xFF);
        	    yidx0 = ((((int)playerYpos)>>16)&0xFF);
        	    // just for announcements:
        	    if (((b = areamap[(yidx0<<8)+xidx0])&0xFF) !=0xFF) {
        	       d3area d3a = area[b];
        	       if (d3a != null && !d3a.getAnnounced()) {
                	  d3a.setAnnounced(true);
                	  overMessage("approaching: "+d3a.name(), 4000, false);
                	  startCarpetSound();                	  
        	       }
        	    }
        	    // permanent check: this might also be null
        	    playerArea = area[botmap[(yidx0<<8)+xidx0]&0xFF];
        	 }
                 
        	 // started player to move?
        	 if (!playerMoving && bmoved) {
        	    playerMoving = true;
        	    startMovingSound(1<<1);
        	 }
        	 else
        	 if (!bmoved && playerMoving) {
        	    // player stopped moving:
        	    playerMoving = false;
        	    stopMovingSound(1<<1);
        	 }
        	 // run a garbage collection?
        	 if (nextGC > -1 && nextGC < currentTime()) {
        	    status("gc");        	    
		    tryToForceGarbageCollection(false);		    
        	    nextGC=currentTime()+60000;
        	 }
               
	      }  // innerloop
          stopCarpetSound();
      }  // outerloop      
    }
    
    void tryToForceGarbageCollection(boolean forceEvenThoughNoGCCallNeeded){	
	if(forceEvenThoughNoGCCallNeeded==true || rt.freeMemory()<10485760)
	    {long freedMemory=0;
	     do{freedMemory=rt.freeMemory();
        	rt.runFinalization();
		rt.gc();
		freedMemory=rt.freeMemory()-freedMemory;
               }
	     while(freedMemory>0);
	    }
    }        
 
    protected void finalize(){
        cleanup();
    }
 
    void performAtExit(){
        System.exit(0);
    }
 
    void cleanup(){
        closeSound();
    }

    // ============= walking bot support =====================    

    void stepBotFace(d3object obj)
    {
       // animation delay
       if (obj.getFaceskip() > 0) {
          obj.setFaceskip((short)(obj.getFaceskip()-1));
          return;
       }
       // default case: bot standing still
       if (obj.getSpeed() < 2) {
          obj.setFaceskip((short)3);
          obj.setIanim(obj.getIanim()+1);
          if (obj.getIdamage() == 0)
             obj.setFace((short)(obj.getIanim() % 5));
          else
             obj.setFace((short)(11+(obj.getIanim() % 5)));
       }
    }

    void tryStepBot(d3object obj,double dxp,double dzp)
    {
       double  xnew = obj.getX();
       double  znew = obj.getZ();
       boolean bStepLeft  = false;
       boolean bStepRight = false;
       boolean bmoved = false;
       int     ispeed = 1;

       if (obj.getSleep2() > 0)
          obj.setSleep2(obj.getSleep2()-1);  // suspend walking (after rocket launch)
       else
       {
	if (bStepLeft) {
          xnew+=Math.sin(obj.getDir()-(fullCircle/4))*10000*obj.getSpeed();
          znew+=Math.cos(obj.getDir()-(fullCircle/4))*10000*obj.getSpeed();
	}
	if (bStepRight) {
          xnew+=Math.sin(obj.getDir()+(fullCircle/4))*10000*obj.getSpeed();
          znew+=Math.cos(obj.getDir()+(fullCircle/4))*10000*obj.getSpeed();
	}
	if (obj.getSpeed() >= 1) {
          // no matter if speed 1 or more, we always probe
          if (obj.getSpeed() >= 2)
             ispeed = obj.getSpeed()-1;
          xnew+=Math.sin(obj.getDir())*10000*ispeed/10;
          znew+=Math.cos(obj.getDir())*10000*ispeed/10;
	}
       }

       if (xnew != obj.getX() || znew != obj.getZ())
       {
          // how far can the bot walk, if at all?
          int xidx0 = ((((int)obj.getX())>>16)&0xFF);
          int yidx0 = ((((int)obj.getZ())>>16)&0xFF);
          int xidx1 = ((((int)xnew)>>16)&0xFF);
          int yidx1 = ((((int)znew)>>16)&0xFF);

          // about to leave area?
          boolean bstop = false;
          double dx, dz;
          d3object d3o;
          byte b;
          if (((b = botmap[(yidx1<<8)+xidx1])&0xFF) == 0xFF)
             bstop = true;
          else {
             d3area d3a = area[b];
             if (d3a == null)
        	bstop = true;
             else
             if (d3a != obj.getMyarea())
        	bstop = true;
             else 
             {
        	// research minimum distance to all other bots
        	// of the same area. make sure bots always
        	// keep some distance between them.
        	for (int n=0;n<d3a.getNmembers();n++) {
                   d3o = d3a.getAmember()[n];
                   if (d3o != null && d3o.getShape()==2 && d3o != obj) {
                      dx = d3o.getX()-xnew;
                      dz = d3o.getZ()-znew;
                      if ((Math.abs(dx) < (2<<16)) && (Math.abs(dz) < (2<<16))) {
                         bstop = true;
                         break;
                      }  // endif
                   }
        	}  // endfor area members
             }
          }  // endelse botmap

          // keep minimum distance also to player
          if (!bstop
        	&& (Math.abs(dxp) < (1<<16))
        	&& (Math.abs(dzp) < (1<<16))  )
             bstop = true;

          // check for obstacles and move
          if (!bstop) {
             b = movemap[(yidx1<<8)+xidx1];
             if (b==0) {
        	obj.setX(xnew);
        	obj.setZ(znew);
        	bmoved = true;
             }
          }

       }  // endif position changed

       if (bmoved) {
          if (obj.getSpeed() < 2) {
             // this determines the bot speeds. the number
             // gets divided by 10. so 10==1.0, 5==0.5 etc.
             obj.setSpeed((short)8);
             obj.setIanim(0);
          }
          obj.setFaceskip((short)0);
          obj.setIanim(obj.getIanim()+1);
          if (obj.getIdamage()==0)
             obj.setFace(aBotWalk1[obj.getIanim() % aBotWalk1.length]);
          else
             obj.setFace((short)(11+aBotWalk1[obj.getIanim() % aBotWalk1.length]));
          // count walking bots, for stepObjects()
          nClBotsWalking++;
       }  else {
          if (obj.getSpeed() >= 2) {
             obj.setSpeed((short)1);
             obj.setIanim(0);
             obj.setFaceskip((short)0);
          }
       }  // endif bmoved
    }

    // =========================================

    // if player is standing in front of an image, show its title.
    void checkForImageTitles() 
    {
       double dmod = Math.abs(playerDirection % (fullCircle/4));
       if (dmod < fullCircle/16 || dmod > (fullCircle/4-fullCircle/16)) 
       {
          double sx = Math.sin(playerDirection);
          double sy = Math.cos(playerDirection);
          int x1 = ((int)(playerXpos + sx*65536.0)>>16)&0xFF;
          int z1 = ((int)(playerYpos + sy*65536.0)>>16)&0xFF;
          int ipix = map[(z1<<8)+x1];
          if (ipix<(iwallimglo-iwallplain))
             return;
          overMessage(imageInfo(ipix), 100, false);
          mover = 0xFF0000;
       }
    }    

    String imageInfo(int ipix) 
    {
       ipix += iwallplain;
       if (ipix >= iwallimglo && ipix <iwallimghi)
          return ainfoabs[(ipix-iwallimglo)%ainfoabs.length];
       if (ipix >= iwallimghi && ipix <iwallimghi+numHiWallImages)
          return ainfosur[(ipix-iwallimghi)%ainfosur.length];
       return "?"; // shouldn't happen
    }

    // area fog levels can change dynamically
    void stepAreaFog()
    {
       int ifogtarg   =  30;
       int ilighttarg = 256;
       if (playerArea != null) {
          ifogtarg = playerArea.getFoglevel();
          ilighttarg = playerArea.getLightlevel();
       }

       if (currentFoglevel != ifogtarg) {
          if (currentFoglevel < ifogtarg) currentFoglevel++;
          else                            currentFoglevel--;
       }
       if (currentFoglevel != ifogtarg) {
          if (currentFoglevel < ifogtarg) currentFoglevel++;
          else                            currentFoglevel--;
       }

       if (currentLight != ilighttarg) {
          if (currentLight < ilighttarg)  currentLight++;
          else                            currentLight--;
       }
       if (currentLight != ilighttarg) {
          if (currentLight < ilighttarg)  currentLight++;
          else                            currentLight--;
       }
    }
    
    void runImageLoader(){
        Image image;
	String sdig;
	PixelGrabber g;	
	d3texture d3t;           		                     
	for(itext=0;itext<ntext;itext++)
	    {d3t = atext[itext];	                  
             for(int i=0; i<d3t.getNfaces(); i++)
        	 {sdig = doubdig(i);
        	  if(d3t.getNfaces()==1) 
		      sdig="";		  
                  image=getPreloadedImage(d3t.getFilebase()+sdig+d3t.getFiletype());
                  g=new PixelGrabber(image,0,0,d3t.getWidth(),d3t.getHeight(),loadBuffer,0,d3t.getWidth());
                  try {g.grabPixels();} 
		  catch (InterruptedException ie) 
		  {System.out.println("Pixel grabber interrupted");}
		  if(d3t.getUsemask())
                      {// grab also mask image, handle both
                       if((g.getStatus() & ImageObserver.ALLBITS)!=0)
                	   {loadMaskToBuffer(d3t,i,loadBuffer2);
			    convertPixelsMasked(d3t,loadBuffer,d3t.getAfaces()[i],loadBuffer2);
                            image.flush();
                	   }				
                      }
                  else
                      if((g.getStatus() & ImageObserver.ALLBITS)!=0)
                	  {// do not use a mask image
                	   convertPixels(d3t.getWidth(),d3t.getHeight(),loadBuffer,
                              d3t.getAfaces()[i],d3t.getTransparent());
                	   image.flush();
                	  } 

        	 }		           
            }	
    }
    
    void overMessage(String s, int duration, boolean bred) { 
       soveradd[0] = null;
       sover = s;
       lover = currentTime()+duration;
       if (bred) mover = 0xFF0F0F;
       else      mover = 0xFFFFFF;
    }

    // tools
    String hex(int n)
    {
       final String ahex[] = { "0","1","2","3","4","5","6","7","8","9","A","B","C","D","E","F" };
       String s="";
       for (int i=32-4; i>=0; i-=4)
          s += ahex[(n>>i)&0xF];
       return s;
    }

    String hex2(int n)
    {
       final String ahex[] = { "0","1","2","3","4","5","6","7","8","9","A","B","C","D","E","F" };
       String s="";
       for (int i=8-4; i>=0; i-=4)
          s += ahex[(n>>i)&0xF];
       return s;
    }   

    String doubdig(int i) {
       if (i<10) return "0"+i;
       return ""+i;
    }

    void status(String s) {       
       System.out.println("status : "+s);           
    }

    void paintBufferString(String s, int ydst, boolean large){        
        gameGLEventController.pushMessage(s,ydst,large);
    }

    void convertPixelsMasked(
       d3texture d3t,int[] sourcePixels,short[] destPixels,byte[] amask)
    {
       final int iMask = 0xFF;
       int width  = d3t.getWidth();
       int height = d3t.getHeight();
       int srcPix,dstPix;
       int src[] = new int[4];
       int nmasked=0,npassed=0;
       int ntopbit=0;
       int iMask2 = 0x1F;

       for (int y1=0; y1<height; y1++)
       for (int x1=0; x1<width; x1++)
       {
          srcPix = y1*width+x1;
          dstPix = x1*width+y1; // turn 90 degrees due to render algos

          if ((amask[srcPix]&0xFF)!=0) {
             destPixels[dstPix] = (short)0xFFFF; // transparent pixel
             nmasked++;
          }
          else
          {
             src[0] = ((sourcePixels[srcPix]>>16)&iMask);
             src[1] = ((sourcePixels[srcPix]>>8)&iMask);
             src[2] = ((sourcePixels[srcPix])&iMask);

             if (d3t.getMaskAmbient() && src[1] > src[0] && src[1] > src[2])
             {
        	// this is for the gleaming eyes of the robots.
        	// all shades of green are turned into grey.
        	src[0]  = src[1];
        	src[2]  = src[1];
        	ntopbit = (1<<15);
        	iMask2  = 0x1E; // avoid 0xFFFF, which is transparent
             }
             else
        	ntopbit = 0;

             // convert from 24-bit to 15-bit color model:
             // each component reduced from 8 to 5 bits
             src[0] = (src[0] >> 3) & iMask2;
             src[1] = (src[1] >> 3) & iMask2;
             src[2] = (src[2] >> 3) & iMask2;
             destPixels[dstPix] =
        	(short)(ntopbit|(src[0]<<10)|(src[1]<<5)|src[2]);
             npassed++;
          }
       }
    }

    
    void stepObjects()
    {
       double objectXnew;
       double objectZnew;
       int ispeed;
       boolean bhit;
       int iobj;
       int xidx1,yidx1;
       double xdiff,ydiff;
       final double hitrange  = 0.30 * 65536.0;
       final double rockrange = 0.10 * 65536.0;
       int ishape,ipix;
       int xplr,yplr;
       d3object obj;

       int nOldBotsWalking = nClBotsWalking;
       nClBotsWalking = 0;

       // cycle through all object slots
       for (counter=0; counter<numObjects; counter++)
       {
          // check where are active objects
          if ((ispeed=object[counter].getSpeed())==0)
             continue;

          obj = object[counter];

          if ((ishape=obj.getShape())==ShapeExplo) {
             // cycle explosion animation
             if (obj.getFace()>=15) {
        	// remove explosion object after 16th frame
        	obj.setFace((short)0);
        	obj.setSpeed((short)0);
        	obj.setShape(-1);
             }
             else
        	obj.setFace((short)(obj.getFace()+1));
             continue;
          }

          if (ishape==2) // bot
          {
             stepBotFace(obj);
             // check if player is within firing range
             xplr = (((int)playerXpos)>>16)&0xFF;
             yplr = (((int)playerYpos)>>16)&0xFF;
             if (botmap[(yplr<<8)+xplr]==obj.getGroup()) 
             {
        	double dx = playerXpos-obj.getX(); // x-distance to player
        	double dz = playerYpos-obj.getZ(); // y-distance to player
        	boolean bfire = true;
        	if (   (obj.getFlags() & 1) != 0 // a near-bot?
                    && (Math.abs(dx) > (3<<16) || Math.abs(dz) > (3<<16)) ) {
                   bfire = false;
        	}
        	if (playerVisibleFrom(obj)) {
                   if (!obj.getSeenPlayer()) {
                      obj.setSeenPlayer(true);
                      // "NOW..."
                      playSound(6,(int)obj.getX(),(int)obj.getZ());
                   }
        	}
        	else { // player not visible by bot
                   bfire = false;
        	}
        	if (bfire && (obj.getSleep() > 0)) { // just for initial sound
                   obj.setSleep(obj.getSleep()-1);   // bot may hesitate by random
                   bfire = false;
        	}
        	if (bfire) {
                   // bot wants to fire. calc direction to player.
                   obj.setDir(reverseDir(dx,dz));
                   if (!playerHit && !playerWins)
                      if (tryLaunchBotRocket(counter, obj.getDir(),
                            counter-IndexBots, obj.getFlags())) {
                         obj.setSleep2(10); // avoid walking into own rocket
                      }
                   tryStepBot(obj,dx,dz);
        	}
             }
             continue;
          }

          // the following is used only for rockets
          objectXnew = obj.getX() + Math.sin(obj.getDir())*10000*ispeed;
          objectZnew = obj.getZ() + Math.cos(obj.getDir())*10000*ispeed;

          // reached a discrete new map position?
          xidx1 = ((((int)objectXnew)>>16)&0xFF);
          yidx1 = ((((int)objectZnew)>>16)&0xFF);

          bhit = false;
          if (obj.getShape()==ShapeRocket)
          {
             // create rocket's light trail
             lightFlash((int)objectXnew,(int)objectZnew,1,20);
             // check for rocket<->object collision
             for (iobj=0; iobj<numObjects; iobj++) 
             {
        	if (   object[iobj].getShape()==-1
                    || object[iobj].getShape()==ShapeBush
                    || object[iobj].getShape()==ShapeExplo
                    || iobj==counter // ourselves
                   )
                   continue;
        	xdiff = Math.abs(object[iobj].getX()-objectXnew);
        	ydiff = Math.abs(object[iobj].getZ()-objectZnew);
        	if (xdiff < hitrange && ydiff < hitrange) {
                   if (object[iobj].getShape()==ShapeRocket) {
                      // rocket nearby another rocket. check precise.
                      if (xdiff < rockrange && ydiff < rockrange) {
                         blastObject(object[iobj]);
                         bhit = true;
                      }
                   }  else {
                      // rocket hit a non-rocket object.
                      blastObject(object[iobj]);
                      bhit = true;
                   }
        	}
             }
             // check for rocket<->player collision
             xdiff = Math.abs(playerXpos-objectXnew);
             ydiff = Math.abs(playerYpos-objectZnew);
             if (xdiff < hitrange && ydiff < hitrange && !playerHit) {
        	// player is hit
        	bhit = true;
        	if (!bcheat)
                   playerHit = true;
        	lightFlash((int)objectXnew,(int)objectZnew,10,127);
        	stopMovingSound(1<<1);
        	playSound(2,(int)objectXnew,(int)objectZnew);
        	playTermSound();
             }
             else
             if (xdiff < hitrange*3 && ydiff < hitrange*3) {
        	// rocket just passed the player. make some noise,
        	// but not too often, and if it's not his own.
        	if (obj.getFlags()==0 && (currentTime() > lClLastPassBy + 1000)) {
                   lClLastPassBy = currentTime();
                   playSound(11,(int)objectXnew,(int)objectZnew);
        	}
             }
          }

          if (map[(yidx1<<8)+xidx1]>-1) 
          {
             // handle a wall impact
             bhit = true;
             ipix = map[(yidx1<<8)+xidx1];
             // show impact on plain wall tile. this is done
             // by stepping the wall texture one step higher.
             if (   ipix < numWallPlainText
                 && (ipix&1)==0)
                 map[(yidx1<<8)+xidx1]++;
             lightFlash((int)objectXnew,(int)objectZnew,6,90);
             playSound(1,(int)objectXnew,(int)objectZnew);
          }

          if (bhit) {
             // no matter what kind of object was hit,
             // change its shape now to animated explosion
             obj.setShape(ShapeExplo);
             obj.setFace((short)0);
          }  else {
             obj.setX(objectXnew);
             obj.setZ(objectZnew);
          }

       }  // endfor all objects

       // any changes in the bot walking soundscape?
       if (nClBotsWalking > nOldBotsWalking) {
          if (nOldBotsWalking < 3) {
             int nDiff = Math.min(3,nClBotsWalking)-nOldBotsWalking;
             for (int i=0;i<nDiff;i++) {
        	// System.out.println("=> start "+(6+nOldBotsWalking));
        	// startMovingSound(1<<(6+nOldBotsWalking));
        	requestBotwalkSound(nOldBotsWalking);
        	nOldBotsWalking++;
             }
             // System.out.println(""+nOldBotsWalking+" walkers");
          }
       }
       else
       if (nClBotsWalking < nOldBotsWalking) {
          if (nClBotsWalking <= 0) {
             // just in case we miscounted:
             unRequestBotwalkSound(0);
             unRequestBotwalkSound(1);
             unRequestBotwalkSound(2);
          }
          else
          if (nOldBotsWalking <= 3) {
             int nDiff = nOldBotsWalking-nClBotsWalking;
             for (int i=0;i<nDiff;i++) {
        	nOldBotsWalking--;
        	// System.out.println("=> stop "+(6+nOldBotsWalking));
        	// stopMovingSound(1<<(6+nOldBotsWalking));
        	unRequestBotwalkSound(nOldBotsWalking);
             }
             // System.out.println(""+nOldBotsWalking+" walkers");
          }
       }
    }
    
    void requestBotwalkSound(int inum) {
       //System.out.println("req "+inum);
       aBwShouldPlay[inum%3] = true;
    }
    void unRequestBotwalkSound(int inum) {
       //System.out.println("ureq "+inum);
       aBwShouldPlay[inum%3] = false;
    }
    void initBotwalkSound() {
       for (int i=0;i<3;i++) {
          aBwShouldPlay[i]     = false;
          aBwIsPlaying[i]      = false;
          aBwPlayingSince[i]   = 0;
       }
    }
    // called per frame:
    void stepBotwalkSound() {  
       int nplaying=0;
       boolean btell=false;
       for (int i=0;i<3;i++) {
          // have to start anything?
          if (aBwShouldPlay[i] && !aBwIsPlaying[i]) {
             startMovingSound(1<<(6+i));
             aBwIsPlaying[i]    = true;
             aBwPlayingSince[i] = currentTime();
             btell=true;
          }
          // have to stop anything? we only stop a sound
          // if it played for at least 500 msec. this avoids
          // a sound system overload on quick start/stop changes.
          if (!aBwShouldPlay[i]
        	&& aBwIsPlaying[i]
        	&& ((aBwPlayingSince[i]+800) < currentTime())
             )
          {
             stopMovingSound(1<<(6+i));
             aBwIsPlaying[i] = false;
             btell=true;
          }
          if (aBwIsPlaying[i])
             nplaying++;
       }
       //if (btell)
       //   System.out.println("botwalk "+nplaying);      
    }

    // used by bots, to tell if player can be seen
    boolean playerVisibleFrom(d3object obj) {
       double x1 = obj.getX();
       double z1 = obj.getZ();
       double x2 = playerXpos;
       double z2 = playerYpos;
       double ddx = x2-x1;
       double ddz = z2-z1;
       int    idx = ((int)ddx)>>(16-3); // i.e. and multiply by 8
       int    idz = ((int)ddz)>>(16-3); // i.e. and multiply by 8
       int isteps = Math.max(Math.abs(idx),Math.abs(idz));
           isteps = Math.max(isteps,1); // FIX/1.0.3: potential division by zero
       int cx,cz;
       for (int i=0;i<=isteps;i++) {
          cx = (((int)(x1+i*ddx/isteps))>>16)&0xFF;
          cz = (((int)(z1+i*ddz/isteps))>>16)&0xFF;
          if (map[(cz<<8)+cx] != -1)
             return false;
       }
       return true;
    }

    boolean playerWithinArea(int icode) {
       int x1 = (((int)playerXpos)>>16)&0xFF;
       int z1 = (((int)playerYpos)>>16)&0xFF;
       return (botmap[(z1<<8)+x1]==icode);
    }
    
    void stepAreaLight() 
    {
       if (nAreaLightToStep<=0)
          return;
       // fade the light in when an area got cleared
       int igroup;
       d3area d3a;
       for (int k=0;k<256;k++) 
       {
          if (area[k]!=null && area[k].getLightsUpCnt()>0) 
          {
             // System.out.println("stepping alight "+k);
             for (int n=256;n<65536-256;n++) {
        	if (botmap[n]==k && lightMap[n]<254) lightMap[n]+=2;
        	else
        	if (botmap[n-1]==k && lightMap[n-1]<254) lightMap[n]+=2;
        	else
        	if (botmap[n+1]==k && lightMap[n+1]<254) lightMap[n]+=2;
        	else
        	if (botmap[n-256]==k && lightMap[n-256]<254) lightMap[n]+=2;
        	else
        	if (botmap[n+256]==k && lightMap[n+256]<254) lightMap[n]+=2;
             }
             area[k].setLightsUpCnt(area[k].getLightsUpCnt()-2);
             if ((area[k].getLightsUpCnt())<=0) {
        	area[k].setLightsUpCnt(0);
        	nAreaLightToStep--;
             }
          }
       }
    }

    // this is called after a rocket impact
    void blastObject(d3object obj)
    {
       if (obj.getShape()==ShapeBot) 
       {
          // a bot was hit.
          lightFlash((int)obj.getX(),(int)obj.getZ(),40,127);
          playSound(2,(int)obj.getX(),(int)obj.getZ());

          // first hit on this bot?
          if (obj.getIdamage()==0) {
             // then just change shape
             obj.setIdamage(obj.getIdamage()+1);
             return;
          }

          // bot is terminated
          playBotHit((int)obj.getX(),(int)obj.getZ(),(int)playerXpos,(int)playerYpos);
          obj.getMyarea().removeMember(obj);
          if (obj.getMyarea().getNmembers()>0) 
          {
             // check if only near-bots remain in area
             d3area d3a = obj.getMyarea();
             boolean btruebots = false;
             int i;
             for (i=0;i<d3a.getAmember().length;i++)
        	if(d3a.getAmember()[i]!=null
                    && d3a.getAmember()[i].getShape()==ShapeBot
                    && d3a.getAmember()[i].getFlags()==0) {
                   btruebots = true;
                   break;
        	}
             // if so, switch them all to far-bots
             if (!btruebots)
              for (i=0;i<d3a.getAmember().length;i++)
        	if (   d3a.getAmember()[i]!=null
                    && d3a.getAmember()[i].getShape()==ShapeBot)
                   d3a.getAmember()[i].setFlags(0);
          }
          if (obj.getMyarea().getNmembers()==0) 
          {
             // no bots remaining in area
             d3area d3a = obj.getMyarea();
             stopCarpetSound();
             playAreaCleared();
             overMessage("area cleared, establishing new art.", 5000, false);
             // allow respawn?
             if (d3a.getSpawnx() != -1)
        	iClLastClearedArea = d3a.getIname();
             // remove alien art
             for (int i=0;i<d3a.getNimages();i++) {
        	map[d3a.getAimagez()[i]*256+d3a.getAimagex()[i]]
                   += (iwallimghi-iwallimglo);
             }
             // lights up!
             d3a.setLightsUpCnt(200);
             nAreaLightToStep++;
             d3a.setFoglevel(1);
             d3a.setLightlevel(256);
             // disable light sources to reduce cpu usage
             d3a.setNlights(0);
          }
          obj.setMyarea(null);
       }  else {
          // a non-bot was hit. this could be
          // another rocket, or a deko
          lightFlash((int)obj.getX(),(int)obj.getZ(),10,127);
          if (obj.getShape()==ShapeDeko) {
             if (obj.getFace()==0 || obj.getFace()>=3)
        	playSound(3,(int)obj.getX(),(int)obj.getZ());
             else // table etc.
        	playSound(4,(int)obj.getX(),(int)obj.getZ());
             // was this a light emitting object?
             if (obj.getFace()==5) {
        	// so, if it' w/in an area, remove light source
        	byte igroup =
                 botmap[ ((((int)obj.getZ())>>16)&0xFF)*256
                	+((((int)obj.getX())>>16)&0xFF)];
        	d3area d3a = area[igroup];
        	if (d3a != null)
                   d3a.tryRemoveLight(((int)obj.getX())>>16,((int)obj.getZ())>>16);
             }
          }
          else
             playSound(1,(int)obj.getX(),(int)obj.getZ());
       }
       // this spot may have been blocked by the object.
       // re-allow player movement here.
       movemap[ ((((int)obj.getZ())>>16)&0xFF)*256
               +((((int)obj.getX())>>16)&0xFF)] = 0;
       // turn the object into an explosion object
       obj.setSpeed((short)1); // pseudo, for explo anim
       obj.setShape(ShapeExplo);
    }

    void tryLaunchPlayerRocket()
    {
       /*It prevents the player from shooting 6 rockets together instantaneously*/
       if(currentTime()-lastShot<d3caster.timeBetweenShots)
           return;
       // a maximum of 3 active rockets applies.
       // if they're all currently active,
       // tryLaunch returns without any action.
       int irocket;
       d3object obj;
       boolean blaunched = false;
       final int maxactive = 6;

       // right rocket
       for (irocket=0; irocket<maxactive; irocket++)
          if (object[IndexPlayerRockets+irocket].getShape()==-1)
             break;
       if (irocket<maxactive)
       {
          obj = object[irocket];
          obj.setX(playerXpos - Math.sin(playerDirection+fullCircle/4)*10000*1);
          obj.setZ(playerYpos - Math.cos(playerDirection+fullCircle/4)*10000*1);
          obj.setShape(ShapeRocket);
          obj.setFace((short)0);
          obj.setDir(playerDirection);
          obj.setSpeed((short)3);
          obj.setFlags(1); // my own rocket
          blaunched = true;
       }

       // left rocket
       for (irocket=0; irocket<maxactive; irocket++)
          if (object[IndexPlayerRockets+irocket].getShape()==-1)
             break;
       if (irocket<maxactive)
       {
          obj = object[irocket];
          obj.setX(playerXpos - Math.sin(playerDirection+fullCircle*3/4)*10000*1);
          obj.setZ(playerYpos - Math.cos(playerDirection+fullCircle*3/4)*10000*1);
          obj.setShape(ShapeRocket);
          obj.setFace((short)0);
          obj.setDir(playerDirection);
          obj.setSpeed((short)3);
          obj.setFlags(1); // my own rocket
          blaunched = true;
       }

       if(blaunched)
           {playSound(0,(int)playerXpos,(int)playerYpos);
	    lastShot=currentTime();
	   }
    }

    boolean tryLaunchBotRocket(int ifrom, double ddir, int irocket, int ibotflags)
    {
       d3object obj;

       // there are two sets of rockets,
       // one for std, and one for dist bots.
       // both together shall not exceed 9 active rockets.
       if ((ibotflags&1)!=0) 
       {
          // take from dist bot contingent.
          irocket = IndexBotRockets + 5 + (irocket % 4);
          if (!bcheat && object[irocket].getShape()==-1)
          {
             obj = object[irocket];
             obj.setX(object[ifrom].getX());
             obj.setZ(object[ifrom].getZ());
             obj.setShape(ShapeRocket);
             obj.setFace((short)0);
             obj.setDir(ddir);
             obj.setSpeed((short)3);
             playSound(0,(int)obj.getX(),(int)obj.getZ());
             return true;
          }
       }
       else 
       {
          // take from std bot contingent.
          irocket = IndexBotRockets + (irocket % 5);
          if (!bcheat && object[irocket].getShape()==-1)
          {
             obj = object[irocket];
             obj.setX(object[ifrom].getX());
             obj.setZ(object[ifrom].getZ());
             obj.setShape(ShapeRocket);
             obj.setFace((short)0);
             obj.setDir(ddir);
             obj.setSpeed((short)3);
             playSound(0,(int)obj.getX(),(int)obj.getZ());
             return true;
          }
       }
       return false;
    }

    // reverse calculate a direction from a position delta
    double reverseDir(double dx, double dz)
    {
       int n1;

       final double aquaddelta[] = {
          0.0, fullCircle/2.0, fullCircle/2.0, fullCircle
       };

       if (dx>0) {
          if (dz > 0) n1 = 0;
          else        n1 = 1;
       }  else  {
          if (dz > 0) n1 = 3;
          else        n1 = 2;
       }

       final double dthresh = 0.01 * 65536.0;
       if (Math.abs(dx) < dthresh) {
          if (dz > 0.0)
             return 0.0;
          else
             return fullCircle/2.0;
       }
       if (Math.abs(dz) < dthresh) {
          if (dx > 0.0)
             return fullCircle/4.0;
          else
             return fullCircle*3.0/4.0;
       }

       double d = Math.atan(dx/dz) + aquaddelta[n1];

       if (d < 0.0) d += fullCircle;

       return d;
    }

    /*
       Image masks are masks for a corresponding JPEG image,
       supplying transparency information.
       Image masks are stored as zip's within a zip.
       Every inner zip contains tres*tres bytes,
       each byte being 1 (transparent) or 0 (opaque).
       Use the supplied conversion tool to create.
       In the following method, the inner zips are extracted
       from the big zip, and stored, in compressed form,
       by their corresponding target d3texture.
    */
    void prepareImageMasks(byte aTmp[]){
     try 
     {       
       InputStream inStream;
       inStream = new FileInputStream("masks.jar"); 	  
       ZipInputStream zis = new ZipInputStream(inStream);
       while (true)
       {
          ZipEntry ze = zis.getNextEntry();
          if (ze == null)
             break; // eod
          String sName  = ze.getName();
          boolean bbail = false;
          for (itext=0; !bbail && (itext<ntext); itext++)
          {
             d3texture d3t = atext[itext];
             for (int iface=0; !bbail && (iface<d3t.getNfaces()); iface++)
             {
        	String sdig = doubdig(iface);
        	if (d3t.getNfaces()==1) sdig="";
        	String sName2 = d3t.getFilebase()+sdig+".zip";
        	if (sName2.equals(sName)) {
                   int icur=0, iRead=0, ntotal=0;
                   try {
                    while ((iRead = zis.read(aTmp,icur,aTmp.length-icur)) > 0) {
                      icur   += iRead;
                      ntotal += iRead;
                    } 
                   } catch(Throwable t) { } // ns 4.79 ...
                   if (d3t.getAmask()==null)
                       d3t.setAmask(new byte[d3t.getNfaces()][]);
                   d3t.setAmask(iface,new byte[ntotal]);
                   System.arraycopy(aTmp,0,d3t.getAmask()[iface],0,ntotal);
                   bbail = true; // continue on next ZipEntry
                   // System.out.println("copied "+sName+", "+ntotal+" bytes");
                   status("prepared "+sName);
        	}
             }
          }
          if (!bbail && sName.indexOf("META-INF")<0)
             System.out.println("warning: no match for "+sName);
       }
       zis.close();
       System.out.println("image masks prepared.");
     } catch (Throwable t) {
       System.out.println("err5: "+t);
       t.printStackTrace();
     }
    }

    // get a stored, compressed image mask and decompress it.
    void loadMaskToBuffer(d3texture d3t,int iface,byte[] aout)
    {
     try 
     {
       if (d3t.getAmask()==null || d3t.getAmask()[iface]==null) {
          System.out.println("err: no mask data for "+d3t.getFilebase());
          return;
       }
       ByteArrayInputStream inStream =
          new ByteArrayInputStream(d3t.getAmask()[iface],0,d3t.getAmask()[iface].length);
       ZipInputStream zis2 = new ZipInputStream(inStream);
       ZipEntry ze2 = zis2.getNextEntry();
       int icur=0,iRead=0,ntotal=0;
       try {
       while ((iRead = zis2.read(aout,icur,aout.length-icur)) > 0) {
          icur   += iRead;
          ntotal += iRead;
	}
       }  catch (Throwable t) {
          // ns 4.79 throws ArrayIndexOutOfBounds,
          // but everything's read fine.
       }
       zis2.close();       
     } catch (Throwable t) {
       System.out.println("err: "+d3t.getFilebase()+": "+t);
       t.printStackTrace();
     }
       d3t.setAmask(iface,null); // no longer needed
    }

    int nextRand(int i) {
       return((rg.nextInt()&65535)%i);
    }

    void respawnWithin(d3area d3a){
       d3object d3o;
       // clear the area
       for (int n=0;n<d3a.getNmembers();n++) {
          d3o = d3a.getAmember()[n];
          if (d3o != null) {
             d3o.setSpeed((short)0);
             d3o.setShape(-1);
          }
       }
       // switch area's images
       for (int n=0;n<d3a.getNimages();n++) {
          int ioff = d3a.getAimagez()[n]*256+d3a.getAimagex()[n];
          int itxt = map[ioff]+iwallplain;
          if (itxt>=iwallimglo && itxt<iwallimghi)
             map[ioff] += (iwallimghi-iwallimglo);
       }
       // warp player into there
       playerXpos = d3a.getSpawnx()<<16;
       playerYpos = d3a.getSpawnz()<<16;
       playerDirection = d3a.getPlayerdir();
       // lights up!
       d3a.setLightsUpCnt(200);
       d3a.setFoglevel(1);
       d3a.setLightlevel(256);
       // disable light sources to reduce cpu usage
       d3a.setNlights(0);
       // avoid double spawn
       d3a.setSpawnx(-1);
       d3a.setSpawnz(-1);
       d3a.setAnnounced(true);
       overMessage(d3a.name(),4000,false);
       stopCarpetSound();
    }
                   	
    /* =========================================================
        	ANY-JDK COMPATIBLE JAVA SOUND SYSTEM
       This code tries to use Java 2 JDK Sound, which is NOT
       available in every browser. If it fails, therefore,
       it simply falls back to Java 1 JDK Sound.
       ========================================================= */
    
    void attachSound() 
    {
       System.out.println("trying Java 2 Sound:");
       try {
          sif = new d3sound2();        
	  sif.attach(null,"",true);
          bJava2Attached = true;
          return;
       }  catch (Throwable e) {
          System.out.println(e.getMessage());
          System.out.println("Java 2 sound failed, retrying on Java 1");
       }
       System.out.println("trying Java 1 Sound:");
       try {
          sif = new d3sound1();         
	  sif.attach(null,"",true);
          return;
       }  catch (Throwable e) {
          System.out.println(e.getMessage());
          System.out.println("Java 1 sound failed");
       }
    }
    
    void    openSound() 
    {  try{
       if (sif!=null) {
          if (!sif.openSound() && bJava2Attached) {
             // Java 2 sound startup failed. retry on Java 1
             System.out.println("retrying on Java 1 Sound");
             try {
        	sif = new d3sound1();
        	bJava2Attached = false;               
		sif.attach(null,"",true);
        	sif.loadSounds();
        	sif.openSound();
        	return;
             }  catch (Throwable e) {
        	System.out.println(e.getMessage());
        	System.out.println("Java 1 sound retry failed");
        	sif = null;
             }
          }
       }
          }
       catch(Exception e){
           System.out.println("Problem : "+e);
       }
    }

    public static void main(String[] args){
	new d3caster();       
    }

    void    closeSound()      { if (sif!=null) sif.closeSound();        }
    boolean loadSounds()      { if (sif!=null) return sif.loadSounds(); 
                                       return false; }
    void    stepMusic()       { if (sif!=null) sif.stepMusic();         }
    void    restartMusic()    { if (sif!=null) sif.restartMusic();      }
    void    stepSoundLoading(){ if (sif!=null) sif.stepSoundLoading();  }
    String  soundInfo()       { if (sif!=null) return sif.soundInfo(); 
                                       return ""; }
    void    playSound(int id,int x,int z) 
       { if (sif!=null) sif.playSound(id,x,z,(int)playerXpos,(int)playerYpos);  }
    void    playBotGreeting() { if (sif!=null) sif.playBotGreeting();   }
    void    playBotHit(int x1,int z1,int x2,int z2) { if (sif!=null) sif.playBotHit(x1,z1,x2,z2); }
    void    playAreaCleared() { if (sif!=null) sif.playAreaCleared();   }
    void    playTermSound()   { if (sif!=null) sif.playTermSound();     }
    void    startMovingSound(int iMask){ if (sif!=null) sif.startMovingSound(iMask);  }
    void    stopMovingSound(int iMask) { if (sif!=null) sif.stopMovingSound(iMask);   }
    void    startCarpetSound(){ if (sif!=null) sif.startCarpetSound();  }
    void    stopCarpetSound() { if (sif!=null) sif.stopCarpetSound();   }
    void    stopAllSounds()   { if (sif!=null) sif.stopAllSounds();     }
    void    setSoundOption(String s) { if (sif!=null) sif.setSoundOption(s); }
}
