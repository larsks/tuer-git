-- 3dvia.com   --

The zip file cop.dae.zip contains the following files :
- readme.txt
- 41E72777495B6D7F_cop.png
- cop.dae


-- Model information --

Model Name : cop
Author : unknown
Publisher : gouessej

You can view this model here :
http://www.3dvia.com/content/BE1BE3B48698AABC
More models about this author :
http://www.3dvia.com/gouessej


-- Attached license --

A license is attached to the cop model and all related media.
You must agree with this licence before using the enclosed media.

License : Attribution-ShareAlike 2.5
Detailed license : http://creativecommons.org/licenses/by-sa/2.5/

The licenses used by 3dvia are based on Creative Commons Licenses.
More info: http://creativecommons.org/about/licenses/meet-the-licenses
