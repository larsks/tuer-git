-- 3dvia.com   --

The zip file LID0.dae.zip contains the following files :
- readme.txt
- 0E4B740416283A0C_wallTexture.png
- LID0.obj.dae


-- Model information --

Model Name : LID0
Author : Julien Gouesse
Publisher : gouessej

You can view this model here :
http://www.3dvia.com/content/8ECAF38496A8BA8C
More models about this author :
http://www.3dvia.com/gouessej


-- Attached license --

A license is attached to the LID0 model and all related media.
You must agree with this licence before using the enclosed media.

License : Attribution-ShareAlike 2.5
Detailed license : http://creativecommons.org/licenses/by-sa/2.5/

The licenses used by 3dvia are based on Creative Commons Licenses.
More info: http://creativecommons.org/about/licenses/meet-the-licenses
