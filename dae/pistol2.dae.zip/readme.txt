-- 3dvia.com   --

The zip file pistol2.dae.zip contains the following files :
- readme.txt
- 48E42A7E50627446_pistol2.png
- pistol2.obj.dae


-- Model information --

Model Name : pistol2
Author : Psionic3D
Publisher : gouessej

You can view this model here :
http://www.3dvia.com/content/08A56A3E10223406
More models about this author :
http://www.3dvia.com/gouessej


-- Attached license --

A license is attached to the pistol2 model and all related media.
You must agree with this licence before using the enclosed media.

License : Attribution-ShareAlike 2.5
Detailed license : http://creativecommons.org/licenses/by-sa/2.5/

The licenses used by 3dvia are based on Creative Commons Licenses.
More info: http://creativecommons.org/about/licenses/meet-the-licenses
